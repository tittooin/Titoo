export interface VideoClip {
  startTime: number;
  endTime: number;
  duration: number;
}

export interface VideoFile {
  file: File;
  url: string;
  duration: number;
}

export function formatTime(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = Math.floor(seconds % 60);
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
}

export function parseTimeInput(timeString: string): number {
  const parts = timeString.split(':');
  if (parts.length === 2) {
    const minutes = parseInt(parts[0], 10);
    const seconds = parseFloat(parts[1]);
    return minutes * 60 + seconds;
  }
  return 0;
}

export function timeToInputValue(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = (seconds % 60).toFixed(1);
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.padStart(4, '0')}`;
}

export function validateVideoFile(file: File): string | null {
  const validTypes = ['video/mp4', 'video/webm', 'video/avi'];
  const maxSize = 500 * 1024 * 1024; // 500MB

  if (!validTypes.includes(file.type)) {
    return 'Please select a valid video file (MP4, WebM, or AVI)';
  }

  if (file.size > maxSize) {
    return 'File size must be less than 500MB';
  }

  return null;
}

export async function getVideoDuration(file: File): Promise<number> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    
    video.onloadedmetadata = () => {
      window.URL.revokeObjectURL(video.src);
      resolve(video.duration);
    };
    
    video.onerror = () => {
      window.URL.revokeObjectURL(video.src);
      reject(new Error('Failed to load video metadata'));
    };
    
    video.src = URL.createObjectURL(file);
  });
}

export async function trimVideo(
  videoFile: File,
  startTime: number,
  endTime: number,
  onProgress?: (progress: number) => void
): Promise<Blob> {
  const { FFmpeg } = await import('@ffmpeg/ffmpeg');
  const { fetchFile, toBlobURL } = await import('@ffmpeg/util');
  
  const ffmpeg = new FFmpeg();
  
  try {
    onProgress?.(10);
    
    // Load FFmpeg core
    const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
    await ffmpeg.load({
      coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
      wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
    });
    
    onProgress?.(30);
    
    // Write input file
    const inputFileName = 'input.mp4';
    const outputFileName = 'output.mp4';
    await ffmpeg.writeFile(inputFileName, await fetchFile(videoFile));
    
    onProgress?.(50);
    
    // Set up progress tracking
    ffmpeg.on('progress', ({ progress }) => {
      const totalProgress = 50 + (progress * 40); // 50% base + 40% for processing
      onProgress?.(totalProgress);
    });
    
    // Execute trim command
    const duration = endTime - startTime;
    await ffmpeg.exec([
      '-i', inputFileName,
      '-ss', startTime.toString(),
      '-t', duration.toString(),
      '-c', 'copy', // Use copy codec for faster processing
      '-avoid_negative_ts', 'make_zero',
      outputFileName
    ]);
    
    onProgress?.(95);
    
    // Read output file
    const data = await ffmpeg.readFile(outputFileName);
    const blob = new Blob([data], { type: 'video/mp4' });
    
    onProgress?.(100);
    
    // Cleanup
    await ffmpeg.deleteFile(inputFileName);
    await ffmpeg.deleteFile(outputFileName);
    ffmpeg.terminate();
    
    return blob;
  } catch (error) {
    ffmpeg.terminate();
    throw new Error(`Video processing failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function isValidVideoUrl(url: string): boolean {
  const youtubePattern = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  const facebookPattern = /(?:facebook\.com|fb\.watch)\/.*\/videos\/\d+/;
  
  return youtubePattern.test(url) || facebookPattern.test(url);
}

export function extractVideoId(url: string): string | null {
  const youtubePattern = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
  const facebookPattern = /(?:facebook\.com|fb\.watch)\/.*\/videos\/(\d+)/;
  
  const youtubeMatch = url.match(youtubePattern);
  if (youtubeMatch) {
    return youtubeMatch[1];
  }
  
  const facebookMatch = url.match(facebookPattern);
  if (facebookMatch) {
    return facebookMatch[1];
  }
  
  return null;
}

export async function downloadVideoFromUrl(url: string, onProgress?: (progress: number) => void): Promise<File> {
  try {
    onProgress?.(10);
    
    // Try direct fetch first (works for some video URLs)
    const response = await fetch(url, {
      method: 'GET',
      mode: 'cors',
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    onProgress?.(30);
    
    const contentLength = response.headers.get('content-length');
    const total = contentLength ? parseInt(contentLength, 10) : 0;
    
    let loaded = 0;
    const reader = response.body?.getReader();
    const chunks: Uint8Array[] = [];
    
    if (!reader) {
      throw new Error('Failed to get response reader');
    }
    
    while (true) {
      const { done, value } = await reader.read();
      
      if (done) break;
      
      chunks.push(value);
      loaded += value.length;
      
      if (total > 0) {
        const progress = 30 + (loaded / total) * 60;
        onProgress?.(Math.min(progress, 90));
      }
    }
    
    onProgress?.(95);
    
    // Combine all chunks
    const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
    const combined = new Uint8Array(totalLength);
    let offset = 0;
    
    for (const chunk of chunks) {
      combined.set(chunk, offset);
      offset += chunk.length;
    }
    
    // Create file with proper name
    const videoId = extractVideoId(url);
    const filename = videoId ? `video_${videoId}.mp4` : 'downloaded_video.mp4';
    const file = new File([combined], filename, { type: 'video/mp4' });
    
    onProgress?.(100);
    return file;
    
  } catch (error) {
    console.error('Direct download failed:', error);
    
    // Fallback: Try using a proxy service or provide instructions
    throw new Error(
      'Direct video download failed due to CORS restrictions. ' +
      'Please try one of these alternatives:\n\n' +
      '1. Download the video manually and upload the file\n' +
      '2. Use a browser extension that allows CORS\n' +
      '3. Use a different video URL that allows direct access\n\n' +
      'For YouTube videos, you can also try using the embed URL format.'
    );
  }
}
