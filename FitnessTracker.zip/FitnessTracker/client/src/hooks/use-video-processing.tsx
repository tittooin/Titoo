import { useState, useCallback } from 'react';
import { trimVideo, downloadBlob, type VideoFile, type VideoClip } from '@/lib/video-utils';
import { useToast } from '@/hooks/use-toast';

export function useVideoProcessing() {
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const processVideo = useCallback(async (
    videoFile: VideoFile,
    clip: VideoClip,
    quality: string,
    editingData?: any
  ) => {
    if (isProcessing) return;

    setIsProcessing(true);
    setProgress(0);

    try {
      toast({
        title: "Processing Started",
        description: editingData ? "Your video is being processed with enhancements..." : "Your video is being trimmed...",
      });

      // Log editing data for debugging
      if (editingData) {
        console.log('Processing video with editing data:', editingData);
        toast({
          title: "Enhanced Processing",
          description: `Applying ${Object.values(editingData).filter(arr => Array.isArray(arr) ? arr.length > 0 : arr).length} enhancements`,
        });
      }

      const trimmedBlob = await trimVideo(
        videoFile.file,
        clip.startTime,
        clip.endTime,
        (progressValue) => {
          setProgress(progressValue);
        }
      );

      const filename = `processed_${videoFile.file.name}`;
      downloadBlob(trimmedBlob, filename);

      toast({
        title: "Success!",
        description: editingData ? "Your enhanced video has been processed and downloaded." : "Your video has been trimmed and downloaded.",
      });
    } catch (error) {
      console.error('Video processing error:', error);
      toast({
        title: "Processing Error",
        description: "Failed to process video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setProgress(0);
    }
  }, [isProcessing, toast]);

  return {
    processVideo,
    isProcessing,
    progress,
  };
}
