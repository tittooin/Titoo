import { useState } from 'react';
import { Settings, Sun, Contrast, Palette, Zap, Eye, RotateCcw } from 'lucide-react';

interface VideoEnhancement {
  brightness: number;
  contrast: number;
  saturation: number;
  hue: number;
  gamma: number;
  sharpness: number;
  denoise: number;
  stabilization: boolean;
  autoColor: boolean;
  autoExposure: boolean;
}

interface EnhancementPanelProps {
  enhancements: VideoEnhancement;
  onEnhancementsChange: (enhancements: VideoEnhancement) => void;
}

export function EnhancementPanel({ enhancements, onEnhancementsChange }: EnhancementPanelProps) {
  const [activeSection, setActiveSection] = useState<'color' | 'quality' | 'auto'>('color');

  const updateEnhancement = (key: keyof VideoEnhancement, value: number | boolean) => {
    onEnhancementsChange({
      ...enhancements,
      [key]: value
    });
  };

  const resetEnhancements = () => {
    onEnhancementsChange({
      brightness: 0,
      contrast: 0,
      saturation: 0,
      hue: 0,
      gamma: 0,
      sharpness: 0,
      denoise: 0,
      stabilization: false,
      autoColor: false,
      autoExposure: false
    });
  };

  const presets = [
    {
      name: 'Vibrant',
      description: 'Boost colors and contrast',
      settings: { brightness: 10, contrast: 20, saturation: 30, hue: 0, gamma: 0, sharpness: 10, denoise: 0 }
    },
    {
      name: 'Cinematic',
      description: 'Film-like color grading',
      settings: { brightness: -5, contrast: 15, saturation: -10, hue: 5, gamma: 5, sharpness: 5, denoise: 5 }
    },
    {
      name: 'Natural',
      description: 'Enhance without overdoing',
      settings: { brightness: 5, contrast: 10, saturation: 10, hue: 0, gamma: 0, sharpness: 5, denoise: 10 }
    },
    {
      name: 'High Contrast',
      description: 'Bold and dramatic look',
      settings: { brightness: 0, contrast: 40, saturation: 20, hue: 0, gamma: -10, sharpness: 15, denoise: 0 }
    }
  ];

  const applyPreset = (preset: typeof presets[0]) => {
    onEnhancementsChange({
      ...enhancements,
      ...preset.settings
    });
  };

  const sections = [
    { id: 'color', name: 'Color', icon: Palette },
    { id: 'quality', name: 'Quality', icon: Eye },
    { id: 'auto', name: 'Auto Fix', icon: Zap }
  ];

  return (
    <div className="bg-slate-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Settings className="mr-2 text-yellow-400" size={20} />
          <h3 className="text-lg font-semibold">Video Enhancement</h3>
        </div>
        <button
          onClick={resetEnhancements}
          className="bg-slate-700 hover:bg-slate-600 px-3 py-1 rounded-lg text-xs font-medium transition-colors flex items-center"
          type="button"
        >
          <RotateCcw className="mr-1" size={12} />
          Reset
        </button>
      </div>

      {/* Quick Presets */}
      <div className="mb-6">
        <h4 className="font-medium text-sm text-slate-300 mb-3">Quick Presets</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {presets.map(preset => (
            <button
              key={preset.name}
              className="bg-slate-700 hover:bg-slate-600 rounded-lg p-3 text-center transition-colors"
              onClick={() => applyPreset(preset)}
              type="button"
            >
              <h5 className="font-medium text-sm mb-1">{preset.name}</h5>
              <p className="text-xs text-slate-400">{preset.description}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Section Tabs */}
      <div className="flex space-x-1 mb-6 bg-slate-700 rounded-lg p-1">
        {sections.map(section => {
          const IconComponent = section.icon;
          return (
            <button
              key={section.id}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex-1 flex items-center justify-center ${
                activeSection === section.id
                  ? 'bg-yellow-500 text-white shadow-lg'
                  : 'text-slate-300 hover:text-white hover:bg-slate-600'
              }`}
              onClick={() => setActiveSection(section.id as any)}
              type="button"
            >
              <IconComponent className="mr-2" size={16} />
              {section.name}
            </button>
          );
        })}
      </div>

      {/* Color Adjustments */}
      {activeSection === 'color' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Sun className="mr-2 text-yellow-400" size={16} />
                Brightness: {enhancements.brightness > 0 ? '+' : ''}{enhancements.brightness}
              </label>
              <input
                type="range"
                min="-50"
                max="50"
                value={enhancements.brightness}
                onChange={(e) => updateEnhancement('brightness', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #475569 0%, #475569 ${((enhancements.brightness + 50) / 100) * 100}%, #eab308 ${((enhancements.brightness + 50) / 100) * 100}%, #eab308 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>Dark</span>
                <span>Bright</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Contrast className="mr-2 text-blue-400" size={16} />
                Contrast: {enhancements.contrast > 0 ? '+' : ''}{enhancements.contrast}
              </label>
              <input
                type="range"
                min="-50"
                max="50"
                value={enhancements.contrast}
                onChange={(e) => updateEnhancement('contrast', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #475569 0%, #475569 ${((enhancements.contrast + 50) / 100) * 100}%, #3b82f6 ${((enhancements.contrast + 50) / 100) * 100}%, #3b82f6 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>Flat</span>
                <span>High</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Palette className="mr-2 text-green-400" size={16} />
                Saturation: {enhancements.saturation > 0 ? '+' : ''}{enhancements.saturation}
              </label>
              <input
                type="range"
                min="-50"
                max="50"
                value={enhancements.saturation}
                onChange={(e) => updateEnhancement('saturation', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #475569 0%, #475569 ${((enhancements.saturation + 50) / 100) * 100}%, #10b981 ${((enhancements.saturation + 50) / 100) * 100}%, #10b981 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>Muted</span>
                <span>Vibrant</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Palette className="mr-2 text-purple-400" size={16} />
                Hue Shift: {enhancements.hue > 0 ? '+' : ''}{enhancements.hue}°
              </label>
              <input
                type="range"
                min="-180"
                max="180"
                value={enhancements.hue}
                onChange={(e) => updateEnhancement('hue', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #475569 0%, #475569 ${((enhancements.hue + 180) / 360) * 100}%, #8b5cf6 ${((enhancements.hue + 180) / 360) * 100}%, #8b5cf6 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>-180°</span>
                <span>+180°</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Sun className="mr-2 text-orange-400" size={16} />
                Gamma: {enhancements.gamma > 0 ? '+' : ''}{enhancements.gamma}
              </label>
              <input
                type="range"
                min="-30"
                max="30"
                value={enhancements.gamma}
                onChange={(e) => updateEnhancement('gamma', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #475569 0%, #475569 ${((enhancements.gamma + 30) / 60) * 100}%, #f97316 ${((enhancements.gamma + 30) / 60) * 100}%, #f97316 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>Dark Mid</span>
                <span>Bright Mid</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quality Enhancements */}
      {activeSection === 'quality' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Eye className="mr-2 text-cyan-400" size={16} />
                Sharpness: {enhancements.sharpness}
              </label>
              <input
                type="range"
                min="0"
                max="50"
                value={enhancements.sharpness}
                onChange={(e) => updateEnhancement('sharpness', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #06b6d4 0%, #06b6d4 ${(enhancements.sharpness / 50) * 100}%, #475569 ${(enhancements.sharpness / 50) * 100}%, #475569 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>Soft</span>
                <span>Sharp</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-3 flex items-center">
                <Zap className="mr-2 text-pink-400" size={16} />
                Noise Reduction: {enhancements.denoise}
              </label>
              <input
                type="range"
                min="0"
                max="50"
                value={enhancements.denoise}
                onChange={(e) => updateEnhancement('denoise', parseInt(e.target.value))}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #ec4899 0%, #ec4899 ${(enhancements.denoise / 50) * 100}%, #475569 ${(enhancements.denoise / 50) * 100}%, #475569 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-slate-400 mt-1">
                <span>None</span>
                <span>Strong</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-sm flex items-center">
                  <Zap className="mr-2 text-blue-400" size={16} />
                  Video Stabilization
                </p>
                <p className="text-xs text-slate-400">Reduce camera shake and movement</p>
              </div>
              <button
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  enhancements.stabilization ? 'bg-blue-500' : 'bg-slate-600'
                }`}
                onClick={() => updateEnhancement('stabilization', !enhancements.stabilization)}
                type="button"
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  enhancements.stabilization ? 'translate-x-7' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Auto Enhancements */}
      {activeSection === 'auto' && (
        <div className="space-y-4">
          <div className="bg-slate-700 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-sm flex items-center">
                  <Palette className="mr-2 text-green-400" size={16} />
                  Auto Color Correction
                </p>
                <p className="text-xs text-slate-400">Automatically balance colors and white balance</p>
              </div>
              <button
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  enhancements.autoColor ? 'bg-green-500' : 'bg-slate-600'
                }`}
                onClick={() => updateEnhancement('autoColor', !enhancements.autoColor)}
                type="button"
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  enhancements.autoColor ? 'translate-x-7' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-sm flex items-center">
                  <Sun className="mr-2 text-yellow-400" size={16} />
                  Auto Exposure
                </p>
                <p className="text-xs text-slate-400">Automatically adjust brightness and contrast</p>
              </div>
              <button
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  enhancements.autoExposure ? 'bg-yellow-500' : 'bg-slate-600'
                }`}
                onClick={() => updateEnhancement('autoExposure', !enhancements.autoExposure)}
                type="button"
              >
                <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                  enhancements.autoExposure ? 'translate-x-7' : 'translate-x-1'
                }`} />
              </button>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-4">
            <div className="text-center">
              <Zap className="mx-auto mb-3 text-blue-400" size={32} />
              <h4 className="font-medium text-sm mb-2">One-Click Enhancement</h4>
              <p className="text-xs text-slate-400 mb-4">Apply intelligent auto-enhancements to your video</p>
              <button
                onClick={() => {
                  onEnhancementsChange({
                    ...enhancements,
                    brightness: 5,
                    contrast: 15,
                    saturation: 10,
                    sharpness: 10,
                    denoise: 15,
                    autoColor: true,
                    autoExposure: true
                  });
                }}
                className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                type="button"
              >
                Auto Enhance Video
              </button>
            </div>
          </div>

          <div className="bg-slate-700 rounded-lg p-4">
            <h4 className="font-medium text-sm mb-3 text-slate-300">Enhancement Tips</h4>
            <ul className="space-y-2 text-xs text-slate-400">
              <li>• Use Auto Color Correction for videos with poor lighting</li>
              <li>• Apply Noise Reduction for grainy or low-quality videos</li>
              <li>• Use Stabilization for handheld or shaky footage</li>
              <li>• Adjust Gamma for better mid-tone visibility</li>
              <li>• Increase Sharpness for clearer details</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}