export function HowItWorks() {
  const steps = [
    {
      number: 1,
      title: "Import Video",
      description: "Upload a file or paste YouTube/Facebook URL",
      bgColor: "bg-blue-500"
    },
    {
      number: 2,
      title: "Quick Clips", 
      description: "Choose 30s, 45s, or 60s clips instantly",
      bgColor: "bg-green-500"
    },
    {
      number: 3,
      title: "Manual Edit",
      description: "Use timeline for precise start/end control",
      bgColor: "bg-purple-500"
    },
    {
      number: 4,
      title: "Download",
      description: "Get your trimmed video file instantly",
      bgColor: "bg-yellow-500"
    }
  ];

  return (
    <section className="bg-slate-800 rounded-xl p-6">
      <h2 className="text-xl font-bold mb-6 text-center">How It Works</h2>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {steps.map((step) => (
          <div key={step.number} className="text-center">
            <div className={`w-12 h-12 ${step.bgColor} rounded-full flex items-center justify-center mx-auto mb-3 text-white font-bold`}>
              {step.number}
            </div>
            <h4 className="font-medium mb-2">{step.title}</h4>
            <p className="text-slate-300 text-sm">{step.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
