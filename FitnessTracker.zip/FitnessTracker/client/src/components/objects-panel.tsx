import { useState } from 'react';
import { ImageIcon, Square, Circle, Triangle, Star, Heart, ArrowRight, Trash2 } from 'lucide-react';

interface VideoObject {
  id: string;
  type: 'shape' | 'arrow' | 'sticker';
  shape?: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  opacity: number;
  rotation: number;
  startTime: number;
  endTime: number;
  borderWidth: number;
  borderColor: string;
  filled: boolean;
}

interface ObjectsPanelProps {
  objects: VideoObject[];
  onObjectsChange: (objects: VideoObject[]) => void;
  videoDuration: number;
}

export function ObjectsPanel({ objects, onObjectsChange, videoDuration }: ObjectsPanelProps) {
  const [selectedObject, setSelectedObject] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<'shapes' | 'arrows' | 'stickers'>('shapes');

  const shapes = [
    { id: 'rectangle', name: 'Rectangle', icon: Square },
    { id: 'circle', name: 'Circle', icon: Circle },
    { id: 'triangle', name: 'Triangle', icon: Triangle },
    { id: 'star', name: 'Star', icon: Star },
    { id: 'heart', name: 'Heart', icon: Heart }
  ];

  const arrows = [
    { id: 'arrow-right', name: 'Right Arrow', icon: ArrowRight },
    { id: 'arrow-up', name: 'Up Arrow', icon: ArrowRight },
    { id: 'arrow-down', name: 'Down Arrow', icon: ArrowRight },
    { id: 'arrow-left', name: 'Left Arrow', icon: ArrowRight }
  ];

  const stickers = [
    { id: 'thumbs-up', name: '👍', emoji: '👍' },
    { id: 'fire', name: '🔥', emoji: '🔥' },
    { id: 'star-eyes', name: '🤩', emoji: '🤩' },
    { id: 'heart-eyes', name: '😍', emoji: '😍' },
    { id: 'laugh', name: '😂', emoji: '😂' },
    { id: 'clap', name: '👏', emoji: '👏' },
    { id: 'rocket', name: '🚀', emoji: '🚀' },
    { id: 'lightning', name: '⚡', emoji: '⚡' }
  ];

  const addObject = (type: VideoObject['type'], shape: string) => {
    const newObject: VideoObject = {
      id: `object_${Date.now()}`,
      type,
      shape,
      x: 50,
      y: 50,
      width: type === 'sticker' ? 60 : 100,
      height: type === 'sticker' ? 60 : 100,
      color: '#3b82f6',
      opacity: 100,
      rotation: 0,
      startTime: 0,
      endTime: Math.min(5, videoDuration),
      borderWidth: 2,
      borderColor: '#1e40af',
      filled: true
    };
    
    onObjectsChange([...objects, newObject]);
    setSelectedObject(newObject.id);
  };

  const updateObject = (id: string, updates: Partial<VideoObject>) => {
    const updatedObjects = objects.map(obj =>
      obj.id === id ? { ...obj, ...updates } : obj
    );
    onObjectsChange(updatedObjects);
  };

  const removeObject = (id: string) => {
    const updatedObjects = objects.filter(obj => obj.id !== id);
    onObjectsChange(updatedObjects);
    if (selectedObject === id) {
      setSelectedObject(null);
    }
  };

  const selectedObjectData = objects.find(obj => obj.id === selectedObject);

  const categories = [
    { id: 'shapes', name: 'Shapes', items: shapes },
    { id: 'arrows', name: 'Arrows', items: arrows },
    { id: 'stickers', name: 'Stickers', items: stickers }
  ];

  const presetColors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#6b7280', '#000000'];

  return (
    <div className="bg-slate-800 rounded-xl p-6">
      <div className="flex items-center mb-6">
        <ImageIcon className="mr-2 text-green-400" size={20} />
        <h3 className="text-lg font-semibold">Objects & Graphics</h3>
      </div>

      {/* Category Tabs */}
      <div className="flex space-x-1 mb-6 bg-slate-700 rounded-lg p-1">
        {categories.map(category => (
          <button
            key={category.id}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex-1 ${
              activeCategory === category.id
                ? 'bg-green-500 text-white shadow-lg'
                : 'text-slate-300 hover:text-white hover:bg-slate-600'
            }`}
            onClick={() => setActiveCategory(category.id as any)}
            type="button"
          >
            {category.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Objects Library */}
        <div className="space-y-4">
          <h4 className="font-medium text-sm text-slate-300">Add {activeCategory}</h4>
          
          {/* Shapes/Arrows Grid */}
          {(activeCategory === 'shapes' || activeCategory === 'arrows') && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {(activeCategory === 'shapes' ? shapes : arrows).map(item => {
                const IconComponent = item.icon;
                return (
                  <button
                    key={item.id}
                    className="bg-slate-700 hover:bg-slate-600 rounded-lg p-4 transition-colors text-center"
                    onClick={() => addObject(activeCategory === 'shapes' ? 'shape' : 'arrow', item.id)}
                    type="button"
                  >
                    <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-2">
                      <IconComponent className="text-white" size={16} />
                    </div>
                    <p className="text-xs font-medium">{item.name}</p>
                  </button>
                );
              })}
            </div>
          )}

          {/* Stickers Grid */}
          {activeCategory === 'stickers' && (
            <div className="grid grid-cols-4 gap-3">
              {stickers.map(sticker => (
                <button
                  key={sticker.id}
                  className="bg-slate-700 hover:bg-slate-600 rounded-lg p-3 transition-colors text-center"
                  onClick={() => addObject('sticker', sticker.id)}
                  type="button"
                >
                  <div className="text-2xl mb-1">{sticker.emoji}</div>
                  <p className="text-xs">{sticker.name}</p>
                </button>
              ))}
            </div>
          )}

          {/* Added Objects List */}
          <div>
            <h4 className="font-medium text-sm text-slate-300 mb-3">Added Objects ({objects.length})</h4>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {objects.map(obj => (
                <div
                  key={obj.id}
                  className={`bg-slate-700 rounded-lg p-3 cursor-pointer border-2 transition-colors ${
                    selectedObject === obj.id 
                      ? 'border-green-500 bg-slate-600' 
                      : 'border-transparent hover:bg-slate-600'
                  }`}
                  onClick={() => setSelectedObject(obj.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-sm capitalize">
                        {obj.type} - {obj.shape?.replace('-', ' ')}
                      </p>
                      <p className="text-xs text-slate-400">
                        {obj.startTime.toFixed(1)}s - {obj.endTime.toFixed(1)}s
                      </p>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeObject(obj.id);
                      }}
                      className="text-red-400 hover:text-red-300 p-1"
                      type="button"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Object Editor */}
        {selectedObjectData && (
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-slate-300">Edit Object</h4>
            
            {/* Position & Size */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">X Position (%)</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={selectedObjectData.x}
                  onChange={(e) => updateObject(selectedObjectData.id, { x: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-xs text-slate-400 text-center">{selectedObjectData.x}%</div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Y Position (%)</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={selectedObjectData.y}
                  onChange={(e) => updateObject(selectedObjectData.id, { y: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-xs text-slate-400 text-center">{selectedObjectData.y}%</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">Width</label>
                <input
                  type="range"
                  min="20"
                  max="300"
                  value={selectedObjectData.width}
                  onChange={(e) => updateObject(selectedObjectData.id, { width: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-xs text-slate-400 text-center">{selectedObjectData.width}px</div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Height</label>
                <input
                  type="range"
                  min="20"
                  max="300"
                  value={selectedObjectData.height}
                  onChange={(e) => updateObject(selectedObjectData.id, { height: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-xs text-slate-400 text-center">{selectedObjectData.height}px</div>
              </div>
            </div>

            {/* Color Settings */}
            {selectedObjectData.type !== 'sticker' && (
              <>
                <div>
                  <label className="block text-sm font-medium mb-2">Fill Color</label>
                  <div className="flex space-x-2 mb-2">
                    {presetColors.map(color => (
                      <button
                        key={color}
                        className={`w-8 h-8 rounded-lg border-2 transition-all ${
                          selectedObjectData.color === color 
                            ? 'border-white scale-110' 
                            : 'border-slate-600 hover:scale-105'
                        }`}
                        style={{ backgroundColor: color }}
                        onClick={() => updateObject(selectedObjectData.id, { color })}
                        type="button"
                      />
                    ))}
                  </div>
                  <input
                    type="color"
                    value={selectedObjectData.color}
                    onChange={(e) => updateObject(selectedObjectData.id, { color: e.target.value })}
                    className="w-full h-10 rounded-lg border border-slate-600 bg-slate-700"
                  />
                </div>

                <div className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                  <div>
                    <p className="font-medium text-sm">Filled</p>
                    <p className="text-xs text-slate-400">Fill shape with color</p>
                  </div>
                  <button
                    className={`w-12 h-6 rounded-full transition-colors relative ${
                      selectedObjectData.filled ? 'bg-green-500' : 'bg-slate-600'
                    }`}
                    onClick={() => updateObject(selectedObjectData.id, { filled: !selectedObjectData.filled })}
                    type="button"
                  >
                    <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                      selectedObjectData.filled ? 'translate-x-7' : 'translate-x-1'
                    }`} />
                  </button>
                </div>

                {!selectedObjectData.filled && (
                  <>
                    <div>
                      <label className="block text-sm font-medium mb-2">Border Width</label>
                      <input
                        type="range"
                        min="1"
                        max="20"
                        value={selectedObjectData.borderWidth}
                        onChange={(e) => updateObject(selectedObjectData.id, { borderWidth: parseInt(e.target.value) })}
                        className="w-full"
                      />
                      <div className="text-xs text-slate-400 text-center">{selectedObjectData.borderWidth}px</div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">Border Color</label>
                      <input
                        type="color"
                        value={selectedObjectData.borderColor}
                        onChange={(e) => updateObject(selectedObjectData.id, { borderColor: e.target.value })}
                        className="w-full h-10 rounded-lg border border-slate-600 bg-slate-700"
                      />
                    </div>
                  </>
                )}
              </>
            )}

            {/* Opacity & Rotation */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">Opacity</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={selectedObjectData.opacity}
                  onChange={(e) => updateObject(selectedObjectData.id, { opacity: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-xs text-slate-400 text-center">{selectedObjectData.opacity}%</div>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Rotation</label>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={selectedObjectData.rotation}
                  onChange={(e) => updateObject(selectedObjectData.id, { rotation: parseInt(e.target.value) })}
                  className="w-full"
                />
                <div className="text-xs text-slate-400 text-center">{selectedObjectData.rotation}°</div>
              </div>
            </div>

            {/* Timing */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">Start Time (s)</label>
                <input
                  type="number"
                  min="0"
                  max={selectedObjectData.endTime - 0.1}
                  step="0.1"
                  value={selectedObjectData.startTime}
                  onChange={(e) => updateObject(selectedObjectData.id, { startTime: parseFloat(e.target.value) })}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">End Time (s)</label>
                <input
                  type="number"
                  min={selectedObjectData.startTime + 0.1}
                  max={videoDuration}
                  step="0.1"
                  value={selectedObjectData.endTime}
                  onChange={(e) => updateObject(selectedObjectData.id, { endTime: parseFloat(e.target.value) })}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}