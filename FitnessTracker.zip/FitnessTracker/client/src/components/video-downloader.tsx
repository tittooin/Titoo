import { useState, useCallback } from 'react';
import { Download, ExternalLink, AlertCircle, CheckCircle, Copy, Play, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface VideoDownloaderProps {
  onVideoSelect?: (video: any) => void;
}

interface VideoFormat {
  quality: string;
  format: string;
  size?: string;
  url?: string;
}

export function VideoDownloader({ onVideoSelect }: VideoDownloaderProps) {
  const [url, setUrl] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [videoInfo, setVideoInfo] = useState<any>(null);
  const [availableFormats, setAvailableFormats] = useState<VideoFormat[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [downloadHistory, setDownloadHistory] = useState<Array<{id: string, filename: string, size: string, timestamp: Date}>>([]);
  const { toast } = useToast();

  // Enhanced video extraction with multiple services
  const extractVideoInfo = useCallback(async (videoUrl: string) => {
    const youtubeMatch = videoUrl.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    const facebookMatch = videoUrl.match(/(?:facebook\.com|fb\.watch)\/.*\/videos\/(\d+)/);
    const instagramMatch = videoUrl.match(/(?:instagram\.com\/(?:p|reel)\/([A-Za-z0-9_-]+))/);
    const tiktokMatch = videoUrl.match(/(?:tiktok\.com\/@[^\/]+\/video\/(\d+))/);
    const twitterMatch = videoUrl.match(/(?:twitter\.com|x\.com)\/\w+\/status\/(\d+)/);
    
    if (youtubeMatch) {
      return {
        platform: 'YouTube',
        id: youtubeMatch[1],
        thumbnail: `https://img.youtube.com/vi/${youtubeMatch[1]}/maxresdefault.jpg`,
        title: `YouTube Video ${youtubeMatch[1]}`,
        downloadUrl: videoUrl,
        originalUrl: videoUrl
      };
    }
    
    if (facebookMatch) {
      return {
        platform: 'Facebook',
        id: facebookMatch[1],
        title: `Facebook Video ${facebookMatch[1]}`,
        downloadUrl: videoUrl,
        originalUrl: videoUrl
      };
    }

    if (instagramMatch) {
      return {
        platform: 'Instagram',
        id: instagramMatch[1],
        title: `Instagram Video ${instagramMatch[1]}`,
        downloadUrl: videoUrl,
        originalUrl: videoUrl
      };
    }

    if (tiktokMatch) {
      return {
        platform: 'TikTok',
        id: tiktokMatch[1],
        title: `TikTok Video ${tiktokMatch[1]}`,
        downloadUrl: videoUrl,
        originalUrl: videoUrl
      };
    }

    if (twitterMatch) {
      return {
        platform: 'Twitter/X',
        id: twitterMatch[1],
        title: `Twitter Video ${twitterMatch[1]}`,
        downloadUrl: videoUrl,
        originalUrl: videoUrl
      };
    }
    
    // For direct video URLs
    const filename = videoUrl.split('/').pop()?.split('?')[0] || 'video';
    return {
      platform: 'Direct',
      title: filename,
      downloadUrl: videoUrl,
      isDirect: true,
      originalUrl: videoUrl
    };
  }, []);

  // Simulate video format analysis (in real implementation, this would call actual APIs)
  const analyzeVideoFormats = useCallback(async (videoInfo: any) => {
    setIsAnalyzing(true);
    
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      let formats: VideoFormat[] = [];
      
      // Use reliable demo videos that are guaranteed to download
      const demoVideos = [
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
        'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4'
      ];
      
      if (videoInfo.platform === 'YouTube') {
        formats = [
          { quality: '1080p', format: 'MP4', size: '~15MB', url: demoVideos[0] },
          { quality: '720p', format: 'MP4', size: '~10MB', url: demoVideos[1] },
          { quality: '480p', format: 'MP4', size: '~8MB', url: demoVideos[2] },
          { quality: '360p', format: 'MP4', size: '~5MB', url: demoVideos[3] }
        ];
      } else if (videoInfo.platform === 'Facebook') {
        formats = [
          { quality: 'HD', format: 'MP4', size: '~15MB', url: demoVideos[0] },
          { quality: 'SD', format: 'MP4', size: '~8MB', url: demoVideos[2] }
        ];
      } else if (videoInfo.platform === 'Instagram') {
        formats = [
          { quality: 'HD', format: 'MP4', size: '~10MB', url: demoVideos[1] }
        ];
      } else if (videoInfo.platform === 'TikTok') {
        formats = [
          { quality: 'Original', format: 'MP4', size: '~8MB', url: demoVideos[2] },
          { quality: 'No Watermark', format: 'MP4', size: '~10MB', url: demoVideos[1] }
        ];
      } else if (videoInfo.platform === 'Twitter/X') {
        formats = [
          { quality: 'HD', format: 'MP4', size: '~15MB', url: demoVideos[3] }
        ];
      } else if (videoInfo.isDirect) {
        formats = [
          { quality: 'Original', format: 'Auto-detect', size: 'Unknown', url: videoInfo.downloadUrl }
        ];
      }
      
      setAvailableFormats(formats);
      
      toast({
        title: "Analysis Complete",
        description: `Found ${formats.length} available format${formats.length > 1 ? 's' : ''} for download.`,
      });
      
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze video formats. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  }, [toast]);

  const handleUrlSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter a video URL",
        variant: "destructive",
      });
      return;
    }

    setIsProcessing(true);
    setDownloadProgress(0);
    setVideoInfo(null);
    setAvailableFormats([]);

    try {
      const info = await extractVideoInfo(url);
      setVideoInfo(info);
      
      toast({
        title: "Video Detected",
        description: `Found ${info.platform} video. Analyzing available formats...`,
      });

      // Auto-analyze formats for supported platforms
      if (!info.isDirect) {
        await analyzeVideoFormats(info);
      }
      
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to process video URL",
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  }, [url, extractVideoInfo, analyzeVideoFormats, toast]);

  // Enhanced download function with format support
  const downloadVideo = useCallback(async (format: VideoFormat, filename: string) => {
    setIsProcessing(true);
    setDownloadProgress(0);
    
    try {
      toast({
        title: "Starting Download",
        description: `Downloading ${format.quality} ${format.format} video...`,
      });

      // Smart download system with CORS fallback
      if (format.url && format.url.startsWith('http')) {
        // Check if URL is likely to have CORS issues (demo videos should work)
        const isSameOrigin = format.url.includes(window.location.hostname);
        const isKnownWorkingDomain = format.url.includes('sample-videos.com') || 
                                   format.url.includes('commondatastorage.googleapis.com');
        
        if (isSameOrigin || isKnownWorkingDomain) {
          try {
            const response = await fetch(format.url, {
              method: 'GET',
              mode: 'cors',
            });

            if (!response.ok) {
              throw new Error(`Download failed: ${response.status} ${response.statusText}`);
            }

            const contentLength = response.headers.get('content-length');
            const total = contentLength ? parseInt(contentLength, 10) : 0;
            const contentType = response.headers.get('content-type') || 'video/mp4';

            let loaded = 0;
            const reader = response.body?.getReader();
            const chunks: Uint8Array[] = [];

            if (!reader) {
              throw new Error('Failed to get response reader');
            }

            // Read the stream with progress tracking
            while (true) {
              const { done, value } = await reader.read();
              
              if (done) break;
              
              chunks.push(value);
              loaded += value.length;
              
              if (total > 0) {
                const progress = (loaded / total) * 100;
                setDownloadProgress(progress);
              } else {
                setDownloadProgress(Math.min((loaded / (1024 * 1024)) * 5, 95));
              }
            }

            // Combine all chunks into final video file
            const totalLength = chunks.reduce((acc, chunk) => acc + chunk.length, 0);
            const combined = new Uint8Array(totalLength);
            let offset = 0;
            
            for (const chunk of chunks) {
              combined.set(chunk, offset);
              offset += chunk.length;
            }

            // Create blob with proper MIME type
            const blob = new Blob([combined], { type: contentType });
            
            // Generate proper filename
            const fileExtension = contentType.includes('mp4') ? 'mp4' : 
                                 contentType.includes('webm') ? 'webm' : 
                                 contentType.includes('avi') ? 'avi' : 'mp4';
            const downloadFilename = `${filename.replace(/[^a-zA-Z0-9_-]/g, '_')}_${format.quality}.${fileExtension}`;
            
            // Trigger download to device
            triggerDeviceDownload(blob, downloadFilename);

            // Validate download
            const fileSizeMB = (blob.size / (1024 * 1024)).toFixed(1);
            
            // Add to download history
            const downloadRecord = {
              id: Date.now().toString(),
              filename: downloadFilename,
              size: `${fileSizeMB}MB`,
              timestamp: new Date()
            };
            setDownloadHistory(prev => [downloadRecord, ...prev.slice(0, 4)]);

            toast({
              title: "Download Complete",
              description: `Video saved as "${downloadFilename}" (${fileSizeMB}MB)`,
            });

            // Auto-import for video editing
            if (onVideoSelect) {
              const file = new File([combined], downloadFilename, { type: contentType });
              const videoFile = {
                file,
                url: URL.createObjectURL(file),
                duration: 0
              };
              
              setTimeout(() => {
                toast({
                  title: "Auto Import Success",
                  description: "Downloaded video imported to editor!",
                });
                onVideoSelect(videoFile);
              }, 1500);
            }

          } catch (fetchError) {
            console.error('Direct download failed:', fetchError);
            // Fallback to browser download
            handleFallbackDownload(format.url, filename, format.quality);
          }
        } else {
          // Use fallback method for external URLs
          handleFallbackDownload(format.url, filename, format.quality);
        }
      } else {
        // For non-direct URLs, simulate download process (would integrate with real APIs)
        for (let i = 0; i <= 100; i += 10) {
          setDownloadProgress(i);
          await new Promise(resolve => setTimeout(resolve, 200));
        }
        
        toast({
          title: "Service Integration Required",
          description: `This feature requires integration with video download APIs. Currently showing demo for ${format.quality} ${format.format}.`,
          variant: "destructive",
        });
      }

      toast({
        title: "Download Complete",
        description: `${format.quality} ${format.format} video downloaded successfully!`,
      });
      
    } catch (error) {
      console.error('Download error:', error);
      toast({
        title: "Download Failed",
        description: `Failed to download ${format.quality} video. Please try another format or download manually.`,
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
      setDownloadProgress(0);
    }
  }, [onVideoSelect, toast]);

  const copyToClipboard = useCallback((text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "URL copied to clipboard",
    });
  }, [toast]);

  // Enhanced download trigger with cross-browser support
  const triggerDeviceDownload = useCallback((blob: Blob, filename: string) => {
    const downloadUrl = URL.createObjectURL(blob);
    
    // Check if browser supports download attribute
    const isSupported = 'download' in document.createElement('a');
    
    if (isSupported) {
      // Modern browsers - direct download
      const downloadLink = document.createElement('a');
      downloadLink.href = downloadUrl;
      downloadLink.download = filename;
      downloadLink.style.display = 'none';
      
      document.body.appendChild(downloadLink);
      downloadLink.click();
      
      setTimeout(() => {
        document.body.removeChild(downloadLink);
        URL.revokeObjectURL(downloadUrl);
      }, 100);
    } else {
      // Fallback for older browsers
      const newWindow = window.open(downloadUrl, '_blank');
      if (newWindow) {
        newWindow.focus();
        setTimeout(() => {
          URL.revokeObjectURL(downloadUrl);
        }, 5000);
      } else {
        // If popup blocked, copy to clipboard
        navigator.clipboard.writeText(downloadUrl);
        toast({
          title: "Download Ready",
          description: "Download link copied to clipboard. Please paste in new tab.",
        });
      }
    }
  }, [toast]);

  // Server-proxy download method that bypasses CORS
  const handleFallbackDownload = useCallback(async (url: string, filename: string, quality: string) => {
    try {
      // Use server proxy to download the video
      const downloadFilename = `${filename.replace(/[^a-zA-Z0-9_-]/g, '_')}_${quality}.mp4`;
      const proxyUrl = `/api/download-video?url=${encodeURIComponent(url)}&filename=${encodeURIComponent(downloadFilename)}`;
      
      // Create download link that goes through our server proxy
      const downloadLink = document.createElement('a');
      downloadLink.href = proxyUrl;
      downloadLink.download = downloadFilename;
      downloadLink.style.display = 'none';
      
      document.body.appendChild(downloadLink);
      downloadLink.click();
      
      // Cleanup
      setTimeout(() => {
        document.body.removeChild(downloadLink);
      }, 100);
      
      toast({
        title: "Download Started",
        description: "Video download initiated through proxy server. Check your downloads folder.",
      });
      
      // Add to download history
      const downloadRecord = {
        id: Date.now().toString(),
        filename: downloadFilename,
        size: 'Proxy',
        timestamp: new Date()
      };
      setDownloadHistory(prev => [downloadRecord, ...prev.slice(0, 4)]);
      
    } catch (error) {
      console.error('Proxy download failed:', error);
      
      // Fallback to direct URL copy
      navigator.clipboard.writeText(url);
      toast({
        title: "Download Link Copied",
        description: "Server proxy failed. URL copied - paste in new tab and right-click to save video.",
      });
    }
  }, [toast, setDownloadHistory]);



  return (
    <section className="mb-6">
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
        <div className="flex items-center mb-4">
          <Download className="text-green-400 mr-2" size={20} />
          <h3 className="text-lg font-semibold">Video Downloader</h3>
        </div>
        
        <form onSubmit={handleUrlSubmit} className="space-y-4">
          <div>
            <input
              type="url"
              placeholder="Paste any video URL (YouTube, TikTok, Instagram, Facebook, Twitter, direct links)..."
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-green-500 focus:border-transparent disabled:opacity-50"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={isProcessing || isAnalyzing}
            />
          </div>
          
          <button
            type="submit"
            className="w-full bg-green-500 hover:bg-green-600 px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isProcessing || isAnalyzing || !url.trim()}
          >
            {isProcessing || isAnalyzing ? (
              <>
                <Loader2 className="animate-spin mr-2" size={16} />
                {isAnalyzing ? 'Analyzing Formats...' : 'Processing...'}
              </>
            ) : (
              <>
                <ExternalLink className="mr-2" size={16} />
                Analyze & Get Download Options
              </>
            )}
          </button>
        </form>

        {/* Video Info & Download Options */}
        {videoInfo && (
          <div className="mt-6 p-4 bg-slate-700 rounded-lg">
            {/* Demo Notice */}
            <div className="bg-yellow-900/30 border border-yellow-500/30 rounded-lg p-3 mb-4">
              <div className="flex items-center">
                <div className="bg-yellow-500 text-black rounded-full w-5 h-5 flex items-center justify-center mr-2 text-xs font-bold">!</div>
                <span className="text-yellow-300 text-sm">Demo Mode: Downloads use sample videos to demonstrate functionality</span>
              </div>
            </div>
            
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h4 className="font-medium text-lg mb-1">{videoInfo.title}</h4>
                <div className="flex items-center gap-4 text-sm text-slate-400">
                  <span className="bg-slate-600 px-2 py-1 rounded text-xs font-medium">
                    {videoInfo.platform}
                  </span>
                  {isAnalyzing && (
                    <span className="flex items-center text-blue-400">
                      <Loader2 className="animate-spin mr-1" size={12} />
                      Analyzing formats...
                    </span>
                  )}
                </div>
              </div>
              <button
                onClick={() => copyToClipboard(videoInfo.originalUrl)}
                className="bg-slate-600 hover:bg-slate-500 p-2 rounded-lg transition-colors"
                type="button"
                title="Copy URL"
              >
                <Copy size={16} />
              </button>
            </div>

            {videoInfo.thumbnail && (
              <img 
                src={videoInfo.thumbnail} 
                alt="Video thumbnail"
                className="w-full h-32 object-cover rounded-lg mb-4"
                onError={(e) => { e.currentTarget.style.display = 'none'; }}
              />
            )}

            {/* Available Download Formats */}
            {availableFormats.length > 0 && (
              <div className="mb-4">
                <div className="bg-blue-900/30 border border-blue-500/30 rounded-lg p-3 mb-4">
                  <h6 className="text-sm font-medium text-blue-300 mb-2">Download Methods:</h6>
                  <div className="text-xs text-blue-200 space-y-1">
                    <p><span className="font-medium text-green-300">Direct:</span> Fast download if server allows direct access</p>
                    <p><span className="font-medium text-blue-300">Proxy:</span> Reliable download through our server (recommended)</p>
                  </div>
                </div>
                
                <h5 className="font-medium mb-3 flex items-center">
                  <Play className="mr-2 text-green-400" size={16} />
                  Available Download Formats
                </h5>
                <div className="space-y-2">
                  {availableFormats.map((format, index) => (
                    <div key={index} className="flex items-center justify-between bg-slate-600 rounded-lg p-3">
                      <div className="flex items-center space-x-3">
                        <div className="bg-green-500 text-white px-2 py-1 rounded text-xs font-bold">
                          {format.quality}
                        </div>
                        <div className="text-sm">
                          <span className="font-medium text-slate-200">{format.format}</span>
                          {format.size && (
                            <span className="text-slate-400 ml-2">({format.size})</span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => downloadVideo(format, videoInfo.title)}
                          className="bg-green-500 hover:bg-green-600 px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center"
                          disabled={isProcessing}
                          type="button"
                        >
                          <Download className="mr-1" size={14} />
                          Direct
                        </button>
                        <button
                          onClick={() => handleFallbackDownload(format.url || videoInfo.originalUrl, videoInfo.title, format.quality)}
                          className="bg-blue-500 hover:bg-blue-600 px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center"
                          disabled={isProcessing}
                          type="button"
                          title="Download via proxy server"
                        >
                          <Download className="mr-1" size={14} />
                          Proxy
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {isProcessing && downloadProgress > 0 && (
                  <div className="mt-4 p-3 bg-slate-600 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Downloading...</span>
                      <span className="text-sm text-slate-400">{Math.round(downloadProgress)}%</span>
                    </div>
                    <div className="bg-slate-700 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-full rounded-full transition-all duration-300" 
                        style={{ width: `${downloadProgress}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Direct Download for supported URLs */}
            {videoInfo.isDirect && availableFormats.length === 0 && !isAnalyzing && (
              <div className="mb-4">
                <button
                  onClick={() => downloadVideo({ quality: 'Original', format: 'MP4', url: videoInfo.downloadUrl }, videoInfo.title)}
                  className="w-full bg-blue-500 hover:bg-blue-600 px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center"
                  disabled={isProcessing}
                  type="button"
                >
                  <Download className="mr-2" size={16} />
                  Download Video Directly
                </button>
              </div>
            )}

            {/* Integration Status */}
            {!videoInfo.isDirect && availableFormats.length > 0 && (
              <div className="mb-4 p-3 bg-blue-900/20 border border-blue-500/30 rounded-lg">
                <div className="flex items-start">
                  <AlertCircle className="text-blue-400 mr-2 mt-0.5 flex-shrink-0" size={16} />
                  <div>
                    <p className="text-blue-400 text-sm font-medium">Integrated Download Service</p>
                    <p className="text-blue-300 text-xs mt-1">
                      This tool provides direct download functionality similar to y2mate.com and savefrom.net, keeping you on this site.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {/* Fallback Instructions */}
            {!videoInfo.isDirect && availableFormats.length === 0 && !isAnalyzing && (
              <div className="bg-slate-600 rounded-lg p-4">
                <h5 className="font-medium mb-3 flex items-center">
                  <AlertCircle className="mr-2 text-yellow-400" size={16} />
                  Alternative Download Methods
                </h5>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <a
                    href={`https://y2mate.com/download?url=${encodeURIComponent(videoInfo.originalUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-red-600 hover:bg-red-700 px-3 py-2 rounded text-sm font-medium transition-colors text-center"
                  >
                    Download via Y2mate
                  </a>
                  <a
                    href={`https://savefrom.net/?url=${encodeURIComponent(videoInfo.originalUrl)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-blue-600 hover:bg-blue-700 px-3 py-2 rounded text-sm font-medium transition-colors text-center"
                  >
                    Download via SaveFrom
                  </a>
                </div>
              </div>
            )}

            <div className="mt-4 p-3 bg-green-900/20 border border-green-500/30 rounded-lg">
              <div className="flex items-start">
                <CheckCircle className="text-green-400 mr-2 mt-0.5 flex-shrink-0" size={16} />
                <div>
                  <p className="text-green-400 text-sm font-medium">Auto Import</p>
                  <p className="text-green-300 text-xs mt-1">
                    Successfully downloaded videos will be automatically imported into the editor for immediate editing!
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Quick Demo & Test Videos */}
        <div className="mt-6 p-4 bg-slate-700 rounded-lg">
          <h4 className="font-medium text-sm mb-3 flex items-center">
            <Play className="mr-2 text-blue-400" size={16} />
            Test with Demo Videos
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => setUrl('https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4')}
              className="bg-blue-600 hover:bg-blue-700 px-3 py-2 rounded text-sm font-medium transition-colors text-left"
              type="button"
            >
              <div className="font-medium">Sample Video</div>
              <div className="text-xs opacity-75">720p • 1MB • Direct Download</div>
            </button>
            <button
              onClick={() => setUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4')}
              className="bg-purple-600 hover:bg-purple-700 px-3 py-2 rounded text-sm font-medium transition-colors text-left"
              type="button"
            >
              <div className="font-medium">Big Buck Bunny</div>
              <div className="text-xs opacity-75">1080p • HD Movie • Direct Download</div>
            </button>
          </div>
          <div className="mt-3 p-2 bg-slate-600 rounded text-xs text-slate-300">
            <strong>Try with social media URLs:</strong> Paste YouTube, TikTok, Instagram, Facebook, or Twitter video URLs to see format analysis and download options.
          </div>
        </div>

        {/* Download History */}
        {downloadHistory.length > 0 && (
          <div className="mt-6 p-4 bg-slate-700 rounded-lg">
            <h4 className="font-medium text-sm mb-3 flex items-center">
              <CheckCircle className="mr-2 text-green-400" size={16} />
              Recent Downloads
            </h4>
            <div className="space-y-2">
              {downloadHistory.map((download) => (
                <div key={download.id} className="flex items-center justify-between bg-slate-600 rounded p-2 text-sm">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span className="font-medium text-slate-200 truncate max-w-48">
                      {download.filename}
                    </span>
                    <span className="text-slate-400">({download.size})</span>
                  </div>
                  <span className="text-xs text-slate-400">
                    {download.timestamp.toLocaleTimeString()}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}