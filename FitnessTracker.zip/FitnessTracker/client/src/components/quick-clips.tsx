import { useState, useCallback } from 'react';
import { Clock, Zap, Download } from 'lucide-react';
import { type VideoFile, type VideoClip, formatTime } from '@/lib/video-utils';

interface QuickClipsProps {
  videoFile: VideoFile;
  onCreateClip: (clip: VideoClip, quality: string) => void;
  isProcessing: boolean;
}

interface PresetClip {
  duration: number;
  label: string;
  description: string;
  icon: typeof Clock;
  color: string;
}

export function QuickClips({ videoFile, onCreateClip, isProcessing }: QuickClipsProps) {
  const [selectedPreset, setSelectedPreset] = useState<number | null>(null);

  const presets: PresetClip[] = [
    {
      duration: 30,
      label: '30 Second Clip',
      description: 'Perfect for social media posts',
      icon: Clock,
      color: 'bg-blue-500 hover:bg-blue-600'
    },
    {
      duration: 45,
      label: '45 Second Clip',
      description: 'Ideal for Instagram stories',
      icon: Zap,
      color: 'bg-green-500 hover:bg-green-600'
    },
    {
      duration: 60,
      label: '60 Second Clip',
      description: 'Great for TikTok and YouTube shorts',
      icon: Download,
      color: 'bg-purple-500 hover:bg-purple-600'
    }
  ];

  const createQuickClip = useCallback((duration: number) => {
    const maxStartTime = Math.max(0, videoFile.duration - duration);
    
    // Try to find an engaging segment (simulated - in real app you'd analyze audio)
    // For now, we'll start from 10% into the video or beginning if video is short
    const startTime = videoFile.duration > duration + 10 
      ? Math.min(videoFile.duration * 0.1, maxStartTime)
      : 0;
    
    const clip: VideoClip = {
      startTime,
      endTime: Math.min(startTime + duration, videoFile.duration),
      duration: Math.min(duration, videoFile.duration - startTime)
    };

    setSelectedPreset(duration);
    onCreateClip(clip, '1080p');
  }, [videoFile, onCreateClip]);

  const canCreateClip = (duration: number) => {
    return videoFile.duration >= duration;
  };

  return (
    <section className="bg-slate-800 rounded-xl p-6 mb-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold mb-2 flex items-center">
          <Zap className="mr-2 text-yellow-400" size={20} />
          Quick Clips
        </h3>
        <p className="text-slate-300 text-sm">
          Generate popular clip lengths automatically from your video
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {presets.map((preset) => {
          const IconComponent = preset.icon;
          const canCreate = canCreateClip(preset.duration);
          const isCurrentlyProcessing = isProcessing && selectedPreset === preset.duration;
          
          return (
            <div
              key={preset.duration}
              className={`${canCreate ? 'bg-slate-700 hover:bg-slate-600' : 'bg-slate-800 opacity-50'} 
                border border-slate-600 rounded-lg p-4 cursor-pointer transition-all duration-200 
                ${!canCreate ? 'cursor-not-allowed' : ''}`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 ${canCreate ? preset.color : 'bg-slate-600'} rounded-lg flex items-center justify-center`}>
                  <IconComponent className="text-white" size={16} />
                </div>
                <span className="text-xs text-slate-400 font-mono">
                  {formatTime(preset.duration)}
                </span>
              </div>
              
              <h4 className="font-semibold mb-1 text-sm">{preset.label}</h4>
              <p className="text-slate-400 text-xs mb-3">{preset.description}</p>
              
              <button
                className={`w-full py-2 px-3 rounded-lg text-xs font-medium transition-colors 
                  ${canCreate && !isProcessing 
                    ? `${preset.color} text-white` 
                    : 'bg-slate-600 text-slate-400 cursor-not-allowed'
                  }`}
                onClick={() => canCreate && !isProcessing && createQuickClip(preset.duration)}
                disabled={!canCreate || isProcessing}
                type="button"
              >
                {isCurrentlyProcessing ? (
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white mr-2"></div>
                    Processing...
                  </div>
                ) : canCreate ? (
                  'Create Clip'
                ) : (
                  `Need ${formatTime(preset.duration)}+ video`
                )}
              </button>
            </div>
          );
        })}
      </div>

      <div className="mt-4 p-3 bg-slate-700 rounded-lg">
        <div className="flex items-start space-x-2">
          <Zap className="text-yellow-400 mt-0.5" size={14} />
          <div className="text-xs text-slate-300">
            <p className="font-medium mb-1">Smart Clipping:</p>
            <p>Quick clips automatically start from an engaging part of your video. You can always use the manual editor below for precise control.</p>
          </div>
        </div>
      </div>
    </section>
  );
}