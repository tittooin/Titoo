import { useState, useRef, useCallback, useEffect } from 'react';
import { Play, Scissors, Undo2 } from 'lucide-react';
import { TimelineControls } from './timeline-controls';
import { EditingToolbar } from './editing-toolbar';
import { TextEditor } from './text-editor';
import { EffectsPanel } from './effects-panel';
import { AudioPanel } from './audio-panel';
import { ObjectsPanel } from './objects-panel';
import { EnhancementPanel } from './enhancement-panel';
import { type VideoFile, type VideoClip } from '@/lib/video-utils';
import { useToast } from '@/hooks/use-toast';

interface VideoEditorProps {
  videoFile: VideoFile;
  onReset: () => void;
  onProcessVideo: (clip: VideoClip, quality: string, editingData?: any) => void;
  isProcessing: boolean;
}

export function VideoEditor({ videoFile, onReset, onProcessVideo, isProcessing }: VideoEditorProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [clip, setClip] = useState<VideoClip>({
    startTime: 0,
    endTime: Math.min(60, videoFile.duration), // Default to first 60 seconds or full duration
    duration: Math.min(60, videoFile.duration),
  });
  const [quality, setQuality] = useState('1080p');
  
  // Editing state
  const [activeTool, setActiveTool] = useState<string | null>(null);
  const [textOverlays, setTextOverlays] = useState<any[]>([]);
  const [effects, setEffects] = useState<any[]>([]);
  const [audioTracks, setAudioTracks] = useState<any[]>([]);
  const [objects, setObjects] = useState<any[]>([]);
  const [enhancements, setEnhancements] = useState({
    brightness: 0,
    contrast: 0,
    saturation: 0,
    hue: 0,
    gamma: 0,
    sharpness: 0,
    denoise: 0,
    stabilization: false,
    autoColor: false,
    autoExposure: false
  });
  
  const { toast } = useToast();

  // Update current time as video plays
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const updateTime = () => {
      setCurrentTime(video.currentTime);
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);

    video.addEventListener('timeupdate', updateTime);
    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);

    return () => {
      video.removeEventListener('timeupdate', updateTime);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
    };
  }, []);

  const handleSeek = useCallback((time: number) => {
    const video = videoRef.current;
    if (video) {
      video.currentTime = time;
      setCurrentTime(time);
    }
  }, []);

  const handlePreviewClip = useCallback(() => {
    const video = videoRef.current;
    if (!video) return;

    video.currentTime = clip.startTime;
    video.play();

    // Stop at end time
    const checkTime = () => {
      if (video.currentTime >= clip.endTime) {
        video.pause();
        return;
      }
      requestAnimationFrame(checkTime);
    };
    requestAnimationFrame(checkTime);

    toast({
      title: "Preview Started",
      description: `Playing clip from ${Math.floor(clip.startTime)}s to ${Math.floor(clip.endTime)}s`,
    });
  }, [clip, toast]);

  const handleProcessVideo = useCallback(() => {
    if (clip.duration < 1) {
      toast({
        title: "Invalid Clip",
        description: "Please select a clip that's at least 1 second long.",
        variant: "destructive",
      });
      return;
    }

    if (clip.duration > 300) { // 5 minutes
      toast({
        title: "Clip Too Long",
        description: "Please select a clip that's less than 5 minutes long.",
        variant: "destructive",
      });
      return;
    }

    // Pass editing data along with clip
    const editingData = {
      textOverlays,
      effects,
      audioTracks,
      objects,
      enhancements
    };

    onProcessVideo(clip, quality, editingData);
  }, [clip, quality, textOverlays, effects, audioTracks, objects, enhancements, onProcessVideo, toast]);

  const renderEditingPanel = () => {
    switch (activeTool) {
      case 'text':
        return (
          <TextEditor
            textOverlays={textOverlays}
            onTextOverlaysChange={setTextOverlays}
            videoDuration={videoFile.duration}
          />
        );
      case 'effects':
        return (
          <EffectsPanel
            effects={effects}
            onEffectsChange={setEffects}
          />
        );
      case 'objects':
        return (
          <ObjectsPanel
            objects={objects}
            onObjectsChange={setObjects}
            videoDuration={videoFile.duration}
          />
        );
      case 'audio':
        return (
          <AudioPanel
            audioTracks={audioTracks}
            onAudioTracksChange={setAudioTracks}
            videoDuration={videoFile.duration}
          />
        );
      case 'music':
        return (
          <AudioPanel
            audioTracks={audioTracks}
            onAudioTracksChange={setAudioTracks}
            videoDuration={videoFile.duration}
          />
        );
      case 'enhance':
        return (
          <EnhancementPanel
            enhancements={enhancements}
            onEnhancementsChange={setEnhancements}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      <section className="bg-slate-800 rounded-xl p-6">
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">Video Editor</h2>
          <p className="text-slate-300 text-sm">Select the portion of your video you want to keep</p>
        </div>

        {/* Video Player */}
        <div className="bg-black rounded-lg mb-6 relative overflow-hidden">
          <video
            ref={videoRef}
            className="w-full h-auto max-h-96"
            controls
            src={videoFile.url}
            style={{ maxHeight: window.innerWidth < 768 ? '250px' : '400px' }}
          />
        </div>

        {/* Timeline Controls */}
        <TimelineControls
          videoDuration={videoFile.duration}
          currentTime={currentTime}
          clip={clip}
          onClipChange={setClip}
          onSeek={handleSeek}
        />

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 mt-6">
          <button
            className="bg-blue-500 hover:bg-blue-600 px-6 py-3 rounded-lg font-medium transition-colors flex-1 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handlePreviewClip}
            disabled={isProcessing}
            type="button"
          >
            <Play className="mr-2" size={16} />
            Preview Clip
          </button>
          <button
            className="bg-green-500 hover:bg-green-600 px-6 py-3 rounded-lg font-medium transition-colors flex-1 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={handleProcessVideo}
            disabled={isProcessing}
            type="button"
          >
            <Scissors className="mr-2" size={16} />
            {isProcessing ? 'Processing...' : 'Trim & Download'}
          </button>
          <button
            className="bg-slate-600 hover:bg-slate-500 px-4 py-3 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            onClick={onReset}
            disabled={isProcessing}
            type="button"
          >
            <Undo2 size={16} />
          </button>
        </div>
      </section>

      {/* Editing Toolbar */}
      <EditingToolbar
        onToolSelect={setActiveTool}
        activeTool={activeTool}
      />

      {/* Active Editing Panel */}
      {renderEditingPanel()}
    </div>
  );
}
