import { useState, useCallback } from 'react';
import { Link, Download, AlertCircle } from 'lucide-react';
import { isValidVideoUrl, downloadVideoFromUrl, getVideoDuration, type VideoFile } from '@/lib/video-utils';
import { useToast } from '@/hooks/use-toast';

interface UrlInputProps {
  onVideoSelect: (video: VideoFile) => void;
}

export function UrlInput({ onVideoSelect }: UrlInputProps) {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const { toast } = useToast();

  const handleUrlSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url.trim()) {
      toast({
        title: "URL Required",
        description: "Please enter a YouTube or Facebook video URL",
        variant: "destructive",
      });
      return;
    }

    if (!isValidVideoUrl(url)) {
      toast({
        title: "Invalid URL",
        description: "Please enter a valid YouTube or Facebook video URL",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setDownloadProgress(0);

    try {
      toast({
        title: "Processing URL",
        description: "Attempting to fetch video from URL...",
      });

      // First try to download the video
      const file = await downloadVideoFromUrl(url, (progress) => {
        setDownloadProgress(progress);
      });

      const duration = await getVideoDuration(file);
      const videoFile: VideoFile = {
        file,
        url: URL.createObjectURL(file),
        duration,
      };
      
      onVideoSelect(videoFile);
      setUrl('');
      
      toast({
        title: "Video Imported Successfully",
        description: "Your video is ready for editing!",
      });
    } catch (error) {
      console.error('Download error:', error);
      
      // Show detailed error message with alternatives
      toast({
        title: "Import Failed",
        description: "Due to CORS restrictions, direct downloads aren't supported. Please download the video manually and use file upload instead.",
        variant: "destructive",
      });
      
      // Provide helpful suggestions
      setTimeout(() => {
        toast({
          title: "Alternative Solutions",
          description: "1. Use 'Save video as...' to download the video\n2. Try browser extensions like Video DownloadHelper\n3. Use online video downloaders",
        });
      }, 2000);
    } finally {
      setIsLoading(false);
      setDownloadProgress(0);
    }
  }, [url, onVideoSelect, toast]);

  return (
    <section className="mb-6">
      <div className="bg-slate-800 rounded-xl border border-slate-700 p-6">
        <div className="flex items-center mb-4">
          <Link className="text-blue-400 mr-2" size={20} />
          <h3 className="text-lg font-semibold">Import from URL</h3>
        </div>
        
        <form onSubmit={handleUrlSubmit} className="space-y-4">
          <div className="space-y-3">
            <input
              type="url"
              placeholder="Paste video URL here (direct .mp4/.webm links work best)..."
              className="w-full bg-slate-700 border border-slate-600 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              disabled={isLoading}
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setUrl('https://sample-videos.com/zip/10/mp4/SampleVideo_1280x720_1mb.mp4')}
                className="bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-xs font-medium transition-colors"
                disabled={isLoading}
              >
                Try Demo Video
              </button>
              <button
                type="button"
                onClick={() => setUrl('https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4')}
                className="bg-purple-600 hover:bg-purple-700 px-3 py-1 rounded text-xs font-medium transition-colors"
                disabled={isLoading}
              >
                Big Buck Bunny
              </button>
            </div>
          </div>
          
          {isLoading && (
            <div className="space-y-2">
              <div className="bg-slate-700 rounded-full h-2">
                <div 
                  className="bg-blue-500 h-full rounded-full transition-all duration-300" 
                  style={{ width: `${downloadProgress}%` }}
                />
              </div>
              <p className="text-sm text-slate-400 text-center">
                Downloading video... {Math.round(downloadProgress)}%
              </p>
            </div>
          )}
          
          <div className="flex items-start space-x-3 p-3 bg-slate-700 rounded-lg">
            <AlertCircle className="text-yellow-400 mt-0.5" size={16} />
            <div className="text-sm text-slate-300">
              <p className="font-medium mb-1">URL Import Info:</p>
              <p>Direct video file URLs work best. For YouTube/Facebook videos, please download manually and use file upload instead due to platform restrictions.</p>
            </div>
          </div>
          
          <button
            type="submit"
            className="w-full bg-blue-500 hover:bg-blue-600 px-4 py-3 rounded-lg font-medium transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Downloading...
              </>
            ) : (
              <>
                <Download className="mr-2" size={16} />
                Download & Import Video
              </>
            )}
          </button>
        </form>
        
        <div className="mt-4 text-xs text-slate-400">
          <p>Works best with: Direct video URLs (.mp4, .webm, .avi)</p>
          <p>Example: https://example.com/video.mp4</p>
        </div>
      </div>
    </section>
  );
}