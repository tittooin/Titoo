import { Settings } from 'lucide-react';

interface ProcessingModalProps {
  isVisible: boolean;
  progress: number;
}

export function ProcessingModal({ isVisible, progress }: ProcessingModalProps) {
  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-slate-800 rounded-xl p-6 w-full max-w-md mx-4">
        <div className="text-center">
          <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Settings className="text-white animate-spin" size={24} />
          </div>
          <h3 className="text-lg font-semibold mb-2">Processing Video</h3>
          <p className="text-slate-300 text-sm mb-4">Please wait while we trim your video...</p>
          
          {/* Progress Bar */}
          <div className="bg-slate-700 rounded-full h-2 mb-4">
            <div 
              className="bg-blue-500 h-full rounded-full transition-all duration-300" 
              style={{ width: `${progress}%` }}
            />
          </div>
          
          <div className="text-sm text-slate-400">
            Processing video... {Math.round(progress)}%
          </div>
        </div>
      </div>
    </div>
  );
}
