import { useState, useCallback, useEffect } from 'react';
import { Crosshair } from 'lucide-react';
import { formatTime, parseTimeInput, timeToInputValue, type VideoClip } from '@/lib/video-utils';

interface TimelineControlsProps {
  videoDuration: number;
  currentTime: number;
  clip: VideoClip;
  onClipChange: (clip: VideoClip) => void;
  onSeek: (time: number) => void;
}

export function TimelineControls({
  videoDuration,
  currentTime,
  clip,
  onClipChange,
  onSeek,
}: TimelineControlsProps) {
  const [startTimeInput, setStartTimeInput] = useState('');
  const [endTimeInput, setEndTimeInput] = useState('');

  // Update input values when clip changes
  useEffect(() => {
    setStartTimeInput(timeToInputValue(clip.startTime));
    setEndTimeInput(timeToInputValue(clip.endTime));
  }, [clip.startTime, clip.endTime]);

  const handleStartTimeChange = useCallback((value: string) => {
    setStartTimeInput(value);
    const seconds = parseTimeInput(value);
    if (seconds >= 0 && seconds < clip.endTime && seconds <= videoDuration) {
      const newClip = {
        ...clip,
        startTime: seconds,
        duration: clip.endTime - seconds,
      };
      onClipChange(newClip);
    }
  }, [clip, videoDuration, onClipChange]);

  const handleEndTimeChange = useCallback((value: string) => {
    setEndTimeInput(value);
    const seconds = parseTimeInput(value);
    if (seconds > clip.startTime && seconds <= videoDuration) {
      const newClip = {
        ...clip,
        endTime: seconds,
        duration: seconds - clip.startTime,
      };
      onClipChange(newClip);
    }
  }, [clip, videoDuration, onClipChange]);

  const setCurrentTimeAsStart = useCallback(() => {
    if (currentTime < clip.endTime) {
      const newClip = {
        ...clip,
        startTime: currentTime,
        duration: clip.endTime - currentTime,
      };
      onClipChange(newClip);
    }
  }, [currentTime, clip, onClipChange]);

  const setCurrentTimeAsEnd = useCallback(() => {
    if (currentTime > clip.startTime) {
      const newClip = {
        ...clip,
        endTime: currentTime,
        duration: currentTime - clip.startTime,
      };
      onClipChange(newClip);
    }
  }, [currentTime, clip, onClipChange]);

  const handleTimelineClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const percentage = clickX / rect.width;
    const time = percentage * videoDuration;
    onSeek(time);
  }, [videoDuration, onSeek]);

  const playbackProgress = (currentTime / videoDuration) * 100;
  const clipStartPercentage = (clip.startTime / videoDuration) * 100;
  const clipWidthPercentage = (clip.duration / videoDuration) * 100;

  return (
    <div className="space-y-4">
      <div className="bg-slate-700 rounded-lg p-4">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm font-medium">Timeline</span>
          <span className="text-sm text-slate-300">
            {formatTime(currentTime)} / {formatTime(videoDuration)}
          </span>
        </div>
        
        {/* Timeline Scrubber */}
        <div className="relative">
          <div 
            className="h-2 bg-slate-600 rounded-full relative overflow-hidden cursor-pointer"
            onClick={handleTimelineClick}
          >
            <div 
              className="h-full bg-blue-500 rounded-full transition-all duration-150" 
              style={{ width: `${playbackProgress}%` }}
            />
            <div 
              className="absolute top-0 h-full bg-blue-400 bg-opacity-30 rounded-full" 
              style={{ 
                left: `${clipStartPercentage}%`, 
                width: `${clipWidthPercentage}%` 
              }}
            />
          </div>
          {/* Timeline markers */}
          <div className="flex justify-between mt-2 text-xs text-slate-400">
            <span>0:00</span>
            <span>{formatTime(videoDuration * 0.25)}</span>
            <span>{formatTime(videoDuration * 0.5)}</span>
            <span>{formatTime(videoDuration * 0.75)}</span>
            <span>{formatTime(videoDuration)}</span>
          </div>
        </div>
      </div>

      {/* Clip Selection Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-700 rounded-lg p-4">
          <label className="block text-sm font-medium mb-2">Start Time</label>
          <div className="flex items-center space-x-2">
            <input
              type="text"
              className="bg-slate-600 border border-slate-500 rounded-lg px-3 py-2 text-sm w-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={startTimeInput}
              onChange={(e) => handleStartTimeChange(e.target.value)}
              placeholder="mm:ss"
            />
            <button
              className="bg-slate-600 hover:bg-slate-500 p-2 rounded-lg transition-colors"
              onClick={setCurrentTimeAsStart}
              title="Use current playback time"
              type="button"
            >
              <Crosshair size={16} />
            </button>
          </div>
        </div>
        <div className="bg-slate-700 rounded-lg p-4">
          <label className="block text-sm font-medium mb-2">End Time</label>
          <div className="flex items-center space-x-2">
            <input
              type="text"
              className="bg-slate-600 border border-slate-500 rounded-lg px-3 py-2 text-sm w-full focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={endTimeInput}
              onChange={(e) => handleEndTimeChange(e.target.value)}
              placeholder="mm:ss"
            />
            <button
              className="bg-slate-600 hover:bg-slate-500 p-2 rounded-lg transition-colors"
              onClick={setCurrentTimeAsEnd}
              title="Use current playback time"
              type="button"
            >
              <Crosshair size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Clip Info */}
      <div className="bg-slate-700 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-sm font-medium">Selected Clip Duration:</span>
            <span className="text-blue-400 ml-2">{formatTime(clip.duration)}</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Quality:</span>
            <select className="bg-slate-600 border border-slate-500 rounded px-2 py-1 text-xs focus:ring-2 focus:ring-blue-500 focus:border-transparent">
              <option value="480p">480p</option>
              <option value="720p">720p</option>
              <option value="1080p" selected>1080p</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
