import { useState, useCallback } from 'react';
import { Plus, Trash2, Type, AlignLeft, AlignCenter, AlignRight, Bold, Italic } from 'lucide-react';

interface TextOverlay {
  id: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  color: string;
  fontFamily: string;
  fontWeight: string;
  fontStyle: string;
  textAlign: string;
  startTime: number;
  endTime: number;
}

interface TextEditorProps {
  textOverlays: TextOverlay[];
  onTextOverlaysChange: (overlays: TextOverlay[]) => void;
  videoDuration: number;
}

export function TextEditor({ textOverlays, onTextOverlaysChange, videoDuration }: TextEditorProps) {
  const [selectedOverlay, setSelectedOverlay] = useState<string | null>(null);

  const addTextOverlay = useCallback(() => {
    const newOverlay: TextOverlay = {
      id: `text_${Date.now()}`,
      text: 'Enter your text',
      x: 50,
      y: 50,
      fontSize: 32,
      color: '#ffffff',
      fontFamily: 'Arial',
      fontWeight: 'bold',
      fontStyle: 'normal',
      textAlign: 'center',
      startTime: 0,
      endTime: Math.min(5, videoDuration)
    };
    
    onTextOverlaysChange([...textOverlays, newOverlay]);
    setSelectedOverlay(newOverlay.id);
  }, [textOverlays, onTextOverlaysChange, videoDuration]);

  const updateOverlay = useCallback((id: string, updates: Partial<TextOverlay>) => {
    const updatedOverlays = textOverlays.map(overlay =>
      overlay.id === id ? { ...overlay, ...updates } : overlay
    );
    onTextOverlaysChange(updatedOverlays);
  }, [textOverlays, onTextOverlaysChange]);

  const removeOverlay = useCallback((id: string) => {
    const updatedOverlays = textOverlays.filter(overlay => overlay.id !== id);
    onTextOverlaysChange(updatedOverlays);
    if (selectedOverlay === id) {
      setSelectedOverlay(null);
    }
  }, [textOverlays, onTextOverlaysChange, selectedOverlay]);

  const selectedOverlayData = textOverlays.find(overlay => overlay.id === selectedOverlay);

  const fontFamilies = ['Arial', 'Helvetica', 'Times New Roman', 'Georgia', 'Verdana', 'Impact', 'Comic Sans MS'];
  const presetColors = ['#ffffff', '#000000', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff'];

  return (
    <div className="bg-slate-800 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center">
          <Type className="mr-2 text-blue-400" size={20} />
          <h3 className="text-lg font-semibold">Text Overlays</h3>
        </div>
        <button
          onClick={addTextOverlay}
          className="bg-blue-500 hover:bg-blue-600 px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center"
          type="button"
        >
          <Plus className="mr-2" size={16} />
          Add Text
        </button>
      </div>

      {textOverlays.length === 0 ? (
        <div className="text-center py-8 text-slate-400">
          <Type size={48} className="mx-auto mb-4 opacity-50" />
          <p>No text overlays added yet</p>
          <p className="text-sm">Click "Add Text" to get started</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Text Overlays List */}
          <div className="space-y-3">
            <h4 className="font-medium text-sm text-slate-300">Text Layers</h4>
            {textOverlays.map((overlay) => (
              <div
                key={overlay.id}
                className={`bg-slate-700 rounded-lg p-3 cursor-pointer border-2 transition-colors ${
                  selectedOverlay === overlay.id 
                    ? 'border-blue-500 bg-slate-600' 
                    : 'border-transparent hover:bg-slate-600'
                }`}
                onClick={() => setSelectedOverlay(overlay.id)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-sm truncate">{overlay.text}</p>
                    <p className="text-xs text-slate-400">
                      {overlay.startTime.toFixed(1)}s - {overlay.endTime.toFixed(1)}s
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      removeOverlay(overlay.id);
                    }}
                    className="text-red-400 hover:text-red-300 p-1"
                    type="button"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Text Editor Panel */}
          {selectedOverlayData && (
            <div className="space-y-4">
              <h4 className="font-medium text-sm text-slate-300">Edit Text</h4>
              
              {/* Text Content */}
              <div>
                <label className="block text-sm font-medium mb-2">Text</label>
                <textarea
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows={3}
                  value={selectedOverlayData.text}
                  onChange={(e) => updateOverlay(selectedOverlayData.id, { text: e.target.value })}
                  placeholder="Enter your text"
                />
              </div>

              {/* Font Settings */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-2">Font Family</label>
                  <select
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    value={selectedOverlayData.fontFamily}
                    onChange={(e) => updateOverlay(selectedOverlayData.id, { fontFamily: e.target.value })}
                  >
                    {fontFamilies.map(font => (
                      <option key={font} value={font}>{font}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Font Size</label>
                  <input
                    type="range"
                    min="12"
                    max="72"
                    value={selectedOverlayData.fontSize}
                    onChange={(e) => updateOverlay(selectedOverlayData.id, { fontSize: parseInt(e.target.value) })}
                    className="w-full"
                  />
                  <div className="text-xs text-slate-400 text-center">{selectedOverlayData.fontSize}px</div>
                </div>
              </div>

              {/* Style Buttons */}
              <div>
                <label className="block text-sm font-medium mb-2">Style</label>
                <div className="flex space-x-2">
                  <button
                    className={`p-2 rounded-lg border transition-colors ${
                      selectedOverlayData.fontWeight === 'bold'
                        ? 'bg-blue-500 border-blue-500 text-white'
                        : 'bg-slate-700 border-slate-600 hover:bg-slate-600'
                    }`}
                    onClick={() => updateOverlay(selectedOverlayData.id, { 
                      fontWeight: selectedOverlayData.fontWeight === 'bold' ? 'normal' : 'bold' 
                    })}
                    type="button"
                  >
                    <Bold size={16} />
                  </button>
                  <button
                    className={`p-2 rounded-lg border transition-colors ${
                      selectedOverlayData.fontStyle === 'italic'
                        ? 'bg-blue-500 border-blue-500 text-white'
                        : 'bg-slate-700 border-slate-600 hover:bg-slate-600'
                    }`}
                    onClick={() => updateOverlay(selectedOverlayData.id, { 
                      fontStyle: selectedOverlayData.fontStyle === 'italic' ? 'normal' : 'italic' 
                    })}
                    type="button"
                  >
                    <Italic size={16} />
                  </button>
                </div>
              </div>

              {/* Text Alignment */}
              <div>
                <label className="block text-sm font-medium mb-2">Alignment</label>
                <div className="flex space-x-2">
                  {[
                    { value: 'left', icon: AlignLeft },
                    { value: 'center', icon: AlignCenter },
                    { value: 'right', icon: AlignRight }
                  ].map(({ value, icon: Icon }) => (
                    <button
                      key={value}
                      className={`p-2 rounded-lg border transition-colors ${
                        selectedOverlayData.textAlign === value
                          ? 'bg-blue-500 border-blue-500 text-white'
                          : 'bg-slate-700 border-slate-600 hover:bg-slate-600'
                      }`}
                      onClick={() => updateOverlay(selectedOverlayData.id, { textAlign: value })}
                      type="button"
                    >
                      <Icon size={16} />
                    </button>
                  ))}
                </div>
              </div>

              {/* Color Picker */}
              <div>
                <label className="block text-sm font-medium mb-2">Text Color</label>
                <div className="flex space-x-2 mb-2">
                  {presetColors.map(color => (
                    <button
                      key={color}
                      className={`w-8 h-8 rounded-lg border-2 transition-all ${
                        selectedOverlayData.color === color 
                          ? 'border-white scale-110' 
                          : 'border-slate-600 hover:scale-105'
                      }`}
                      style={{ backgroundColor: color }}
                      onClick={() => updateOverlay(selectedOverlayData.id, { color })}
                      type="button"
                    />
                  ))}
                </div>
                <input
                  type="color"
                  value={selectedOverlayData.color}
                  onChange={(e) => updateOverlay(selectedOverlayData.id, { color: e.target.value })}
                  className="w-full h-10 rounded-lg border border-slate-600 bg-slate-700"
                />
              </div>

              {/* Position */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-2">X Position (%)</label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={selectedOverlayData.x}
                    onChange={(e) => updateOverlay(selectedOverlayData.id, { x: parseInt(e.target.value) })}
                    className="w-full"
                  />
                  <div className="text-xs text-slate-400 text-center">{selectedOverlayData.x}%</div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Y Position (%)</label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={selectedOverlayData.y}
                    onChange={(e) => updateOverlay(selectedOverlayData.id, { y: parseInt(e.target.value) })}
                    className="w-full"
                  />
                  <div className="text-xs text-slate-400 text-center">{selectedOverlayData.y}%</div>
                </div>
              </div>

              {/* Timing */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium mb-2">Start Time (s)</label>
                  <input
                    type="number"
                    min="0"
                    max={selectedOverlayData.endTime - 0.1}
                    step="0.1"
                    value={selectedOverlayData.startTime}
                    onChange={(e) => updateOverlay(selectedOverlayData.id, { startTime: parseFloat(e.target.value) })}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">End Time (s)</label>
                  <input
                    type="number"
                    min={selectedOverlayData.startTime + 0.1}
                    max={videoDuration}
                    step="0.1"
                    value={selectedOverlayData.endTime}
                    onChange={(e) => updateOverlay(selectedOverlayData.id, { endTime: parseFloat(e.target.value) })}
                    className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}