import { Zap, Shield, Smartphone } from 'lucide-react';

export function FeaturesSection() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <div className="bg-slate-800 rounded-xl p-6 text-center">
        <div className="w-12 h-12 bg-blue-500 rounded-lg flex items-center justify-center mx-auto mb-4">
          <Zap className="text-white" size={24} />
        </div>
        <h3 className="font-semibold mb-2">Quick Clips</h3>
        <p className="text-slate-300 text-sm">Generate 30, 45, or 60-second clips instantly with one click</p>
      </div>
      <div className="bg-slate-800 rounded-xl p-6 text-center">
        <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mx-auto mb-4">
          <Shield className="text-white" size={24} />
        </div>
        <h3 className="font-semibold mb-2">URL Import</h3>
        <p className="text-slate-300 text-sm">Import videos directly from YouTube and Facebook URLs</p>
      </div>
      <div className="bg-slate-800 rounded-xl p-6 text-center">
        <div className="w-12 h-12 bg-purple-500 rounded-lg flex items-center justify-center mx-auto mb-4">
          <Smartphone className="text-white" size={24} />
        </div>
        <h3 className="font-semibold mb-2">Privacy First</h3>
        <p className="text-slate-300 text-sm">All processing happens in your browser - videos never leave your device</p>
      </div>
    </section>
  );
}
