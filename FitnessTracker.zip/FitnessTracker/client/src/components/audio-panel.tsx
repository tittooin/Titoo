import { useState, useRef } from 'react';
import { Volume2, Music, Upload, Play, Pause, Trash2, VolumeX } from 'lucide-react';

interface AudioTrack {
  id: string;
  name: string;
  type: 'sound-effect' | 'music' | 'voiceover';
  file?: File;
  url?: string;
  volume: number;
  startTime: number;
  duration: number;
  loop: boolean;
  fadeIn: number;
  fadeOut: number;
}

interface AudioPanelProps {
  audioTracks: AudioTrack[];
  onAudioTracksChange: (tracks: AudioTrack[]) => void;
  videoDuration: number;
}

export function AudioPanel({ audioTracks, onAudioTracksChange, videoDuration }: AudioPanelProps) {
  const [selectedTrack, setSelectedTrack] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'effects' | 'music' | 'voiceover'>('effects');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const soundEffects = [
    { name: 'Applause', url: '/assets/audio/applause.mp3', duration: 3.5 },
    { name: 'Whoosh', url: '/assets/audio/whoosh.mp3', duration: 1.2 },
    { name: 'Pop', url: '/assets/audio/pop.mp3', duration: 0.5 },
    { name: 'Ding', url: '/assets/audio/ding.mp3', duration: 0.8 },
    { name: 'Swoosh', url: '/assets/audio/swoosh.mp3', duration: 1.0 },
    { name: 'Click', url: '/assets/audio/click.mp3', duration: 0.3 }
  ];

  const backgroundMusic = [
    { name: 'Upbeat Corporate', url: '/assets/music/upbeat.mp3', duration: 180 },
    { name: 'Chill Lo-Fi', url: '/assets/music/lofi.mp3', duration: 165 },
    { name: 'Energetic Rock', url: '/assets/music/rock.mp3', duration: 210 },
    { name: 'Peaceful Ambient', url: '/assets/music/ambient.mp3', duration: 240 },
    { name: 'Funky Groove', url: '/assets/music/funk.mp3', duration: 195 }
  ];

  const addAudioTrack = (name: string, type: AudioTrack['type'], url?: string, file?: File, duration?: number) => {
    const newTrack: AudioTrack = {
      id: `audio_${Date.now()}`,
      name,
      type,
      url,
      file,
      volume: type === 'music' ? 30 : 70,
      startTime: 0,
      duration: duration || 10,
      loop: type === 'music',
      fadeIn: type === 'music' ? 2 : 0,
      fadeOut: type === 'music' ? 2 : 0
    };
    
    onAudioTracksChange([...audioTracks, newTrack]);
    setSelectedTrack(newTrack.id);
  };

  const updateTrack = (id: string, updates: Partial<AudioTrack>) => {
    const updatedTracks = audioTracks.map(track =>
      track.id === id ? { ...track, ...updates } : track
    );
    onAudioTracksChange(updatedTracks);
  };

  const removeTrack = (id: string) => {
    const updatedTracks = audioTracks.filter(track => track.id !== id);
    onAudioTracksChange(updatedTracks);
    if (selectedTrack === id) {
      setSelectedTrack(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && file.type.startsWith('audio/')) {
      addAudioTrack(file.name, activeTab === 'music' ? 'music' : 'sound-effect', undefined, file);
    }
  };

  const selectedTrackData = audioTracks.find(track => track.id === selectedTrack);

  const tabs = [
    { id: 'effects', name: 'Sound Effects', icon: Volume2 },
    { id: 'music', name: 'Background Music', icon: Music },
    { id: 'voiceover', name: 'Voiceover', icon: Volume2 }
  ];

  return (
    <div className="bg-slate-800 rounded-xl p-6">
      <div className="flex items-center mb-6">
        <Volume2 className="mr-2 text-orange-400" size={20} />
        <h3 className="text-lg font-semibold">Audio & Music</h3>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 mb-6 bg-slate-700 rounded-lg p-1">
        {tabs.map(tab => {
          const IconComponent = tab.icon;
          return (
            <button
              key={tab.id}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex-1 flex items-center justify-center ${
                activeTab === tab.id
                  ? 'bg-orange-500 text-white shadow-lg'
                  : 'text-slate-300 hover:text-white hover:bg-slate-600'
              }`}
              onClick={() => setActiveTab(tab.id as any)}
              type="button"
            >
              <IconComponent className="mr-2" size={16} />
              {tab.name}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Audio Library / Upload */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="font-medium text-sm text-slate-300">
              {activeTab === 'effects' && 'Sound Effects Library'}
              {activeTab === 'music' && 'Background Music Library'}
              {activeTab === 'voiceover' && 'Upload Voiceover'}
            </h4>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-orange-500 hover:bg-orange-600 px-3 py-1 rounded-lg text-xs font-medium transition-colors flex items-center"
              type="button"
            >
              <Upload className="mr-1" size={12} />
              Upload
            </button>
          </div>

          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            onChange={handleFileUpload}
            className="hidden"
          />

          {/* Preset Audio Library */}
          {activeTab === 'effects' && (
            <div className="space-y-2">
              {soundEffects.map(effect => (
                <div key={effect.name} className="bg-slate-700 rounded-lg p-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm">{effect.name}</p>
                    <p className="text-xs text-slate-400">{effect.duration}s</p>
                  </div>
                  <button
                    onClick={() => addAudioTrack(effect.name, 'sound-effect', effect.url, undefined, effect.duration)}
                    className="bg-orange-500 hover:bg-orange-600 px-3 py-1 rounded text-xs transition-colors"
                    type="button"
                  >
                    Add
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'music' && (
            <div className="space-y-2">
              {backgroundMusic.map(track => (
                <div key={track.name} className="bg-slate-700 rounded-lg p-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-sm">{track.name}</p>
                    <p className="text-xs text-slate-400">{Math.floor(track.duration / 60)}m {track.duration % 60}s</p>
                  </div>
                  <button
                    onClick={() => addAudioTrack(track.name, 'music', track.url, undefined, track.duration)}
                    className="bg-orange-500 hover:bg-orange-600 px-3 py-1 rounded text-xs transition-colors"
                    type="button"
                  >
                    Add
                  </button>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'voiceover' && (
            <div className="bg-slate-700 rounded-lg p-4 text-center">
              <Volume2 size={32} className="mx-auto mb-3 text-slate-400" />
              <p className="text-sm text-slate-300 mb-3">Upload your voiceover audio files</p>
              <p className="text-xs text-slate-400">Supported: MP3, WAV, AAC</p>
            </div>
          )}

          {/* Active Audio Tracks */}
          <div>
            <h4 className="font-medium text-sm text-slate-300 mb-3">Added Tracks ({audioTracks.length})</h4>
            <div className="space-y-2">
              {audioTracks.map(track => (
                <div
                  key={track.id}
                  className={`bg-slate-700 rounded-lg p-3 cursor-pointer border-2 transition-colors ${
                    selectedTrack === track.id 
                      ? 'border-orange-500 bg-slate-600' 
                      : 'border-transparent hover:bg-slate-600'
                  }`}
                  onClick={() => setSelectedTrack(track.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-sm truncate">{track.name}</p>
                      <div className="flex items-center space-x-3 text-xs text-slate-400">
                        <span className="capitalize">{track.type.replace('-', ' ')}</span>
                        <span>{track.startTime.toFixed(1)}s</span>
                        <span>Vol: {track.volume}%</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {track.volume === 0 ? (
                        <VolumeX className="text-slate-400" size={16} />
                      ) : (
                        <Volume2 className="text-slate-400" size={16} />
                      )}
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removeTrack(track.id);
                        }}
                        className="text-red-400 hover:text-red-300 p-1"
                        type="button"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Audio Track Editor */}
        {selectedTrackData && (
          <div className="space-y-4">
            <h4 className="font-medium text-sm text-slate-300">Edit Audio Track</h4>
            
            {/* Volume Control */}
            <div>
              <label className="block text-sm font-medium mb-2">
                Volume: {selectedTrackData.volume}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={selectedTrackData.volume}
                onChange={(e) => updateTrack(selectedTrackData.id, { volume: parseInt(e.target.value) })}
                className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #f97316 0%, #f97316 ${selectedTrackData.volume}%, #475569 ${selectedTrackData.volume}%, #475569 100%)`
                }}
              />
            </div>

            {/* Timing Controls */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">Start Time (s)</label>
                <input
                  type="number"
                  min="0"
                  max={videoDuration}
                  step="0.1"
                  value={selectedTrackData.startTime}
                  onChange={(e) => updateTrack(selectedTrackData.id, { startTime: parseFloat(e.target.value) })}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Duration (s)</label>
                <input
                  type="number"
                  min="0.1"
                  max={videoDuration - selectedTrackData.startTime}
                  step="0.1"
                  value={selectedTrackData.duration}
                  onChange={(e) => updateTrack(selectedTrackData.id, { duration: parseFloat(e.target.value) })}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Fade Controls */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium mb-2">Fade In (s)</label>
                <input
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  value={selectedTrackData.fadeIn}
                  onChange={(e) => updateTrack(selectedTrackData.id, { fadeIn: parseFloat(e.target.value) })}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Fade Out (s)</label>
                <input
                  type="number"
                  min="0"
                  max="5"
                  step="0.1"
                  value={selectedTrackData.fadeOut}
                  onChange={(e) => updateTrack(selectedTrackData.id, { fadeOut: parseFloat(e.target.value) })}
                  className="w-full bg-slate-700 border border-slate-600 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Loop Option (for music) */}
            {selectedTrackData.type === 'music' && (
              <div className="flex items-center justify-between p-3 bg-slate-700 rounded-lg">
                <div>
                  <p className="font-medium text-sm">Loop Track</p>
                  <p className="text-xs text-slate-400">Repeat music throughout video</p>
                </div>
                <button
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    selectedTrackData.loop ? 'bg-orange-500' : 'bg-slate-600'
                  }`}
                  onClick={() => updateTrack(selectedTrackData.id, { loop: !selectedTrackData.loop })}
                  type="button"
                >
                  <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                    selectedTrackData.loop ? 'translate-x-7' : 'translate-x-1'
                  }`} />
                </button>
              </div>
            )}

            {/* Quick Actions */}
            <div className="flex space-x-2">
              <button
                onClick={() => updateTrack(selectedTrackData.id, { volume: selectedTrackData.volume === 0 ? 70 : 0 })}
                className="flex-1 bg-slate-700 hover:bg-slate-600 px-3 py-2 rounded-lg text-sm transition-colors flex items-center justify-center"
                type="button"
              >
                {selectedTrackData.volume === 0 ? <Volume2 size={16} /> : <VolumeX size={16} />}
                <span className="ml-2">{selectedTrackData.volume === 0 ? 'Unmute' : 'Mute'}</span>
              </button>
              <button
                onClick={() => removeTrack(selectedTrackData.id)}
                className="bg-red-600 hover:bg-red-700 px-3 py-2 rounded-lg text-sm transition-colors flex items-center"
                type="button"
              >
                <Trash2 size={16} className="mr-2" />
                Remove
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}