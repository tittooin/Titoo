import { useCallback, useState } from 'react';
import { Upload, Video } from 'lucide-react';
import { validateVideoFile, getVideoDuration, type VideoFile } from '@/lib/video-utils';
import { useToast } from '@/hooks/use-toast';

interface FileUploadProps {
  onVideoSelect: (video: VideoFile) => void;
}

export function FileUpload({ onVideoSelect }: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleFile = useCallback(async (file: File) => {
    const error = validateVideoFile(file);
    if (error) {
      toast({
        title: "Invalid File",
        description: error,
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const duration = await getVideoDuration(file);
      const videoFile: VideoFile = {
        file,
        url: URL.createObjectURL(file),
        duration,
      };
      
      onVideoSelect(videoFile);
      toast({
        title: "Video Loaded",
        description: "Your video is ready for editing!",
      });
    } catch (error) {
      toast({
        title: "Loading Error",
        description: "Failed to load video. Please try another file.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [onVideoSelect, toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFile(files[0]);
    }
  }, [handleFile]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFile(files[0]);
    }
  }, [handleFile]);

  return (
    <section className="mb-8">
      <div
        className={`bg-slate-800 rounded-xl border-2 border-dashed transition-all duration-300 p-8 text-center cursor-pointer ${
          isDragOver 
            ? 'border-blue-500 bg-slate-700' 
            : 'border-slate-600 hover:border-blue-500'
        } ${isLoading ? 'opacity-50 pointer-events-none' : ''}`}
        onDrop={handleDrop}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={(e) => {
          e.preventDefault();
          setIsDragOver(false);
        }}
        onClick={() => document.getElementById('videoInput')?.click()}
      >
        <div className="max-w-md mx-auto">
          <div className="w-16 h-16 bg-slate-700 rounded-full flex items-center justify-center mx-auto mb-4">
            {isLoading ? (
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
            ) : (
              <Upload className="text-2xl text-blue-400" size={24} />
            )}
          </div>
          <h2 className="text-xl font-semibold mb-2">
            {isLoading ? 'Loading Video...' : 'Upload Your Video'}
          </h2>
          <p className="text-slate-300 mb-4">
            {isLoading 
              ? 'Please wait while we process your video'
              : 'Drag and drop your video file here, or click to browse'
            }
          </p>
          <div className="space-y-2 text-sm text-slate-400">
            <p>Supported formats: MP4, WebM, AVI</p>
            <p>Maximum file size: 500MB</p>
          </div>
          {!isLoading && (
            <button 
              className="bg-blue-500 hover:bg-blue-600 px-6 py-3 rounded-lg font-medium mt-4 transition-colors"
              type="button"
            >
              Choose File
            </button>
          )}
          <input
            type="file"
            id="videoInput"
            accept="video/*"
            className="hidden"
            onChange={handleFileInput}
            disabled={isLoading}
          />
        </div>
      </div>
    </section>
  );
}
