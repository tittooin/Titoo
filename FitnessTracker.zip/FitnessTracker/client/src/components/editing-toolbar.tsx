import { Type, Sparkles, Volume2, ImageIcon, Settings } from 'lucide-react';

interface EditingToolbarProps {
  onToolSelect: (tool: string | null) => void;
  activeTool: string | null;
}

export function EditingToolbar({ onToolSelect, activeTool }: EditingToolbarProps) {
  const tools = [
    {
      id: 'text',
      name: 'Text',
      icon: Type,
      description: 'Add text overlays',
      color: 'blue'
    },
    {
      id: 'effects',
      name: 'Effects',
      icon: Sparkles,
      description: 'Apply visual effects',
      color: 'purple'
    },
    {
      id: 'objects',
      name: 'Objects',
      icon: ImageIcon,
      description: 'Add shapes & graphics',
      color: 'green'
    },
    {
      id: 'audio',
      name: 'Audio',
      icon: Volume2,
      description: 'Add sound effects & music',
      color: 'orange'
    },
    {
      id: 'enhance',
      name: 'Enhance',
      icon: Settings,
      description: 'Video enhancement',
      color: 'yellow'
    }
  ];

  const getColorClasses = (color: string, isActive: boolean) => {
    const colorMap = {
      blue: isActive ? 'bg-blue-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-blue-500 hover:text-white',
      purple: isActive ? 'bg-purple-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-purple-500 hover:text-white',
      green: isActive ? 'bg-green-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-green-500 hover:text-white',
      orange: isActive ? 'bg-orange-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-orange-500 hover:text-white',
      yellow: isActive ? 'bg-yellow-500 text-white' : 'bg-slate-700 text-slate-300 hover:bg-yellow-500 hover:text-white'
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  return (
    <div className="bg-slate-800 rounded-xl p-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold">Editing Tools</h3>
        <p className="text-slate-400 text-sm">Select a tool to enhance your video</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {tools.map(tool => {
          const IconComponent = tool.icon;
          const isActive = activeTool === tool.id;
          
          return (
            <button
              key={tool.id}
              className={`p-4 rounded-lg transition-all duration-200 text-center ${getColorClasses(tool.color, isActive)}`}
              onClick={() => onToolSelect(isActive ? null : tool.id)}
              type="button"
            >
              <div className="flex flex-col items-center space-y-2">
                <IconComponent size={24} />
                <div>
                  <p className="font-medium text-sm">{tool.name}</p>
                  <p className="text-xs opacity-75">{tool.description}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}