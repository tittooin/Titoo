import { useState } from 'react';
import { Sparkles, Sun, Contrast, Palette, Zap, Eye } from 'lucide-react';

interface VideoEffect {
  id: string;
  name: string;
  type: 'filter' | 'adjustment' | 'artistic';
  intensity: number;
  enabled: boolean;
}

interface EffectsPanelProps {
  effects: VideoEffect[];
  onEffectsChange: (effects: VideoEffect[]) => void;
}

export function EffectsPanel({ effects, onEffectsChange }: EffectsPanelProps) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'filter' | 'adjustment' | 'artistic'>('all');

  const availableEffects = [
    // Color Adjustments
    { id: 'brightness', name: 'Brightness', type: 'adjustment', icon: Sun, description: 'Adjust video brightness' },
    { id: 'contrast', name: 'Contrast', type: 'adjustment', icon: Contrast, description: 'Enhance contrast' },
    { id: 'saturation', name: 'Saturation', type: 'adjustment', icon: Palette, description: 'Boost color saturation' },
    { id: 'hue', name: 'Hue Shift', type: 'adjustment', icon: Palette, description: 'Shift color hue' },
    
    // Filters
    { id: 'vintage', name: 'Vintage', type: 'filter', icon: Eye, description: 'Retro film look' },
    { id: 'blackwhite', name: 'Black & White', type: 'filter', icon: Eye, description: 'Grayscale effect' },
    { id: 'sepia', name: 'Sepia', type: 'filter', icon: Eye, description: 'Warm sepia tone' },
    { id: 'cool', name: 'Cool Tone', type: 'filter', icon: Eye, description: 'Cool blue tint' },
    { id: 'warm', name: 'Warm Tone', type: 'filter', icon: Eye, description: 'Warm orange tint' },
    
    // Artistic Effects
    { id: 'blur', name: 'Motion Blur', type: 'artistic', icon: Zap, description: 'Add motion blur effect' },
    { id: 'sharpen', name: 'Sharpen', type: 'artistic', icon: Zap, description: 'Enhance video sharpness' },
    { id: 'vignette', name: 'Vignette', type: 'artistic', icon: Sparkles, description: 'Dark edge vignette' },
    { id: 'noise', name: 'Film Grain', type: 'artistic', icon: Sparkles, description: 'Add film grain texture' }
  ] as const;

  const updateEffect = (effectId: string, updates: Partial<VideoEffect>) => {
    const updatedEffects = effects.map(effect =>
      effect.id === effectId ? { ...effect, ...updates } : effect
    );
    onEffectsChange(updatedEffects);
  };

  const toggleEffect = (effectId: string) => {
    const existingEffect = effects.find(e => e.id === effectId);
    
    if (existingEffect) {
      updateEffect(effectId, { enabled: !existingEffect.enabled });
    } else {
      const newEffect: VideoEffect = {
        id: effectId,
        name: availableEffects.find(e => e.id === effectId)?.name || effectId,
        type: availableEffects.find(e => e.id === effectId)?.type || 'filter',
        intensity: 50,
        enabled: true
      };
      onEffectsChange([...effects, newEffect]);
    }
  };

  const filteredEffects = availableEffects.filter(effect => 
    selectedCategory === 'all' || effect.type === selectedCategory
  );

  const categories = [
    { id: 'all', name: 'All Effects', count: availableEffects.length },
    { id: 'adjustment', name: 'Color', count: availableEffects.filter(e => e.type === 'adjustment').length },
    { id: 'filter', name: 'Filters', count: availableEffects.filter(e => e.type === 'filter').length },
    { id: 'artistic', name: 'Artistic', count: availableEffects.filter(e => e.type === 'artistic').length }
  ];

  return (
    <div className="bg-slate-800 rounded-xl p-6">
      <div className="flex items-center mb-6">
        <Sparkles className="mr-2 text-purple-400" size={20} />
        <h3 className="text-lg font-semibold">Visual Effects</h3>
      </div>

      {/* Category Tabs */}
      <div className="flex space-x-1 mb-6 bg-slate-700 rounded-lg p-1">
        {categories.map(category => (
          <button
            key={category.id}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex-1 ${
              selectedCategory === category.id
                ? 'bg-purple-500 text-white shadow-lg'
                : 'text-slate-300 hover:text-white hover:bg-slate-600'
            }`}
            onClick={() => setSelectedCategory(category.id as any)}
            type="button"
          >
            {category.name}
            <span className="ml-2 text-xs opacity-75">({category.count})</span>
          </button>
        ))}
      </div>

      {/* Effects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {filteredEffects.map(effect => {
          const IconComponent = effect.icon;
          const appliedEffect = effects.find(e => e.id === effect.id);
          const isEnabled = appliedEffect?.enabled || false;
          
          return (
            <div
              key={effect.id}
              className={`bg-slate-700 rounded-lg p-4 border-2 transition-all duration-200 ${
                isEnabled 
                  ? 'border-purple-500 bg-slate-600' 
                  : 'border-transparent hover:border-slate-500'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${
                    isEnabled ? 'bg-purple-500' : 'bg-slate-600'
                  }`}>
                    <IconComponent className="text-white" size={16} />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">{effect.name}</h4>
                    <p className="text-xs text-slate-400">{effect.description}</p>
                  </div>
                </div>
                <button
                  className={`w-12 h-6 rounded-full transition-colors relative ${
                    isEnabled ? 'bg-purple-500' : 'bg-slate-600'
                  }`}
                  onClick={() => toggleEffect(effect.id)}
                  type="button"
                >
                  <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                    isEnabled ? 'translate-x-7' : 'translate-x-1'
                  }`} />
                </button>
              </div>
              
              {/* Intensity Slider (only show if effect is enabled) */}
              {isEnabled && appliedEffect && (
                <div>
                  <label className="block text-xs font-medium mb-2 text-slate-300">
                    Intensity: {appliedEffect.intensity}%
                  </label>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={appliedEffect.intensity}
                    onChange={(e) => updateEffect(effect.id, { intensity: parseInt(e.target.value) })}
                    className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer"
                    style={{
                      background: `linear-gradient(to right, #8b5cf6 0%, #8b5cf6 ${appliedEffect.intensity}%, #475569 ${appliedEffect.intensity}%, #475569 100%)`
                    }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Active Effects Summary */}
      {effects.filter(e => e.enabled).length > 0 && (
        <div className="bg-slate-700 rounded-lg p-4">
          <h4 className="font-medium text-sm mb-3 text-slate-300">Active Effects ({effects.filter(e => e.enabled).length})</h4>
          <div className="flex flex-wrap gap-2">
            {effects.filter(e => e.enabled).map(effect => (
              <div key={effect.id} className="bg-purple-500 text-white px-3 py-1 rounded-full text-xs flex items-center">
                {effect.name}
                <span className="ml-2 opacity-75">{effect.intensity}%</span>
                <button
                  onClick={() => updateEffect(effect.id, { enabled: false })}
                  className="ml-2 hover:bg-purple-600 rounded-full p-0.5"
                  type="button"
                >
                  ×
                </button>
              </div>
            ))}
          </div>
          <button
            onClick={() => onEffectsChange(effects.map(e => ({ ...e, enabled: false })))}
            className="text-xs text-slate-400 hover:text-slate-300 mt-2"
            type="button"
          >
            Clear all effects
          </button>
        </div>
      )}
    </div>
  );
}