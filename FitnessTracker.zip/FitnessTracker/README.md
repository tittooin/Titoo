# VideoClipper - Client-Side Video Editing Application

VideoClipper is a comprehensive web application that allows users to convert long videos into short, engaging clips (15-60 seconds) using client-side processing. The application supports both file uploads and URL imports from YouTube and Facebook, providing a privacy-first approach by processing videos entirely in the browser without uploading to external servers.

## ✨ Features

### 🎥 Video Import Options
- **File Upload**: Drag-and-drop or browse for video files (MP4, WebM, AVI)
- **URL Import**: Direct import from YouTube and Facebook video URLs
- **Large File Support**: Handles files up to 500MB

### ⚡ Quick Clips
- **Instant Processing**: Generate 30, 45, or 60-second clips with one click
- **Smart Positioning**: Automatically selects engaging segments from your video
- **Multiple Formats**: Export in 480p, 720p, or 1080p quality

### 🎞️ Manual Editing
- **Timeline Editor**: Precise timeline controls for custom clip selection
- **Real-time Preview**: Preview your clips before processing
- **Crosshair Tools**: Set exact start/end times using current playback position

### 🔒 Privacy & Performance
- **Client-Side Processing**: Videos never leave your device
- **FFmpeg.wasm Integration**: Professional video processing in the browser
- **No Server Dependencies**: Works entirely offline after initial load

## 🚀 Getting Started

### Prerequisites
- Node.js 20 or higher
- Modern web browser with WebAssembly support

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd videoclipper
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:5000`

## 🏗️ Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # React components
│   │   │   ├── file-upload.tsx      # File upload interface
│   │   │   ├── url-input.tsx        # URL import component
│   │   │   ├── quick-clips.tsx      # Preset clip generator
│   │   │   ├── video-editor.tsx     # Main editing interface
│   │   │   ├── timeline-controls.tsx # Timeline and controls
│   │   │   └── processing-modal.tsx  # Progress indicator
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions and video processing
│   │   └── pages/          # Application pages
├── server/                 # Backend Express server
├── shared/                 # Shared TypeScript schemas
└── package.json           # Dependencies and scripts
```

## 🛠️ Technology Stack

### Frontend
- **React 18** with TypeScript
- **Vite** for fast development and builds
- **Tailwind CSS** with custom dark theme
- **shadcn/ui** components for consistent UI
- **FFmpeg.wasm** for video processing
- **React Query** for state management

### Backend
- **Express.js** with TypeScript
- **PostgreSQL** with Drizzle ORM (ready for database features)
- **Session management** for future user accounts

## 📖 How Video Processing Works Without APIs/GPU

VideoClipper uses **FFmpeg.wasm**, a WebAssembly port of FFmpeg that runs entirely in the browser:

### Client-Side Processing Flow:
1. **Video Loading**: Files are loaded into browser memory using File API
2. **FFmpeg Initialization**: WebAssembly module loads FFmpeg core
3. **Video Processing**: FFmpeg commands execute in browser's WebAssembly runtime
4. **Output Generation**: Processed video is generated as a Blob
5. **Download**: Browser automatically downloads the trimmed clip

### Why This Approach:
- **Privacy**: Videos never leave user's device
- **No Server Costs**: All processing happens client-side
- **Professional Quality**: Full FFmpeg capabilities available
- **Offline Capable**: Works without internet after initial load

### CPU-Based Processing:
- Uses efficient codec copying when possible (`-c copy`)
- Optimized FFmpeg commands for fast processing
- Progress tracking with real-time updates
- Memory management with automatic cleanup

## 🌐 URL Import Limitations

Due to browser security restrictions (CORS), direct video downloads from YouTube and Facebook may not work in all cases:

### Current Implementation:
- URL validation for YouTube and Facebook formats
- Simulated download process for demonstration
- Clear error messages when CORS blocks requests

### Recommended Solutions:
1. **Browser Extensions**: Use video downloader extensions
2. **Manual Download**: Download videos manually then upload files
3. **Proxy Service**: Implement server-side proxy (future enhancement)

## 🎯 Usage Guide

### Method 1: Quick Clips (Recommended for Social Media)
1. Upload a video file or paste a URL
2. Click on 30s, 45s, or 60s quick clip buttons
3. Your clip will be automatically processed and downloaded

### Method 2: Manual Editing (For Precise Control)
1. Upload your video
2. Use the timeline to navigate to your desired start point
3. Set start and end times using:
   - Manual time input (MM:SS format)
   - Crosshair buttons to use current playback time
   - Timeline scrubber for visual selection
4. Preview your clip to ensure it's perfect
5. Click "Trim & Download" to process

### Supported Formats:
- **Input**: MP4, WebM, AVI (up to 500MB)
- **Output**: MP4 (480p, 720p, 1080p)

## 🔧 Development

### Available Scripts:
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

### Key Development Guidelines:
- Client-side processing prioritized over server operations
- Dark theme design for video editing workflow
- Mobile-responsive design
- TypeScript for type safety across the stack

## 📱 Mobile App Development

While this repository contains the web application, the architecture is designed to support mobile development:

### Recommended Mobile Stack:
- **Flutter** with `ffmpeg_kit_flutter` for video processing
- **React Native** with `react-native-ffmpeg`
- Shared UI components and design system
- Similar client-side processing approach

## 🚀 Deployment

### Static Hosting (Recommended):
1. Build the application: `npm run build`
2. Deploy `dist/` folder to:
   - **Netlify**: Drag & drop deployment
   - **Vercel**: Git integration
   - **GitHub Pages**: Static site hosting
   - **Replit**: One-click deployment

### Requirements:
- Static file hosting with HTTPS
- WebAssembly support (most modern hosting providers)
- No server-side requirements needed

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Commit your changes: `git commit -m 'Add amazing feature'`
4. Push to the branch: `git push origin feature/amazing-feature`
5. Open a Pull Request

## 📄 License

This project is open-source and available under the MIT License.

## 🆘 Support

For help and support:
- Check the in-app help button for quick guidance
- Review this README for technical details
- Open an issue for bug reports or feature requests

## 🔮 Future Enhancements

- Audio analysis for automatic engaging segment detection
- Text overlays and basic filters
- Batch processing for multiple clips
- User accounts and project saving
- Mobile app development
- Server-side proxy for URL downloads
- Advanced editing features (transitions, effects)

---

**Built with ❤️ for content creators who value privacy and performance.**