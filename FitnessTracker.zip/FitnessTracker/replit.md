# VideoClipper - Client-Side Video Editing Application

## Overview

VideoClipper is a comprehensive web application that allows users to convert long videos into short, engaging clips (15-60 seconds) using client-side processing. The application supports both file uploads and URL imports from YouTube and Facebook, providing a privacy-first approach by processing videos entirely in the browser without uploading to external servers.

## Recent Changes (January 2025)

✓ Added comprehensive video editing suite with professional tools
✓ Implemented text overlays, visual effects, objects/graphics panels
✓ Created audio tracks system with sound effects and background music
✓ Built video enhancement panel with color correction and quality improvements
✓ Added editing toolbar with 5 specialized tool categories
✓ Created advanced video downloader with y2mate/savefrom-style functionality
✓ Added multi-platform support (YouTube, TikTok, Instagram, Facebook, Twitter)
✓ Implemented format analysis with quality options (1080p, 720p, 480p, etc.)
✓ Built integrated download interface to keep users on the site
✓ Enhanced URL import with demo videos and better error handling
✓ Enhanced FFmpeg.wasm processing to support editing data
✓ Updated user interface with 3-tab navigation (Upload, Download, Direct URL)
✓ Added automatic video import after successful download
✓ Implemented server-side proxy endpoint to bypass CORS restrictions
✓ Added dual download options (Direct + Proxy) for maximum compatibility
✓ Fixed actual file downloads to user's device instead of opening external pages
✓ Enhanced download history tracking with proxy download status

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter for lightweight client-side routing
- **UI Framework**: shadcn/ui components with Radix UI primitives
- **Styling**: Tailwind CSS with custom design tokens for dark theme
- **State Management**: React Query (@tanstack/react-query) for server state and built-in React hooks for local state

### Backend Architecture
- **Server**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Development**: Vite middleware integration for seamless full-stack development

### Key Components

#### Video Processing
- **Client-Side Processing**: Uses FFmpeg.wasm for professional video trimming and editing operations
- **File Handling**: Supports MP4, WebM, and AVI formats with 500MB file size limit
- **URL Import**: Direct import from YouTube and Facebook video URLs (with CORS limitations)
- **Quick Clips**: Preset clip durations of 30, 45, and 60 seconds for instant processing
- **Timeline Editor**: Custom timeline controls for precise clip selection
- **Quality Options**: Support for 480p, 720p, and 1080p output quality

#### User Interface Components
- **FileUpload**: Drag-and-drop video file upload with validation
- **VideoDownloader**: Advanced y2mate/savefrom-style downloader with multi-platform support and format analysis
- **UrlInput**: Direct URL import component for video files
- **QuickClips**: One-click preset clip generation (30s, 45s, 60s)
- **VideoEditor**: Main editing interface with comprehensive editing suite
- **EditingToolbar**: Professional editing tools (text, effects, objects, audio, enhancement)
- **TextEditor**: Text overlay system with fonts, colors, and animations
- **EffectsPanel**: Visual effects library with transitions and filters
- **ObjectsPanel**: Shapes, graphics, and visual elements insertion
- **AudioPanel**: Sound effects, background music, and audio mixing
- **EnhancementPanel**: Video quality improvements and color correction
- **TimelineControls**: Precise time input controls for clip start/end times
- **ProcessingModal**: Progress indication during video processing with FFmpeg.wasm
- **FeaturesSection**: Updated marketing section highlighting comprehensive editing
- **HowItWorks**: Step-by-step guide for the complete editing workflow

#### Custom Hooks
- **useVideoProcessing**: Manages video trimming workflow and progress tracking
- **useToast**: Toast notification system for user feedback
- **useMobile**: Responsive design utilities

### Data Flow

1. **Video Upload**: User selects video file through FileUpload component
2. **Video Loading**: File validation and duration extraction using browser APIs
3. **Timeline Setup**: Initialize timeline controls with video duration
4. **Clip Selection**: User adjusts start/end times through TimelineControls
5. **Processing**: FFmpeg.wasm processes video client-side with progress updates
6. **Download**: Processed clip automatically downloads to user's device

### External Dependencies

#### Core Dependencies
- **@ffmpeg/ffmpeg & @ffmpeg/util**: Client-side video processing
- **@neondatabase/serverless**: Neon database connection for PostgreSQL
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **@radix-ui/***: Accessible UI component primitives
- **@tanstack/react-query**: Data fetching and caching

#### Development Dependencies
- **tsx**: TypeScript execution for development server
- **esbuild**: Fast JavaScript bundler for production builds
- **@replit/vite-plugin-cartographer**: Replit-specific development tools

### Database Schema

Currently implements a basic user system with:
- **users table**: Basic user authentication (id, username, password)
- **Extensible design**: Ready for adding video projects, user preferences, etc.

### Deployment Strategy

#### Development
- Uses Vite dev server with HMR (Hot Module Replacement)
- Express server with middleware integration
- TypeScript compilation with strict type checking

#### Production
- Vite builds optimized static assets to `dist/public`
- esbuild bundles server code to `dist/index.js`
- Single-artifact deployment with static file serving

#### Environment Configuration
- PostgreSQL database via `DATABASE_URL` environment variable
- Drizzle migrations stored in `./migrations` directory
- Session management with PostgreSQL store

### Technical Decisions

#### Client-Side Processing Choice
- **Problem**: Privacy concerns and server costs for video processing
- **Solution**: FFmpeg.wasm for browser-based video processing
- **Benefits**: Complete privacy, no upload time, reduced server costs
- **Trade-offs**: Limited by browser memory and processing power

#### Monorepo Structure
- **Problem**: Coordinating frontend/backend development
- **Solution**: Shared TypeScript configuration and schema definitions
- **Benefits**: Type safety across stack, simplified development workflow

#### PostgreSQL with Drizzle
- **Problem**: Need for reliable data persistence and type safety
- **Solution**: Drizzle ORM with PostgreSQL
- **Benefits**: Type-safe queries, excellent migration system, production-ready
- **Note**: Currently using in-memory storage for development, ready for PostgreSQL integration

#### Dark Theme Design
- **Problem**: Video editing traditionally requires dark interfaces
- **Solution**: Custom dark color palette with CSS custom properties
- **Benefits**: Better user experience for video editing, modern aesthetic