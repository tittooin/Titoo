import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  // Video download proxy endpoint to bypass CORS
  app.get("/api/download-video", async (req, res) => {
    try {
      const { url, filename } = req.query;
      
      if (!url || typeof url !== 'string') {
        return res.status(400).json({ error: "URL parameter is required" });
      }
      
      console.log(`Proxying video download: ${url}`);
      
      const response = await fetch(url);
      
      if (!response.ok) {
        return res.status(response.status).json({ error: `Failed to fetch video: ${response.statusText}` });
      }
      
      // Set appropriate headers for download
      const contentType = response.headers.get('content-type') || 'video/mp4';
      const contentLength = response.headers.get('content-length');
      const safeFilename = typeof filename === 'string' ? filename : 'video.mp4';
      
      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${safeFilename}"`);
      res.setHeader('Access-Control-Allow-Origin', '*');
      
      if (contentLength) {
        res.setHeader('Content-Length', contentLength);
      }
      
      // Stream the video data
      if (response.body) {
        const reader = response.body.getReader();
        const pump = async () => {
          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              res.write(value);
            }
            res.end();
          } catch (error) {
            console.error('Streaming error:', error);
            res.status(500).end();
          }
        };
        pump();
      } else {
        res.status(500).json({ error: "No response body" });
      }
      
    } catch (error) {
      console.error('Download proxy error:', error);
      res.status(500).json({ error: "Failed to download video" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
