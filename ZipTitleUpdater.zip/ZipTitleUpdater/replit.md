# TittoosTools - Online Tools Platform

## Overview

TittoosTools is a comprehensive web application providing 35+ essential online tools for productivity and development. The platform offers free, no-registration-required utilities including converters, generators, analyzers, and editors. Built with modern web technologies, it provides a responsive, user-friendly interface for various text processing, file conversion, and development tasks.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (@tanstack/react-query) for server state and React hooks for local state
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Build Tool**: Vite for development and production builds

### Backend Architecture
- **Runtime**: Node.js with TypeScript
- **Framework**: Express.js for REST API endpoints
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: In-memory storage with connect-pg-simple for session store
- **Development**: Vite dev server with HMR for seamless development experience

### Component Structure
- **Layout Components**: Header, Footer, Hero section
- **Tool Components**: Individual tool pages with consistent UI patterns
- **UI Components**: Reusable components from shadcn/ui library
- **Utility Functions**: Helper functions for file operations, validation, and formatting

## Key Components

### Tool Categories
1. **Converters**: PDF converter, image compressor, YouTube downloader, unit converter, timestamp converter
2. **Generators**: QR code generator, password generator, Lorem ipsum generator, gradient generator, favicon generator
3. **Analyzers**: SEO analyzer, page speed test, IP lookup, WHOIS lookup, domain checker, SSL checker
4. **Editors**: Text editor, markdown editor, JSON formatter, XML formatter, SQL formatter

### Data Management
- **Schema**: User management with username/password authentication
- **Storage Interface**: Abstracted storage layer supporting both in-memory and database storage
- **File Handling**: Client-side file processing with download capabilities

### UI/UX Features
- **Responsive Design**: Mobile-first approach with responsive breakpoints
- **Dark Mode**: CSS variable-based theming system
- **Accessibility**: Radix UI primitives ensure ARIA compliance
- **Toast Notifications**: User feedback for operations
- **Search and Filtering**: Tool discovery with category filtering

## Data Flow

### Client-Side Flow
1. User navigates to tool page via routing
2. Tool component renders with appropriate form fields
3. User inputs data and triggers processing
4. Client-side processing occurs (most tools are client-only)
5. Results displayed with copy/download options
6. Toast notifications provide user feedback

### Server-Side Flow (when applicable)
1. Client makes API request to /api endpoints
2. Express middleware handles request processing
3. Storage layer interacts with database if needed
4. Response sent back to client with appropriate data
5. Client updates UI based on response

### File Processing Flow
1. User selects or inputs file/data
2. Client-side JavaScript processes the data
3. Results generated and displayed immediately
4. Download functionality creates blob URLs for file downloads

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connectivity
- **drizzle-orm**: Type-safe database ORM
- **@tanstack/react-query**: Server state management
- **wouter**: Lightweight React routing
- **@radix-ui/***: Accessible UI primitives

### Development Tools
- **Vite**: Build tool and dev server
- **TypeScript**: Type safety and developer experience
- **Tailwind CSS**: Utility-first CSS framework
- **@replit/vite-plugin-runtime-error-modal**: Development error handling

### Utility Libraries
- **lucide-react**: Icon library
- **date-fns**: Date manipulation
- **react-hook-form**: Form handling
- **zod**: Runtime type validation

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React application to `dist/public`
2. **Backend Build**: esbuild compiles TypeScript server to `dist/index.js`
3. **Static Assets**: Client assets served from build directory
4. **Environment Variables**: Database URL and other config via environment

### Production Setup
- **Database**: PostgreSQL database provisioned via Neon
- **Server**: Node.js application serving both API and static files
- **Session Storage**: PostgreSQL-backed session store for production
- **Asset Serving**: Express serves built client assets in production

### Development Setup
- **Hot Reload**: Vite dev server with HMR for client development
- **API Proxy**: Development server proxies API requests to Express backend
- **Database**: Local or cloud PostgreSQL instance for development
- **Error Handling**: Runtime error overlays for debugging

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 01, 2025. Initial setup