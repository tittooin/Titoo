export interface Tool {
  id: string;
  title: string;
  description: string;
  category: 'converters' | 'generators' | 'analyzers' | 'editors';
  icon: string;
  color: string;
  path: string;
}

export const tools: Tool[] = [
  {
    id: 'pdf-converter',
    title: 'PDF Converter',
    description: 'Convert documents to PDF and vice versa',
    category: 'converters',
    icon: 'FileText',
    color: 'red',
    path: '/tools/pdf-converter'
  },
  {
    id: 'youtube-downloader',
    title: 'YouTube Downloader',
    description: 'Download YouTube videos in various formats',
    category: 'converters',
    icon: 'Download',
    color: 'red',
    path: '/tools/youtube-downloader'
  },
  {
    id: 'image-compressor',
    title: 'Image Compressor',
    description: 'Reduce image file sizes without quality loss',
    category: 'converters',
    icon: 'Minimize2',
    color: 'green',
    path: '/tools/image-compressor'
  },
  {
    id: 'text-editor',
    title: 'Text Editor',
    description: 'Rich text editor with formatting options',
    category: 'editors',
    icon: 'Edit',
    color: 'blue',
    path: '/tools/text-editor'
  },
  {
    id: 'qr-generator',
    title: 'QR Code Generator',
    description: 'Generate QR codes for text, URLs, and more',
    category: 'generators',
    icon: 'QrCode',
    color: 'purple',
    path: '/tools/qr-generator'
  },
  {
    id: 'password-generator',
    title: 'Password Generator',
    description: 'Create secure passwords with custom options',
    category: 'generators',
    icon: 'Key',
    color: 'yellow',
    path: '/tools/password-generator'
  },
  {
    id: 'url-shortener',
    title: 'URL Shortener',
    description: 'Shorten long URLs for easy sharing',
    category: 'converters',
    icon: 'Link',
    color: 'indigo',
    path: '/tools/url-shortener'
  },
  {
    id: 'color-picker',
    title: 'Color Picker',
    description: 'Pick colors and get hex, RGB, HSL values',
    category: 'generators',
    icon: 'Palette',
    color: 'pink',
    path: '/tools/color-picker'
  },
  {
    id: 'base64-encoder',
    title: 'Base64 Encoder',
    description: 'Encode and decode Base64 strings',
    category: 'converters',
    icon: 'Code',
    color: 'gray',
    path: '/tools/base64-encoder'
  },
  {
    id: 'json-formatter',
    title: 'JSON Formatter',
    description: 'Format and validate JSON data',
    category: 'editors',
    icon: 'Braces',
    color: 'orange',
    path: '/tools/json-formatter'
  },
  {
    id: 'html-minifier',
    title: 'HTML Minifier',
    description: 'Minify HTML code to reduce file size',
    category: 'converters',
    icon: 'FileCode',
    color: 'red',
    path: '/tools/html-minifier'
  },
  {
    id: 'css-minifier',
    title: 'CSS Minifier',
    description: 'Minify CSS code for better performance',
    category: 'converters',
    icon: 'Brush',
    color: 'blue',
    path: '/tools/css-minifier'
  },
  {
    id: 'js-minifier',
    title: 'JS Minifier',
    description: 'Minify JavaScript code efficiently',
    category: 'converters',
    icon: 'FileCode2',
    color: 'yellow',
    path: '/tools/js-minifier'
  },
  {
    id: 'markdown-editor',
    title: 'Markdown Editor',
    description: 'Write and preview Markdown content',
    category: 'editors',
    icon: 'FileEdit',
    color: 'gray',
    path: '/tools/markdown-editor'
  },
  {
    id: 'hash-generator',
    title: 'Hash Generator',
    description: 'Generate MD5, SHA1, SHA256 hashes',
    category: 'generators',
    icon: 'Hash',
    color: 'purple',
    path: '/tools/hash-generator'
  },
  {
    id: 'unit-converter',
    title: 'Unit Converter',
    description: 'Convert between different units of measurement',
    category: 'converters',
    icon: 'ArrowLeftRight',
    color: 'green',
    path: '/tools/unit-converter'
  },
  {
    id: 'timestamp-converter',
    title: 'Timestamp Converter',
    description: 'Convert between timestamp and readable date',
    category: 'converters',
    icon: 'Clock',
    color: 'blue',
    path: '/tools/timestamp-converter'
  },
  {
    id: 'regex-tester',
    title: 'Regex Tester',
    description: 'Test and debug regular expressions',
    category: 'analyzers',
    icon: 'Search',
    color: 'red',
    path: '/tools/regex-tester'
  },
  {
    id: 'lorem-generator',
    title: 'Lorem Generator',
    description: 'Generate placeholder text for design',
    category: 'generators',
    icon: 'Type',
    color: 'orange',
    path: '/tools/lorem-generator'
  },
  {
    id: 'gradient-generator',
    title: 'Gradient Generator',
    description: 'Create CSS gradients with visual editor',
    category: 'generators',
    icon: 'Paintbrush',
    color: 'pink',
    path: '/tools/gradient-generator'
  },
  {
    id: 'ip-lookup',
    title: 'IP Lookup',
    description: 'Get detailed information about IP addresses',
    category: 'analyzers',
    icon: 'Globe',
    color: 'cyan',
    path: '/tools/ip-lookup'
  },
  {
    id: 'whois-lookup',
    title: 'Whois Lookup',
    description: 'Check domain registration information',
    category: 'analyzers',
    icon: 'Info',
    color: 'teal',
    path: '/tools/whois-lookup'
  },
  {
    id: 'domain-checker',
    title: 'Domain Checker',
    description: 'Check domain availability and status',
    category: 'analyzers',
    icon: 'CheckCircle',
    color: 'emerald',
    path: '/tools/domain-checker'
  },
  {
    id: 'ssl-checker',
    title: 'SSL Checker',
    description: 'Check SSL certificate status and details',
    category: 'analyzers',
    icon: 'Shield',
    color: 'green',
    path: '/tools/ssl-checker'
  },
  {
    id: 'page-speed-test',
    title: 'Page Speed Test',
    description: 'Analyze website loading performance',
    category: 'analyzers',
    icon: 'Gauge',
    color: 'orange',
    path: '/tools/page-speed-test'
  },
  {
    id: 'seo-analyzer',
    title: 'SEO Analyzer',
    description: 'Analyze website SEO performance',
    category: 'analyzers',
    icon: 'TrendingUp',
    color: 'blue',
    path: '/tools/seo-analyzer'
  },
  {
    id: 'meta-tag-generator',
    title: 'Meta Tag Generator',
    description: 'Generate HTML meta tags for SEO',
    category: 'generators',
    icon: 'Tag',
    color: 'indigo',
    path: '/tools/meta-tag-generator'
  },
  {
    id: 'sitemap-generator',
    title: 'Sitemap Generator',
    description: 'Generate XML sitemaps for websites',
    category: 'generators',
    icon: 'Sitemap',
    color: 'purple',
    path: '/tools/sitemap-generator'
  },
  {
    id: 'robots-txt-generator',
    title: 'Robots.txt Generator',
    description: 'Create robots.txt files for SEO',
    category: 'generators',
    icon: 'Bot',
    color: 'gray',
    path: '/tools/robots-txt-generator'
  },
  {
    id: 'htaccess-generator',
    title: '.htaccess Generator',
    description: 'Generate .htaccess rules and redirects',
    category: 'generators',
    icon: 'Settings',
    color: 'red',
    path: '/tools/htaccess-generator'
  },
  {
    id: 'csv-to-json',
    title: 'CSV to JSON',
    description: 'Convert CSV data to JSON format',
    category: 'converters',
    icon: 'FileSpreadsheet',
    color: 'green',
    path: '/tools/csv-to-json'
  },
  {
    id: 'xml-formatter',
    title: 'XML Formatter',
    description: 'Format and validate XML documents',
    category: 'editors',
    icon: 'FileCode',
    color: 'yellow',
    path: '/tools/xml-formatter'
  },
  {
    id: 'sql-formatter',
    title: 'SQL Formatter',
    description: 'Format and beautify SQL queries',
    category: 'editors',
    icon: 'Database',
    color: 'blue',
    path: '/tools/sql-formatter'
  },
  {
    id: 'image-resizer',
    title: 'Image Resizer',
    description: 'Resize images to custom dimensions',
    category: 'converters',
    icon: 'Resize',
    color: 'pink',
    path: '/tools/image-resizer'
  },
  {
    id: 'favicon-generator',
    title: 'Favicon Generator',
    description: 'Create favicons from images',
    category: 'generators',
    icon: 'Star',
    color: 'orange',
    path: '/tools/favicon-generator'
  },
  {
    id: 'email-validator',
    title: 'Email Validator',
    description: 'Validate email addresses and check syntax',
    category: 'analyzers',
    icon: 'Mail',
    color: 'purple',
    path: '/tools/email-validator'
  }
];

export const categories = [
  { id: 'all', label: 'All Tools' },
  { id: 'converters', label: 'Converters' },
  { id: 'generators', label: 'Generators' },
  { id: 'analyzers', label: 'Analyzers' },
  { id: 'editors', label: 'Editors' }
];
