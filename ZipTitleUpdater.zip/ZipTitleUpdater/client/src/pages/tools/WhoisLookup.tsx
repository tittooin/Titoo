import { useState } from "react";
import { Info, Search, Calendar, User, Globe } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface WhoisInfo {
  domain: string;
  registrar: string;
  registrationDate: string;
  expirationDate: string;
  nameServers: string[];
  status: string[];
  registrantName?: string;
  registrantOrganization?: string;
  registrantCountry?: string;
}

export default function WhoisLookup() {
  const [domain, setDomain] = useState('');
  const [whoisInfo, setWhoisInfo] = useState<WhoisInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const isValidDomain = (domain: string) => {
    const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    return domainRegex.test(domain);
  };

  const lookupWhois = async () => {
    if (!domain.trim()) {
      toast({
        title: "Error",
        description: "Please enter a domain name",
        variant: "destructive"
      });
      return;
    }

    const cleanDomain = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '');

    if (!isValidDomain(cleanDomain)) {
      toast({
        title: "Error",
        description: "Please enter a valid domain name",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // Note: In a production environment, you would need a WHOIS API service
      // This is a mock response for demonstration
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock WHOIS data (in production, this would come from a WHOIS API)
      const mockWhoisData: WhoisInfo = {
        domain: cleanDomain,
        registrar: "Example Registrar LLC",
        registrationDate: "2020-01-15",
        expirationDate: "2025-01-15",
        nameServers: [
          "ns1.example.com",
          "ns2.example.com",
          "ns3.example.com"
        ],
        status: [
          "clientTransferProhibited",
          "clientDeleteProhibited",
          "clientUpdateProhibited"
        ],
        registrantName: "Domain Owner",
        registrantOrganization: "Example Organization",
        registrantCountry: "United States"
      };
      
      setWhoisInfo(mockWhoisData);
      toast({
        title: "Success",
        description: "WHOIS information retrieved successfully"
      });
    } catch (err) {
      setError("Failed to retrieve WHOIS information. This feature requires a WHOIS API service.");
      setWhoisInfo(null);
      toast({
        title: "Error",
        description: "Failed to lookup domain",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getDaysUntilExpiration = (expirationDate: string) => {
    const expDate = new Date(expirationDate);
    const today = new Date();
    const diffTime = expDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Info className="mx-auto w-16 h-16 text-teal-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">WHOIS Lookup</h1>
          <p className="text-xl text-gray-600">Check domain registration information</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Domain WHOIS Lookup</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="domain-input">Domain Name</Label>
              <Input
                id="domain-input"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                placeholder="Enter domain name (e.g., example.com)"
                className="mt-2"
                onKeyPress={(e) => e.key === 'Enter' && lookupWhois()}
              />
            </div>

            <Button 
              onClick={lookupWhois} 
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>Looking up...</>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Lookup WHOIS
                </>
              )}
            </Button>

            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <AlertDescription>
                <strong>Note:</strong> This is a demo interface. In production, this would integrate 
                with a WHOIS API service to retrieve real domain registration data.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {whoisInfo && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="w-5 h-5" />
                  Domain Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div>
                    <Label className="text-gray-600">Domain Name</Label>
                    <p className="font-mono font-medium">{whoisInfo.domain}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Registrar</Label>
                    <p className="font-medium">{whoisInfo.registrar}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Status</Label>
                    <div className="space-y-1">
                      {whoisInfo.status.map((status, index) => (
                        <span 
                          key={index}
                          className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded mr-1"
                        >
                          {status}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Important Dates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div>
                    <Label className="text-gray-600">Registration Date</Label>
                    <p className="font-medium">{formatDate(whoisInfo.registrationDate)}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Expiration Date</Label>
                    <p className="font-medium">{formatDate(whoisInfo.expirationDate)}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Days Until Expiration</Label>
                    <p className={`font-medium ${getDaysUntilExpiration(whoisInfo.expirationDate) < 30 ? 'text-red-600' : 'text-green-600'}`}>
                      {getDaysUntilExpiration(whoisInfo.expirationDate)} days
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Registrant Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div>
                    <Label className="text-gray-600">Name</Label>
                    <p className="font-medium">{whoisInfo.registrantName || 'Private/Protected'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Organization</Label>
                    <p className="font-medium">{whoisInfo.registrantOrganization || 'Private/Protected'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Country</Label>
                    <p className="font-medium">{whoisInfo.registrantCountry || 'Private/Protected'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Name Servers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {whoisInfo.nameServers.map((ns, index) => (
                    <div 
                      key={index}
                      className="p-2 bg-gray-50 border rounded text-sm font-mono"
                    >
                      {ns}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
