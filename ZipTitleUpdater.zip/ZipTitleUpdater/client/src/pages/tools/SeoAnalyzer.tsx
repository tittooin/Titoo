import { useState } from "react";
import { TrendingUp, Search, CheckCircle, XCircle, AlertTriangle, ExternalLink } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { isValidUrl } from "@/lib/utils";

interface SeoAnalysis {
  url: string;
  title: string;
  titleLength: number;
  description: string;
  descriptionLength: number;
  headings: { [key: string]: number };
  images: number;
  imagesWithoutAlt: number;
  internalLinks: number;
  externalLinks: number;
  metaKeywords: string;
  canonicalUrl: string;
  robots: string;
  viewport: string;
  charset: string;
  score: number;
  issues: Array<{ type: 'error' | 'warning' | 'info'; message: string }>;
}

export default function SeoAnalyzer() {
  const [url, setUrl] = useState('');
  const [analysis, setAnalysis] = useState<SeoAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const analyzeSEO = async () => {
    if (!url.trim()) {
      toast({
        title: "Error",
        description: "Please enter a URL to analyze",
        variant: "destructive"
      });
      return;
    }

    if (!isValidUrl(url)) {
      toast({
        title: "Error",
        description: "Please enter a valid URL",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // Fetch the webpage content
      const response = await fetch(`/api/seo-analyze?url=${encodeURIComponent(url)}`);
      
      if (!response.ok) {
        throw new Error('Failed to analyze website');
      }

      const html = await response.text();
      const parser = new DOMParser();
      const doc = parser.parseFromString(html, 'text/html');

      // Extract SEO data
      const title = doc.querySelector('title')?.textContent || '';
      const description = doc.querySelector('meta[name="description"]')?.getAttribute('content') || '';
      const keywords = doc.querySelector('meta[name="keywords"]')?.getAttribute('content') || '';
      const canonical = doc.querySelector('link[rel="canonical"]')?.getAttribute('href') || '';
      const robots = doc.querySelector('meta[name="robots"]')?.getAttribute('content') || '';
      const viewport = doc.querySelector('meta[name="viewport"]')?.getAttribute('content') || '';
      const charset = doc.querySelector('meta[charset]')?.getAttribute('charset') || 
                     doc.querySelector('meta[http-equiv="Content-Type"]')?.getAttribute('content') || '';

      // Count headings
      const headings: { [key: string]: number } = {};
      ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'].forEach(tag => {
        headings[tag] = doc.querySelectorAll(tag).length;
      });

      // Count images
      const images = doc.querySelectorAll('img').length;
      const imagesWithoutAlt = doc.querySelectorAll('img:not([alt])').length;

      // Count links
      const allLinks = doc.querySelectorAll('a[href]');
      let internalLinks = 0;
      let externalLinks = 0;
      
      allLinks.forEach(link => {
        const href = link.getAttribute('href') || '';
        if (href.startsWith('http') && !href.includes(new URL(url).hostname)) {
          externalLinks++;
        } else if (href.startsWith('/') || href.includes(new URL(url).hostname)) {
          internalLinks++;
        }
      });

      // Generate issues and calculate score
      const issues: Array<{ type: 'error' | 'warning' | 'info'; message: string }> = [];
      let score = 100;

      if (!title) {
        issues.push({ type: 'error', message: 'Missing page title' });
        score -= 15;
      } else if (title.length < 30 || title.length > 60) {
        issues.push({ type: 'warning', message: 'Title length should be 30-60 characters' });
        score -= 5;
      }

      if (!description) {
        issues.push({ type: 'error', message: 'Missing meta description' });
        score -= 15;
      } else if (description.length < 120 || description.length > 160) {
        issues.push({ type: 'warning', message: 'Meta description should be 120-160 characters' });
        score -= 5;
      }

      if (headings.h1 === 0) {
        issues.push({ type: 'error', message: 'Missing H1 heading' });
        score -= 10;
      } else if (headings.h1 > 1) {
        issues.push({ type: 'warning', message: 'Multiple H1 headings found' });
        score -= 5;
      }

      if (imagesWithoutAlt > 0) {
        issues.push({ type: 'warning', message: `${imagesWithoutAlt} images missing alt attributes` });
        score -= Math.min(10, imagesWithoutAlt * 2);
      }

      if (!viewport) {
        issues.push({ type: 'warning', message: 'Missing viewport meta tag' });
        score -= 5;
      }

      if (!canonical) {
        issues.push({ type: 'info', message: 'No canonical URL specified' });
      }

      const seoAnalysis: SeoAnalysis = {
        url,
        title,
        titleLength: title.length,
        description,
        descriptionLength: description.length,
        headings,
        images,
        imagesWithoutAlt,
        internalLinks,
        externalLinks,
        metaKeywords: keywords,
        canonicalUrl: canonical,
        robots,
        viewport,
        charset,
        score: Math.max(0, score),
        issues
      };

      setAnalysis(seoAnalysis);
      toast({
        title: "Success",
        description: "SEO analysis completed"
      });
    } catch (err) {
      setError('Failed to analyze website. This feature requires server-side implementation.');
      setAnalysis(null);
      toast({
        title: "Error",
        description: "Failed to analyze website",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Good';
    if (score >= 60) return 'Needs Improvement';
    return 'Poor';
  };

  const getIssueIcon = (type: 'error' | 'warning' | 'info') => {
    switch (type) {
      case 'error':
        return <XCircle className="w-4 h-4 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'info':
        return <CheckCircle className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <TrendingUp className="mx-auto w-16 h-16 text-blue-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">SEO Analyzer</h1>
          <p className="text-xl text-gray-600">Analyze website SEO performance</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>SEO Analysis</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="url-input">Website URL</Label>
              <Input
                id="url-input"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                className="mt-2"
                onKeyPress={(e) => e.key === 'Enter' && analyzeSEO()}
              />
            </div>

            <Button 
              onClick={analyzeSEO} 
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>Analyzing SEO...</>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Analyze SEO
                </>
              )}
            </Button>

            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <AlertDescription>
                <strong>Note:</strong> This tool requires server-side implementation to fetch and analyze web pages.
                In production, it would parse HTML content and extract SEO metadata.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {analysis && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>SEO Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-6">
                  <div className={`text-6xl font-bold mb-2 ${getScoreColor(analysis.score)}`}>
                    {analysis.score}
                  </div>
                  <div className={`text-lg font-medium ${getScoreColor(analysis.score)}`}>
                    {getScoreLabel(analysis.score)}
                  </div>
                  <Progress 
                    value={analysis.score} 
                    className="mt-4"
                  />
                </div>
                <div className="flex items-center gap-2 justify-center">
                  <ExternalLink className="w-4 h-4" />
                  <a 
                    href={analysis.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:underline break-all"
                  >
                    {analysis.url}
                  </a>
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Page Content</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium">Title Tag</Label>
                    <p className="text-sm mt-1 p-2 bg-gray-50 rounded border">
                      {analysis.title || 'Not found'}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">
                      Length: {analysis.titleLength} characters (optimal: 30-60)
                    </p>
                  </div>
                  
                  <div>
                    <Label className="text-sm font-medium">Meta Description</Label>
                    <p className="text-sm mt-1 p-2 bg-gray-50 rounded border">
                      {analysis.description || 'Not found'}
                    </p>
                    <p className="text-xs text-gray-600 mt-1">
                      Length: {analysis.descriptionLength} characters (optimal: 120-160)
                    </p>
                  </div>

                  <div>
                    <Label className="text-sm font-medium">Headings Structure</Label>
                    <div className="grid grid-cols-3 gap-2 mt-1">
                      {Object.entries(analysis.headings).map(([tag, count]) => (
                        <div key={tag} className="text-center p-2 bg-gray-50 rounded border">
                          <div className="text-sm font-medium">{tag.toUpperCase()}</div>
                          <div className="text-lg font-bold">{count}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Technical SEO</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <Label className="text-gray-600">Images</Label>
                      <p className="font-medium">{analysis.images} total</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Missing Alt Tags</Label>
                      <p className="font-medium text-red-600">{analysis.imagesWithoutAlt}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Internal Links</Label>
                      <p className="font-medium">{analysis.internalLinks}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">External Links</Label>
                      <p className="font-medium">{analysis.externalLinks}</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div>
                      <Label className="text-sm font-medium">Viewport</Label>
                      <p className="text-sm text-gray-600">
                        {analysis.viewport || 'Not found'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Charset</Label>
                      <p className="text-sm text-gray-600">
                        {analysis.charset || 'Not specified'}
                      </p>
                    </div>
                    <div>
                      <Label className="text-sm font-medium">Robots</Label>
                      <p className="text-sm text-gray-600">
                        {analysis.robots || 'Default'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Issues & Recommendations</CardTitle>
              </CardHeader>
              <CardContent>
                {analysis.issues.length > 0 ? (
                  <div className="space-y-3">
                    {analysis.issues.map((issue, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                        {getIssueIcon(issue.type)}
                        <div className="flex-1">
                          <Badge 
                            variant={issue.type === 'error' ? 'destructive' : 'secondary'}
                            className="mb-1"
                          >
                            {issue.type.charAt(0).toUpperCase() + issue.type.slice(1)}
                          </Badge>
                          <p className="text-sm">{issue.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                    <p className="text-green-700 font-medium">No critical SEO issues found!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
