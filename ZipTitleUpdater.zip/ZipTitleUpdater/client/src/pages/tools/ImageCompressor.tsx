import { useState } from "react";
import { Upload, Download, Minimize2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { formatBytes } from "@/lib/utils";

export default function ImageCompressor() {
  const [file, setFile] = useState<File | null>(null);
  const [compressedImage, setCompressedImage] = useState<string | null>(null);
  const [quality, setQuality] = useState([80]);
  const [originalSize, setOriginalSize] = useState(0);
  const [compressedSize, setCompressedSize] = useState(0);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);
      setOriginalSize(selectedFile.size);
      setCompressedImage(null);
      setCompressedSize(0);
    }
  };

  const compressImage = () => {
    if (!file) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    const img = new Image();

    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality[0] / 100);
        setCompressedImage(compressedDataUrl);
        
        // Calculate compressed size (rough estimation)
        const compressedSizeEstimate = Math.round((compressedDataUrl.length * 3) / 4);
        setCompressedSize(compressedSizeEstimate);
      }
    };

    img.src = URL.createObjectURL(file);
  };

  const downloadCompressed = () => {
    if (!compressedImage) return;
    
    const link = document.createElement('a');
    link.href = compressedImage;
    link.download = `compressed_${file?.name || 'image.jpg'}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const compressionRatio = originalSize > 0 ? ((originalSize - compressedSize) / originalSize * 100) : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Minimize2 className="mx-auto w-16 h-16 text-green-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Image Compressor</h1>
          <p className="text-xl text-gray-600">Reduce image file sizes without quality loss</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Upload Image</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                <Upload className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                <div className="space-y-2">
                  <p className="text-lg font-medium text-gray-900">Drop your image here or click to browse</p>
                  <p className="text-gray-500">Supports: JPG, PNG, WEBP</p>
                  <input
                    type="file"
                    onChange={handleFileChange}
                    accept="image/*"
                    className="hidden"
                    id="image-upload"
                  />
                  <label htmlFor="image-upload">
                    <Button variant="outline" className="cursor-pointer">
                      Choose Image
                    </Button>
                  </label>
                </div>
              </div>

              {file && (
                <div className="space-y-4">
                  <div>
                    <Label>Quality: {quality[0]}%</Label>
                    <Slider
                      value={quality}
                      onValueChange={setQuality}
                      max={100}
                      min={10}
                      step={5}
                      className="mt-2"
                    />
                  </div>

                  <Button onClick={compressImage} className="w-full">
                    Compress Image
                  </Button>

                  {originalSize > 0 && (
                    <Alert>
                      <AlertDescription>
                        Original size: {formatBytes(originalSize)}
                        {compressedSize > 0 && (
                          <>
                            <br />
                            Compressed size: {formatBytes(compressedSize)}
                            <br />
                            Compression: {compressionRatio.toFixed(1)}% reduction
                          </>
                        )}
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Preview
                <Button
                  variant="outline"
                  size="sm"
                  onClick={downloadCompressed}
                  disabled={!compressedImage}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {compressedImage ? (
                <img
                  src={compressedImage}
                  alt="Compressed"
                  className="w-full h-auto rounded-lg border border-gray-300"
                />
              ) : (
                <div className="flex items-center justify-center h-64 border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="text-center">
                    <Minimize2 className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                    <p className="text-gray-500">Compressed image will appear here</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
