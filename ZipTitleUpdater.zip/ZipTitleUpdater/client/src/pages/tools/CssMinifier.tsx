import { useState } from "react";
import { Brush, Copy, Download } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile, formatBytes } from "@/lib/utils";

export default function CssMinifier() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const { toast } = useToast();

  const minifyCss = () => {
    if (!input.trim()) {
      setOutput('');
      return;
    }

    // Simple CSS minification
    let minified = input
      // Remove comments
      .replace(/\/\*[\s\S]*?\*\//g, '')
      // Remove extra whitespace and newlines
      .replace(/\s+/g, ' ')
      // Remove spaces around specific characters
      .replace(/\s*{\s*/g, '{')
      .replace(/;\s*/g, ';')
      .replace(/:\s*/g, ':')
      .replace(/}\s*/g, '}')
      .replace(/,\s*/g, ',')
      // Remove trailing semicolons
      .replace(/;}/g, '}')
      // Trim
      .trim();

    setOutput(minified);
    
    const originalSize = new Blob([input]).size;
    const minifiedSize = new Blob([minified]).size;
    const savings = ((originalSize - minifiedSize) / originalSize * 100).toFixed(1);
    
    toast({
      title: "Success",
      description: `CSS minified successfully. ${savings}% size reduction.`
    });
  };

  const copyOutput = async () => {
    if (!output) return;
    
    try {
      await copyToClipboard(output);
      toast({
        title: "Success",
        description: "Minified CSS copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy CSS",
        variant: "destructive"
      });
    }
  };

  const downloadOutput = () => {
    if (!output) return;
    downloadFile(output, 'minified.css', 'text/css');
  };

  const originalSize = input ? new Blob([input]).size : 0;
  const minifiedSize = output ? new Blob([output]).size : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Brush className="mx-auto w-16 h-16 text-blue-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">CSS Minifier</h1>
          <p className="text-xl text-gray-600">Minify CSS code for better performance</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Input CSS</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your CSS code here..."
                className="min-h-[400px] font-mono text-sm"
              />
              <Button onClick={minifyCss} className="w-full">
                Minify CSS
              </Button>
              {originalSize > 0 && (
                <p className="text-sm text-gray-600">
                  Original size: {formatBytes(originalSize)}
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Minified CSS
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyOutput}
                    disabled={!output}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadOutput}
                    disabled={!output}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={output}
                readOnly
                placeholder="Minified CSS will appear here..."
                className="min-h-[400px] font-mono text-sm"
              />
              {minifiedSize > 0 && (
                <div className="mt-4 text-sm text-gray-600">
                  <p>Minified size: {formatBytes(minifiedSize)}</p>
                  {originalSize > 0 && (
                    <p>Size reduction: {((originalSize - minifiedSize) / originalSize * 100).toFixed(1)}%</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
