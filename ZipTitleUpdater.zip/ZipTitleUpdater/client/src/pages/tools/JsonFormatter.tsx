import { useState } from "react";
import { Braces, Copy, Download } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

export default function JsonFormatter() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isValid, setIsValid] = useState(true);
  const { toast } = useToast();

  const formatJson = () => {
    if (!input.trim()) {
      setOutput('');
      return;
    }

    try {
      const parsed = JSON.parse(input);
      const formatted = JSON.stringify(parsed, null, 2);
      setOutput(formatted);
      setIsValid(true);
      toast({
        title: "Success",
        description: "JSON formatted successfully"
      });
    } catch (error) {
      setIsValid(false);
      toast({
        title: "Error",
        description: "Invalid JSON format",
        variant: "destructive"
      });
    }
  };

  const minifyJson = () => {
    if (!input.trim()) {
      setOutput('');
      return;
    }

    try {
      const parsed = JSON.parse(input);
      const minified = JSON.stringify(parsed);
      setOutput(minified);
      setIsValid(true);
      toast({
        title: "Success",
        description: "JSON minified successfully"
      });
    } catch (error) {
      setIsValid(false);
      toast({
        title: "Error",
        description: "Invalid JSON format",
        variant: "destructive"
      });
    }
  };

  const validateJson = () => {
    if (!input.trim()) {
      setIsValid(true);
      return;
    }

    try {
      JSON.parse(input);
      setIsValid(true);
      toast({
        title: "Success",
        description: "JSON is valid"
      });
    } catch (error) {
      setIsValid(false);
      toast({
        title: "Error",
        description: "Invalid JSON format",
        variant: "destructive"
      });
    }
  };

  const copyOutput = async () => {
    if (!output) return;
    
    try {
      await copyToClipboard(output);
      toast({
        title: "Success",
        description: "JSON copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy JSON",
        variant: "destructive"
      });
    }
  };

  const downloadJson = () => {
    if (!output) return;
    downloadFile(output, 'formatted.json', 'application/json');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Braces className="mx-auto w-16 h-16 text-orange-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">JSON Formatter</h1>
          <p className="text-xl text-gray-600">Format and validate JSON data</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Input JSON</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your JSON here..."
                className="min-h-[400px] font-mono text-sm"
              />
              <div className="flex gap-2 flex-wrap">
                <Button onClick={formatJson} className="flex-1">
                  Format
                </Button>
                <Button onClick={minifyJson} variant="outline" className="flex-1">
                  Minify
                </Button>
                <Button onClick={validateJson} variant="outline" className="flex-1">
                  Validate
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Output JSON
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyOutput}
                    disabled={!output}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadJson}
                    disabled={!output}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={output}
                readOnly
                placeholder="Formatted JSON will appear here..."
                className={`min-h-[400px] font-mono text-sm ${
                  isValid ? 'border-green-300' : 'border-red-300'
                }`}
              />
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
