import { useState } from "react";
import { FileSpreadsheet, Download, Copy, Upload } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

export default function CsvToJson() {
  const [csvInput, setCsvInput] = useState('');
  const [jsonOutput, setJsonOutput] = useState('');
  const [hasHeaders, setHasHeaders] = useState(true);
  const [delimiter, setDelimiter] = useState(',');
  const [outputFormat, setOutputFormat] = useState('pretty');
  const { toast } = useToast();

  const parseCSV = (csv: string, delimiter: string, hasHeaders: boolean) => {
    const lines = csv.trim().split('\n');
    if (lines.length === 0) return [];

    const result = [];
    let headers: string[] = [];

    // Parse headers
    if (hasHeaders && lines.length > 0) {
      headers = parseCSVLine(lines[0], delimiter);
      lines.shift(); // Remove header line
    }

    // Parse data rows
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) continue;

      const values = parseCSVLine(line, delimiter);
      
      if (hasHeaders) {
        const row: { [key: string]: string } = {};
        headers.forEach((header, index) => {
          row[header] = values[index] || '';
        });
        result.push(row);
      } else {
        result.push(values);
      }
    }

    return result;
  };

  const parseCSVLine = (line: string, delimiter: string): string[] => {
    const result = [];
    let current = '';
    let inQuotes = false;
    let i = 0;

    while (i < line.length) {
      const char = line[i];
      const nextChar = line[i + 1];

      if (char === '"') {
        if (inQuotes && nextChar === '"') {
          // Escaped quote
          current += '"';
          i += 2;
        } else {
          // Toggle quote state
          inQuotes = !inQuotes;
          i++;
        }
      } else if (char === delimiter && !inQuotes) {
        // Field separator
        result.push(current.trim());
        current = '';
        i++;
      } else {
        current += char;
        i++;
      }
    }

    result.push(current.trim());
    return result;
  };

  const convertToJson = () => {
    if (!csvInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter CSV data to convert",
        variant: "destructive"
      });
      return;
    }

    try {
      const parsed = parseCSV(csvInput, delimiter, hasHeaders);
      
      if (parsed.length === 0) {
        toast({
          title: "Error",
          description: "No valid CSV data found",
          variant: "destructive"
        });
        return;
      }

      let jsonString = '';
      if (outputFormat === 'pretty') {
        jsonString = JSON.stringify(parsed, null, 2);
      } else {
        jsonString = JSON.stringify(parsed);
      }

      setJsonOutput(jsonString);
      toast({
        title: "Success",
        description: `Converted ${parsed.length} rows to JSON`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to parse CSV data",
        variant: "destructive"
      });
    }
  };

  const copyJson = async () => {
    if (!jsonOutput) {
      toast({
        title: "Error",
        description: "No JSON data to copy",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await copyToClipboard(jsonOutput);
      toast({
        title: "Success",
        description: "JSON data copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy JSON data",
        variant: "destructive"
      });
    }
  };

  const downloadJson = () => {
    if (!jsonOutput) {
      toast({
        title: "Error",
        description: "No JSON data to download",
        variant: "destructive"
      });
      return;
    }
    
    downloadFile(jsonOutput, 'converted.json', 'application/json');
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (file.type !== 'text/csv' && !file.name.endsWith('.csv')) {
      toast({
        title: "Error",
        description: "Please select a CSV file",
        variant: "destructive"
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const csv = e.target?.result as string;
      setCsvInput(csv);
    };
    reader.readAsText(file);
  };

  const loadSampleData = () => {
    const sampleCSV = `Name,Age,City,Country
John Doe,30,New York,USA
Jane Smith,25,London,UK
Bob Johnson,35,Toronto,Canada
Alice Brown,28,Sydney,Australia`;
    setCsvInput(sampleCSV);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <FileSpreadsheet className="mx-auto w-16 h-16 text-green-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">CSV to JSON Converter</h1>
          <p className="text-xl text-gray-600">Convert CSV data to JSON format</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                CSV Input
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={loadSampleData}>
                    Load Sample
                  </Button>
                  <div>
                    <input
                      type="file"
                      accept=".csv"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="csv-upload"
                    />
                    <label htmlFor="csv-upload">
                      <Button variant="outline" size="sm" className="cursor-pointer">
                        <Upload className="w-4 h-4 mr-2" />
                        Upload CSV
                      </Button>
                    </label>
                  </div>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="delimiter">Delimiter</Label>
                  <Select value={delimiter} onValueChange={setDelimiter}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value=",">Comma (,)</SelectItem>
                      <SelectItem value=";">Semicolon (;)</SelectItem>
                      <SelectItem value="\t">Tab</SelectItem>
                      <SelectItem value="|">Pipe (|)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2 mt-6">
                  <Checkbox
                    id="has-headers"
                    checked={hasHeaders}
                    onCheckedChange={(checked) => setHasHeaders(checked as boolean)}
                  />
                  <Label htmlFor="has-headers">First row contains headers</Label>
                </div>

                <div>
                  <Label htmlFor="output-format">Output Format</Label>
                  <Select value={outputFormat} onValueChange={setOutputFormat}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pretty">Pretty (formatted)</SelectItem>
                      <SelectItem value="minified">Minified</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="csv-input">CSV Data</Label>
                <Textarea
                  id="csv-input"
                  value={csvInput}
                  onChange={(e) => setCsvInput(e.target.value)}
                  placeholder="Paste your CSV data here or upload a file..."
                  className="mt-2 min-h-[300px] font-mono text-sm"
                />
              </div>

              <Button onClick={convertToJson} className="w-full">
                Convert to JSON
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                JSON Output
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyJson}
                    disabled={!jsonOutput}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadJson}
                    disabled={!jsonOutput}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={jsonOutput}
                readOnly
                placeholder="Converted JSON will appear here..."
                className="min-h-[400px] font-mono text-sm"
              />
              
              {jsonOutput && (
                <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="text-sm text-green-800">
                    <strong>Conversion successful!</strong><br />
                    Rows processed: {jsonOutput ? JSON.parse(jsonOutput).length : 0}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Usage Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div>
                <h4 className="font-medium mb-2">CSV Format Requirements:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Each row should be on a new line</li>
                  <li>• Use quotes around values containing delimiters</li>
                  <li>• Escape quotes by doubling them ("")</li>
                  <li>• Ensure consistent number of columns</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Output Options:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• With headers: Creates objects with property names</li>
                  <li>• Without headers: Creates arrays of values</li>
                  <li>• Pretty format: Formatted for readability</li>
                  <li>• Minified: Compact format for production</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
