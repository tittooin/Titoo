import { useState } from "react";
import { Table, Plus, Trash2, Download, Copy, Calendar } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile, isValidUrl } from "@/lib/utils";

interface SitemapUrl {
  loc: string;
  changefreq: string;
  priority: string;
  lastmod?: string;
}

export default function SitemapGenerator() {
  const [urls, setUrls] = useState<SitemapUrl[]>([
    {
      loc: '',
      changefreq: 'weekly',
      priority: '1.0',
      lastmod: new Date().toISOString().split('T')[0]
    }
  ]);
  
  const { toast } = useToast();

  const addUrl = () => {
    setUrls([...urls, {
      loc: '',
      changefreq: 'weekly',
      priority: '0.8',
      lastmod: new Date().toISOString().split('T')[0]
    }]);
  };

  const removeUrl = (index: number) => {
    if (urls.length > 1) {
      setUrls(urls.filter((_, i) => i !== index));
    }
  };

  const updateUrl = (index: number, field: keyof SitemapUrl, value: string) => {
    const newUrls = [...urls];
    newUrls[index] = { ...newUrls[index], [field]: value };
    setUrls(newUrls);
  };

  const generateSitemap = () => {
    const validUrls = urls.filter(url => url.loc.trim() && isValidUrl(url.loc));
    
    if (validUrls.length === 0) {
      toast({
        title: "Error",
        description: "Please add at least one valid URL",
        variant: "destructive"
      });
      return '';
    }

    const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${validUrls.map(url => `  <url>
    <loc>${url.loc}</loc>
    <lastmod>${url.lastmod}</lastmod>
    <changefreq>${url.changefreq}</changefreq>
    <priority>${url.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

    return xml;
  };

  const copySitemap = async () => {
    const xml = generateSitemap();
    if (!xml) return;
    
    try {
      await copyToClipboard(xml);
      toast({
        title: "Success",
        description: "Table XML copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy sitemap",
        variant: "destructive"
      });
    }
  };

  const downloadSitemap = () => {
    const xml = generateSitemap();
    if (!xml) return;
    
    downloadFile(xml, 'sitemap.xml', 'application/xml');
  };

  const bulkImport = (text: string) => {
    const lines = text.split('\n').filter(line => line.trim());
    const newUrls: SitemapUrl[] = [];
    
    lines.forEach(line => {
      const url = line.trim();
      if (url && isValidUrl(url)) {
        newUrls.push({
          loc: url,
          changefreq: 'weekly',
          priority: url.endsWith('/') ? '1.0' : '0.8', // Homepage gets priority 1.0
          lastmod: new Date().toISOString().split('T')[0]
        });
      }
    });
    
    if (newUrls.length > 0) {
      setUrls(newUrls);
      toast({
        title: "Success",
        description: `Imported ${newUrls.length} URLs`
      });
    } else {
      toast({
        title: "Error",
        description: "No valid URLs found in the input",
        variant: "destructive"
      });
    }
  };

  const [bulkInput, setBulkInput] = useState('');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Table className="mx-auto w-16 h-16 text-purple-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Table Generator</h1>
          <p className="text-xl text-gray-600">Generate XML sitemaps for websites</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Table URLs
                  <Button onClick={addUrl} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add URL
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="max-h-96 overflow-y-auto space-y-4">
                  {urls.map((url, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">URL {index + 1}</Label>
                        {urls.length > 1 && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeUrl(index)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div>
                        <Input
                          value={url.loc}
                          onChange={(e) => updateUrl(index, 'loc', e.target.value)}
                          placeholder="https://example.com/page"
                          className="w-full"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <Label className="text-xs">Change Frequency</Label>
                          <Select 
                            value={url.changefreq} 
                            onValueChange={(value) => updateUrl(index, 'changefreq', value)}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="always">Always</SelectItem>
                              <SelectItem value="hourly">Hourly</SelectItem>
                              <SelectItem value="daily">Daily</SelectItem>
                              <SelectItem value="weekly">Weekly</SelectItem>
                              <SelectItem value="monthly">Monthly</SelectItem>
                              <SelectItem value="yearly">Yearly</SelectItem>
                              <SelectItem value="never">Never</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        <div>
                          <Label className="text-xs">Priority</Label>
                          <Select 
                            value={url.priority} 
                            onValueChange={(value) => updateUrl(index, 'priority', value)}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="1.0">1.0 (Highest)</SelectItem>
                              <SelectItem value="0.9">0.9</SelectItem>
                              <SelectItem value="0.8">0.8</SelectItem>
                              <SelectItem value="0.7">0.7</SelectItem>
                              <SelectItem value="0.6">0.6</SelectItem>
                              <SelectItem value="0.5">0.5 (Medium)</SelectItem>
                              <SelectItem value="0.4">0.4</SelectItem>
                              <SelectItem value="0.3">0.3</SelectItem>
                              <SelectItem value="0.2">0.2</SelectItem>
                              <SelectItem value="0.1">0.1 (Lowest)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                      
                      <div>
                        <Label className="text-xs flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          Last Modified
                        </Label>
                        <Input
                          type="date"
                          value={url.lastmod}
                          onChange={(e) => updateUrl(index, 'lastmod', e.target.value)}
                          className="w-full"
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bulk Import URLs</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="bulk-input">URLs (one per line)</Label>
                  <Textarea
                    id="bulk-input"
                    value={bulkInput}
                    onChange={(e) => setBulkInput(e.target.value)}
                    placeholder={`https://example.com/
https://example.com/about
https://example.com/contact
https://example.com/blog`}
                    className="mt-2 min-h-[120px]"
                  />
                </div>
                <Button 
                  onClick={() => bulkImport(bulkInput)}
                  className="w-full"
                  disabled={!bulkInput.trim()}
                >
                  Import URLs
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Generated Table
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={copySitemap}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadSitemap}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={generateSitemap()}
                readOnly
                placeholder="Generated sitemap XML will appear here..."
                className="min-h-[500px] font-mono text-sm"
              />
              
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Usage Instructions:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Save the generated XML as 'sitemap.xml'</li>
                  <li>• Upload it to your website's root directory</li>
                  <li>• Submit to Google Search Console</li>
                  <li>• Add to your robots.txt: Table: https://yoursite.com/sitemap.xml</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
