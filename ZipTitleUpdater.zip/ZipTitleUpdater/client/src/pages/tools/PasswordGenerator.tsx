import { useState } from "react";
import { Key, Copy, RefreshCw } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard } from "@/lib/utils";

export default function PasswordGenerator() {
  const [password, setPassword] = useState('');
  const [length, setLength] = useState([12]);
  const [options, setOptions] = useState({
    lowercase: true,
    uppercase: true,
    numbers: true,
    symbols: false,
    excludeSimilar: false
  });
  const { toast } = useToast();

  const generatePassword = () => {
    let charset = '';
    if (options.lowercase) charset += 'abcdefghijklmnopqrstuvwxyz';
    if (options.uppercase) charset += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (options.numbers) charset += '0123456789';
    if (options.symbols) charset += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    if (options.excludeSimilar) {
      charset = charset.replace(/[il1Lo0O]/g, '');
    }

    if (!charset) {
      toast({
        title: "Error",
        description: "Please select at least one character type",
        variant: "destructive"
      });
      return;
    }

    let result = '';
    for (let i = 0; i < length[0]; i++) {
      result += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    setPassword(result);
  };

  const handleCopy = async () => {
    if (!password) return;
    
    try {
      await copyToClipboard(password);
      toast({
        title: "Success",
        description: "Password copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy password",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Key className="mx-auto w-16 h-16 text-yellow-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Password Generator</h1>
          <p className="text-xl text-gray-600">Create secure passwords with custom options</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Generate Password</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="length">Password Length: {length[0]}</Label>
              <Slider
                id="length"
                min={4}
                max={128}
                step={1}
                value={length}
                onValueChange={setLength}
                className="mt-2"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="lowercase"
                    checked={options.lowercase}
                    onCheckedChange={(checked) => 
                      setOptions(prev => ({ ...prev, lowercase: checked as boolean }))
                    }
                  />
                  <Label htmlFor="lowercase">Lowercase letters (a-z)</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="uppercase"
                    checked={options.uppercase}
                    onCheckedChange={(checked) => 
                      setOptions(prev => ({ ...prev, uppercase: checked as boolean }))
                    }
                  />
                  <Label htmlFor="uppercase">Uppercase letters (A-Z)</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="numbers"
                    checked={options.numbers}
                    onCheckedChange={(checked) => 
                      setOptions(prev => ({ ...prev, numbers: checked as boolean }))
                    }
                  />
                  <Label htmlFor="numbers">Numbers (0-9)</Label>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="symbols"
                    checked={options.symbols}
                    onCheckedChange={(checked) => 
                      setOptions(prev => ({ ...prev, symbols: checked as boolean }))
                    }
                  />
                  <Label htmlFor="symbols">Symbols (!@#$%^&*)</Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="excludeSimilar"
                    checked={options.excludeSimilar}
                    onCheckedChange={(checked) => 
                      setOptions(prev => ({ ...prev, excludeSimilar: checked as boolean }))
                    }
                  />
                  <Label htmlFor="excludeSimilar">Exclude similar characters</Label>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex gap-2">
                <Input
                  value={password}
                  readOnly
                  placeholder="Generated password will appear here"
                  className="font-mono"
                />
                <Button onClick={handleCopy} disabled={!password} variant="outline">
                  <Copy className="w-4 h-4" />
                </Button>
              </div>

              <Button onClick={generatePassword} className="w-full">
                <RefreshCw className="w-4 h-4 mr-2" />
                Generate Password
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
