import { useState } from "react";
import { FileEdit, Copy, Download, Eye, Edit3 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

export default function MarkdownEditor() {
  const [markdown, setMarkdown] = useState('# Welcome to Markdown Editor\n\nStart writing your **markdown** content here!\n\n## Features\n\n- Live preview\n- Export functionality\n- Easy formatting\n\n### Code Example\n\n```javascript\nconst greeting = "Hello, World!";\nconsole.log(greeting);\n```\n\n> This is a blockquote\n\n- List item 1\n- List item 2\n- List item 3\n\n[Link example](https://example.com)');
  const { toast } = useToast();

  // Simple markdown to HTML converter
  const convertMarkdownToHtml = (md: string) => {
    return md
      // Headers
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      // Bold
      .replace(/\*\*(.*)\*\*/gim, '<strong>$1</strong>')
      // Italic
      .replace(/\*(.*)\*/gim, '<em>$1</em>')
      // Code blocks
      .replace(/```([\s\S]*?)```/gim, '<pre><code>$1</code></pre>')
      // Inline code
      .replace(/`(.*?)`/gim, '<code>$1</code>')
      // Links
      .replace(/\[([^\]]+)\]\(([^)]+)\)/gim, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>')
      // Blockquotes
      .replace(/^> (.*$)/gim, '<blockquote>$1</blockquote>')
      // Unordered lists
      .replace(/^\- (.*$)/gim, '<li>$1</li>')
      .replace(/(<li>.*<\/li>)/gs, '<ul>$1</ul>')
      // Line breaks
      .replace(/\n/gim, '<br/>');
  };

  const copyMarkdown = async () => {
    if (!markdown) return;
    
    try {
      await copyToClipboard(markdown);
      toast({
        title: "Success",
        description: "Markdown copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy markdown",
        variant: "destructive"
      });
    }
  };

  const copyHtml = async () => {
    if (!markdown) return;
    
    try {
      const html = convertMarkdownToHtml(markdown);
      await copyToClipboard(html);
      toast({
        title: "Success",
        description: "HTML copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy HTML",
        variant: "destructive"
      });
    }
  };

  const downloadMarkdown = () => {
    if (!markdown) return;
    downloadFile(markdown, 'document.md', 'text/markdown');
  };

  const downloadHtml = () => {
    if (!markdown) return;
    const html = `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Markdown Document</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        pre { background: #f4f4f4; padding: 10px; border-radius: 5px; }
        blockquote { border-left: 4px solid #ddd; margin: 0; padding-left: 20px; }
        code { background: #f4f4f4; padding: 2px 4px; border-radius: 3px; }
    </style>
</head>
<body>
    ${convertMarkdownToHtml(markdown)}
</body>
</html>`;
    downloadFile(html, 'document.html', 'text/html');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <FileEdit className="mx-auto w-16 h-16 text-gray-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Markdown Editor</h1>
          <p className="text-xl text-gray-600">Write and preview Markdown content</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Markdown Editor</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="edit" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="edit" className="flex items-center gap-2">
                  <Edit3 className="w-4 h-4" />
                  Edit
                </TabsTrigger>
                <TabsTrigger value="preview" className="flex items-center gap-2">
                  <Eye className="w-4 h-4" />
                  Preview
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="edit" className="space-y-4">
                <Textarea
                  value={markdown}
                  onChange={(e) => setMarkdown(e.target.value)}
                  placeholder="Start writing your markdown here..."
                  className="min-h-[500px] font-mono text-sm"
                />
                <div className="flex gap-2 flex-wrap">
                  <Button onClick={copyMarkdown} variant="outline">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Markdown
                  </Button>
                  <Button onClick={downloadMarkdown} variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download MD
                  </Button>
                  <Button onClick={copyHtml} variant="outline">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy HTML
                  </Button>
                  <Button onClick={downloadHtml} variant="outline">
                    <Download className="w-4 h-4 mr-2" />
                    Download HTML
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="preview" className="space-y-4">
                <div 
                  className="min-h-[500px] p-6 border border-gray-300 rounded-lg bg-white prose prose-sm max-w-none"
                  dangerouslySetInnerHTML={{ __html: convertMarkdownToHtml(markdown) }}
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
