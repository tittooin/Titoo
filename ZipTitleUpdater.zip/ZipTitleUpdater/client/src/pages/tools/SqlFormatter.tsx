import { useState } from "react";
import { Database, Copy, Download, Wand2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile, formatBytes } from "@/lib/utils";

interface FormatOptions {
  indentSize: number;
  keywordCase: 'upper' | 'lower';
  commaStyle: 'trailing' | 'leading';
  linesBetweenQueries: number;
}

export default function SqlFormatter() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [options, setOptions] = useState<FormatOptions>({
    indentSize: 2,
    keywordCase: 'upper',
    commaStyle: 'trailing',
    linesBetweenQueries: 1
  });
  const { toast } = useToast();

  const sqlKeywords = [
    'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'NOT', 'IN', 'EXISTS', 'BETWEEN',
    'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE', 'CREATE', 'TABLE',
    'ALTER', 'DROP', 'INDEX', 'VIEW', 'TRIGGER', 'FUNCTION', 'PROCEDURE',
    'JOIN', 'INNER', 'LEFT', 'RIGHT', 'FULL', 'OUTER', 'ON', 'USING',
    'GROUP', 'BY', 'ORDER', 'HAVING', 'LIMIT', 'OFFSET', 'UNION', 'ALL',
    'DISTINCT', 'AS', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'IF', 'NULL',
    'IS', 'LIKE', 'REGEXP', 'COUNT', 'SUM', 'AVG', 'MIN', 'MAX', 'CAST',
    'CONVERT', 'COALESCE', 'ISNULL', 'CONCAT', 'SUBSTRING', 'LENGTH',
    'PRIMARY', 'KEY', 'FOREIGN', 'REFERENCES', 'UNIQUE', 'CHECK', 'DEFAULT',
    'AUTO_INCREMENT', 'SERIAL', 'IDENTITY', 'CONSTRAINT'
  ];

  const formatSql = (sql: string): string => {
    if (!sql.trim()) return '';

    let formatted = sql;
    const indent = ' '.repeat(options.indentSize);
    
    // Normalize whitespace
    formatted = formatted.replace(/\s+/g, ' ').trim();
    
    // Handle keywords case
    sqlKeywords.forEach(keyword => {
      const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
      const replacement = options.keywordCase === 'upper' ? keyword.toUpperCase() : keyword.toLowerCase();
      formatted = formatted.replace(regex, replacement);
    });

    // Add line breaks and indentation
    const patterns = [
      // Main clauses
      { regex: /\b(SELECT|FROM|WHERE|GROUP BY|ORDER BY|HAVING|UNION|INSERT INTO|UPDATE|DELETE FROM|CREATE TABLE|ALTER TABLE|DROP TABLE)\b/gi, replacement: '\n$1' },
      // JOIN clauses
      { regex: /\b((?:INNER |LEFT |RIGHT |FULL |OUTER )?JOIN)\b/gi, replacement: '\n$1' },
      // AND/OR in WHERE clauses
      { regex: /\b(AND|OR)\b(?=\s+(?![^(]*\)))/gi, replacement: '\n  $1' },
      // Subqueries
      { regex: /\(\s*(SELECT\b)/gi, replacement: '(\n  $1' },
      // INSERT VALUES
      { regex: /\bVALUES\b/gi, replacement: '\nVALUES' },
      // SET in UPDATE
      { regex: /\bSET\b/gi, replacement: '\nSET' }
    ];

    patterns.forEach(pattern => {
      formatted = formatted.replace(pattern.regex, pattern.replacement);
    });

    // Handle commas
    if (options.commaStyle === 'leading') {
      formatted = formatted.replace(/,\s*/g, '\n, ');
    } else {
      formatted = formatted.replace(/,\s*/g, ',\n');
    }

    // Clean up extra whitespace and add proper indentation
    const lines = formatted.split('\n');
    let indentLevel = 0;
    const formattedLines = lines.map(line => {
      const trimmed = line.trim();
      if (!trimmed) return '';

      // Adjust indent level
      if (trimmed.includes('(')) {
        const result = indent.repeat(indentLevel) + trimmed;
        indentLevel += (trimmed.match(/\(/g) || []).length;
        return result;
      }
      if (trimmed.includes(')')) {
        indentLevel -= (trimmed.match(/\)/g) || []).length;
        return indent.repeat(Math.max(0, indentLevel)) + trimmed;
      }

      // Special indentation for certain keywords
      if (trimmed.match(/^(AND|OR)\b/i)) {
        return indent.repeat(Math.max(0, indentLevel + 1)) + trimmed;
      }

      return indent.repeat(indentLevel) + trimmed;
    });

    // Join lines and clean up
    formatted = formattedLines
      .filter(line => line.trim())
      .join('\n')
      .replace(/\n{3,}/g, '\n\n');

    // Add lines between queries
    if (options.linesBetweenQueries > 0) {
      const separator = '\n'.repeat(options.linesBetweenQueries + 1);
      formatted = formatted.replace(/;\s*(?=\S)/g, ';' + separator);
    }

    return formatted;
  };

  const minifySql = (sql: string): string => {
    if (!sql.trim()) return '';
    
    return sql
      .replace(/\s+/g, ' ')
      .replace(/\s*([,();])\s*/g, '$1')
      .replace(/\s*(=|<|>|<=|>=|!=)\s*/g, '$1')
      .trim();
  };

  const formatQuery = () => {
    if (!input.trim()) {
      setOutput('');
      return;
    }

    try {
      const formatted = formatSql(input);
      setOutput(formatted);
      
      const originalSize = new Blob([input]).size;
      const formattedSize = new Blob([formatted]).size;
      const change = formattedSize > originalSize ? 'increase' : 'reduction';
      const percentage = ((Math.abs(originalSize - formattedSize) / originalSize) * 100).toFixed(1);
      
      toast({
        title: "Success",
        description: `SQL formatted successfully. ${percentage}% size ${change}.`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to format SQL",
        variant: "destructive"
      });
    }
  };

  const minifyQuery = () => {
    if (!input.trim()) {
      setOutput('');
      return;
    }

    try {
      const minified = minifySql(input);
      setOutput(minified);
      
      const originalSize = new Blob([input]).size;
      const minifiedSize = new Blob([minified]).size;
      const reduction = ((originalSize - minifiedSize) / originalSize * 100).toFixed(1);
      
      toast({
        title: "Success",
        description: `SQL minified successfully. ${reduction}% size reduction.`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to minify SQL",
        variant: "destructive"
      });
    }
  };

  const copyOutput = async () => {
    if (!output) return;
    
    try {
      await copyToClipboard(output);
      toast({
        title: "Success",
        description: "SQL copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy SQL",
        variant: "destructive"
      });
    }
  };

  const downloadOutput = () => {
    if (!output) return;
    downloadFile(output, 'formatted.sql', 'application/sql');
  };

  const loadSampleSql = () => {
    const sampleSql = `select u.id,u.name,u.email,p.title,p.content,c.name as category from users u inner join posts p on u.id=p.user_id left join categories c on p.category_id=c.id where u.active=1 and p.published_at is not null and p.created_at between '2023-01-01' and '2023-12-31' order by p.created_at desc limit 10;`;
    setInput(sampleSql);
  };

  const originalSize = input ? new Blob([input]).size : 0;
  const formattedSize = output ? new Blob([output]).size : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Database className="mx-auto w-16 h-16 text-blue-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">SQL Formatter</h1>
          <p className="text-xl text-gray-600">Format and beautify SQL queries</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Formatting Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="indent-size">Indent Size</Label>
                <Select 
                  value={options.indentSize.toString()} 
                  onValueChange={(value) => setOptions(prev => ({ ...prev, indentSize: parseInt(value) }))}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2">2 spaces</SelectItem>
                    <SelectItem value="4">4 spaces</SelectItem>
                    <SelectItem value="8">8 spaces</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="keyword-case">Keyword Case</Label>
                <Select 
                  value={options.keywordCase} 
                  onValueChange={(value: 'upper' | 'lower') => setOptions(prev => ({ ...prev, keywordCase: value }))}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upper">UPPERCASE</SelectItem>
                    <SelectItem value="lower">lowercase</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="comma-style">Comma Style</Label>
                <Select 
                  value={options.commaStyle} 
                  onValueChange={(value: 'trailing' | 'leading') => setOptions(prev => ({ ...prev, commaStyle: value }))}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="trailing">Trailing (column,)</SelectItem>
                    <SelectItem value="leading">Leading (, column)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="lines-between">Lines Between Queries</Label>
                <Select 
                  value={options.linesBetweenQueries.toString()} 
                  onValueChange={(value) => setOptions(prev => ({ ...prev, linesBetweenQueries: parseInt(value) }))}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">0 lines</SelectItem>
                    <SelectItem value="1">1 line</SelectItem>
                    <SelectItem value="2">2 lines</SelectItem>
                    <SelectItem value="3">3 lines</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Input SQL
                <Button variant="outline" size="sm" onClick={loadSampleSql}>
                  Load Sample
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your SQL query here..."
                className="min-h-[400px] font-mono text-sm"
              />
              
              <div className="flex gap-2">
                <Button onClick={formatQuery} className="flex-1">
                  <Wand2 className="w-4 h-4 mr-2" />
                  Format
                </Button>
                <Button onClick={minifyQuery} variant="outline" className="flex-1">
                  Minify
                </Button>
              </div>

              {originalSize > 0 && (
                <p className="text-sm text-gray-600">
                  Original size: {formatBytes(originalSize)}
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Formatted SQL
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyOutput}
                    disabled={!output}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadOutput}
                    disabled={!output}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={output}
                readOnly
                placeholder="Formatted SQL will appear here..."
                className="min-h-[400px] font-mono text-sm"
              />
              
              {formattedSize > 0 && (
                <div className="mt-4 text-sm text-gray-600">
                  <p>Formatted size: {formatBytes(formattedSize)}</p>
                  {originalSize > 0 && (
                    <p>
                      Size change: {formattedSize > originalSize ? '+' : ''}
                      {((formattedSize - originalSize) / originalSize * 100).toFixed(1)}%
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>SQL Formatting Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
              <div>
                <h4 className="font-medium mb-2">Formatting Features:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Consistent keyword casing</li>
                  <li>• Proper indentation for readability</li>
                  <li>• Line breaks at logical points</li>
                  <li>• Comma placement options</li>
                  <li>• JOIN clause formatting</li>
                  <li>• Subquery indentation</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Supported SQL Elements:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• SELECT, INSERT, UPDATE, DELETE</li>
                  <li>• JOINs (INNER, LEFT, RIGHT, FULL)</li>
                  <li>• WHERE, GROUP BY, ORDER BY</li>
                  <li>• Subqueries and CTEs</li>
                  <li>• Functions and operators</li>
                  <li>• DDL statements (CREATE, ALTER, DROP)</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
