import { useState } from "react";
import { Gauge, Search, Clock, Zap, AlertTriangle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { isValidUrl } from "@/lib/utils";

interface PageSpeedResult {
  url: string;
  performanceScore: number;
  loadTime: number;
  firstContentfulPaint: number;
  largestContentfulPaint: number;
  cumulativeLayoutShift: number;
  firstInputDelay: number;
  recommendations: string[];
  totalRequests: number;
  totalSize: number;
}

export default function PageSpeedTest() {
  const [url, setUrl] = useState('');
  const [result, setResult] = useState<PageSpeedResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const analyzePageSpeed = async () => {
    if (!url.trim()) {
      toast({
        title: "Error",
        description: "Please enter a URL to analyze",
        variant: "destructive"
      });
      return;
    }

    if (!isValidUrl(url)) {
      toast({
        title: "Error",
        description: "Please enter a valid URL",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // Use Google PageSpeed Insights API
      const apiKey = process.env.VITE_GOOGLE_PAGESPEED_API_KEY || '';
      if (!apiKey) {
        throw new Error('Google PageSpeed Insights API key not configured');
      }

      const response = await fetch(
        `https://www.googleapis.com/pagespeedonline/v5/runPagespeed?url=${encodeURIComponent(url)}&key=${apiKey}&category=performance`
      );

      if (!response.ok) {
        throw new Error('Failed to analyze page speed');
      }

      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message || 'Analysis failed');
      }

      const lighthouse = data.lighthouseResult;
      const audits = lighthouse.audits;

      const pageSpeedResult: PageSpeedResult = {
        url: url,
        performanceScore: Math.round(lighthouse.categories.performance.score * 100),
        loadTime: audits['speed-index']?.numericValue || 0,
        firstContentfulPaint: audits['first-contentful-paint']?.numericValue || 0,
        largestContentfulPaint: audits['largest-contentful-paint']?.numericValue || 0,
        cumulativeLayoutShift: audits['cumulative-layout-shift']?.numericValue || 0,
        firstInputDelay: audits['max-potential-fid']?.numericValue || 0,
        recommendations: [
          audits['unused-css-rules']?.score < 1 ? 'Remove unused CSS' : '',
          audits['unused-javascript']?.score < 1 ? 'Remove unused JavaScript' : '',
          audits['render-blocking-resources']?.score < 1 ? 'Eliminate render-blocking resources' : '',
          audits['unminified-css']?.score < 1 ? 'Minify CSS' : '',
          audits['unminified-javascript']?.score < 1 ? 'Minify JavaScript' : '',
          audits['efficient-animated-content']?.score < 1 ? 'Use efficient image formats' : '',
        ].filter(Boolean),
        totalRequests: audits['diagnostics']?.details?.items?.[0]?.numRequests || 0,
        totalSize: audits['diagnostics']?.details?.items?.[0]?.totalByteWeight || 0
      };

      setResult(pageSpeedResult);
      toast({
        title: "Success",
        description: "Page speed analysis completed"
      });
    } catch (err) {
      setError((err as Error).message);
      setResult(null);
      toast({
        title: "Error",
        description: "Failed to analyze page speed",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 90) return 'Good';
    if (score >= 50) return 'Needs Improvement';
    return 'Poor';
  };

  const formatTime = (ms: number) => {
    if (ms < 1000) return `${Math.round(ms)}ms`;
    return `${(ms / 1000).toFixed(1)}s`;
  };

  const formatSize = (bytes: number) => {
    const kb = bytes / 1024;
    if (kb < 1024) return `${Math.round(kb)}KB`;
    const mb = kb / 1024;
    return `${mb.toFixed(1)}MB`;
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Gauge className="mx-auto w-16 h-16 text-orange-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Page Speed Test</h1>
          <p className="text-xl text-gray-600">Analyze website loading performance</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Website Performance Analysis</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="url-input">Website URL</Label>
              <Input
                id="url-input"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                className="mt-2"
                onKeyPress={(e) => e.key === 'Enter' && analyzePageSpeed()}
              />
            </div>

            <Button 
              onClick={analyzePageSpeed} 
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>Analyzing performance...</>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Analyze Page Speed
                </>
              )}
            </Button>

            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {result && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center mb-6">
                  <div className={`text-6xl font-bold mb-2 ${getScoreColor(result.performanceScore)}`}>
                    {result.performanceScore}
                  </div>
                  <div className={`text-lg font-medium ${getScoreColor(result.performanceScore)}`}>
                    {getScoreLabel(result.performanceScore)}
                  </div>
                  <Progress 
                    value={result.performanceScore} 
                    className="mt-4"
                  />
                </div>
                <p className="text-center text-gray-600 text-sm">
                  Performance score based on Google Lighthouse metrics
                </p>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    Core Web Vitals
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">First Contentful Paint</Label>
                      <span className="text-sm font-medium">{formatTime(result.firstContentfulPaint)}</span>
                    </div>
                    <div className="text-xs text-gray-600">Time until first text/image appears</div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">Largest Contentful Paint</Label>
                      <span className="text-sm font-medium">{formatTime(result.largestContentfulPaint)}</span>
                    </div>
                    <div className="text-xs text-gray-600">Time until largest element loads</div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">Cumulative Layout Shift</Label>
                      <span className="text-sm font-medium">{result.cumulativeLayoutShift.toFixed(3)}</span>
                    </div>
                    <div className="text-xs text-gray-600">Visual stability during loading</div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">First Input Delay</Label>
                      <span className="text-sm font-medium">{formatTime(result.firstInputDelay)}</span>
                    </div>
                    <div className="text-xs text-gray-600">Time until page becomes interactive</div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5" />
                    Resource Summary
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">Total Load Time</Label>
                      <span className="text-sm font-medium">{formatTime(result.loadTime)}</span>
                    </div>
                    <div className="text-xs text-gray-600">Time for page to fully load</div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">Total Requests</Label>
                      <span className="text-sm font-medium">{result.totalRequests}</span>
                    </div>
                    <div className="text-xs text-gray-600">Number of HTTP requests</div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">Total Size</Label>
                      <span className="text-sm font-medium">{formatSize(result.totalSize)}</span>
                    </div>
                    <div className="text-xs text-gray-600">Total page weight</div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between items-center mb-1">
                      <Label className="text-sm">Analyzed URL</Label>
                    </div>
                    <div className="text-xs text-gray-600 break-all">{result.url}</div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {result.recommendations.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Performance Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {result.recommendations.map((recommendation, index) => (
                      <li key={index} className="flex items-start gap-2">
                        <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 flex-shrink-0" />
                        <span className="text-sm">{recommendation}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
