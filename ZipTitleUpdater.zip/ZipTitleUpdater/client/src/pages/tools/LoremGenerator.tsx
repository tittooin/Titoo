import { useState } from "react";
import { Type, Copy, Download, RefreshCw } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

const loremWords = [
  'lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit',
  'sed', 'do', 'eiusmod', 'tempor', 'incididunt', 'ut', 'labore', 'et', 'dolore',
  'magna', 'aliqua', 'enim', 'ad', 'minim', 'veniam', 'quis', 'nostrud',
  'exercitation', 'ullamco', 'laboris', 'nisi', 'aliquip', 'ex', 'ea', 'commodo',
  'consequat', 'duis', 'aute', 'irure', 'in', 'reprehenderit', 'voluptate',
  'velit', 'esse', 'cillum', 'fugiat', 'nulla', 'pariatur', 'excepteur', 'sint',
  'occaecat', 'cupidatat', 'non', 'proident', 'sunt', 'culpa', 'qui', 'officia',
  'deserunt', 'mollit', 'anim', 'id', 'est', 'laborum'
];

export default function LoremGenerator() {
  const [type, setType] = useState('paragraphs');
  const [count, setCount] = useState('3');
  const [startWithLorem, setStartWithLorem] = useState(true);
  const [output, setOutput] = useState('');
  const { toast } = useToast();

  const generateWords = (num: number) => {
    const words = [];
    for (let i = 0; i < num; i++) {
      words.push(loremWords[Math.floor(Math.random() * loremWords.length)]);
    }
    return words.join(' ');
  };

  const generateSentence = () => {
    const wordCount = Math.floor(Math.random() * 10) + 8; // 8-17 words
    const words = generateWords(wordCount);
    return words.charAt(0).toUpperCase() + words.slice(1) + '.';
  };

  const generateParagraph = () => {
    const sentenceCount = Math.floor(Math.random() * 4) + 4; // 4-7 sentences
    const sentences = [];
    
    if (startWithLorem && sentences.length === 0) {
      sentences.push('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.');
    }
    
    for (let i = sentences.length; i < sentenceCount; i++) {
      sentences.push(generateSentence());
    }
    
    return sentences.join(' ');
  };

  const generateLorem = () => {
    const num = parseInt(count);
    if (isNaN(num) || num <= 0) {
      toast({
        title: "Error",
        description: "Please enter a valid number",
        variant: "destructive"
      });
      return;
    }

    let result = '';
    
    switch (type) {
      case 'words':
        if (startWithLorem && num >= 2) {
          result = 'Lorem ipsum ' + generateWords(num - 2);
        } else {
          result = generateWords(num);
        }
        break;
        
      case 'sentences':
        const sentences = [];
        if (startWithLorem) {
          sentences.push('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.');
        }
        for (let i = sentences.length; i < num; i++) {
          sentences.push(generateSentence());
        }
        result = sentences.join(' ');
        break;
        
      case 'paragraphs':
        const paragraphs = [];
        for (let i = 0; i < num; i++) {
          paragraphs.push(generateParagraph());
        }
        result = paragraphs.join('\n\n');
        break;
        
      case 'lists':
        const items = [];
        for (let i = 0; i < num; i++) {
          items.push(`• ${generateSentence()}`);
        }
        result = items.join('\n');
        break;
    }
    
    setOutput(result);
    toast({
      title: "Success",
      description: `Generated ${num} ${type}`
    });
  };

  const copyOutput = async () => {
    if (!output) return;
    
    try {
      await copyToClipboard(output);
      toast({
        title: "Success",
        description: "Lorem ipsum text copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy text",
        variant: "destructive"
      });
    }
  };

  const downloadOutput = () => {
    if (!output) return;
    downloadFile(output, 'lorem-ipsum.txt');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Type className="mx-auto w-16 h-16 text-orange-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Lorem Generator</h1>
          <p className="text-xl text-gray-600">Generate placeholder text for design</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Generate Lorem Ipsum</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="type">Type</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="words">Words</SelectItem>
                    <SelectItem value="sentences">Sentences</SelectItem>
                    <SelectItem value="paragraphs">Paragraphs</SelectItem>
                    <SelectItem value="lists">List Items</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="count">Count</Label>
                <Input
                  id="count"
                  type="number"
                  value={count}
                  onChange={(e) => setCount(e.target.value)}
                  min="1"
                  max="100"
                  className="mt-2"
                />
              </div>

              <div className="flex items-end">
                <Button onClick={generateLorem} className="w-full">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Generate
                </Button>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="start-lorem"
                checked={startWithLorem}
                onChange={(e) => setStartWithLorem(e.target.checked)}
                className="rounded"
              />
              <Label htmlFor="start-lorem">Start with "Lorem ipsum"</Label>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Label>Generated Text</Label>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyOutput}
                    disabled={!output}
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadOutput}
                    disabled={!output}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
              
              <Textarea
                value={output}
                readOnly
                placeholder="Generated lorem ipsum text will appear here..."
                className="min-h-[300px]"
              />
            </div>

            {output && (
              <div className="text-sm text-gray-600">
                <p>
                  <strong>Word count:</strong> {output.split(/\s+/).length} |{' '}
                  <strong>Character count:</strong> {output.length}
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
