import { useState } from "react";
import { Palette, Copy } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard } from "@/lib/utils";

export default function ColorPicker() {
  const [color, setColor] = useState('#3b82f6');
  const { toast } = useToast();

  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
      ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16)
        }
      : null;
  };

  const hexToHsl = (hex: string) => {
    const rgb = hexToRgb(hex);
    if (!rgb) return null;

    const r = rgb.r / 255;
    const g = rgb.g / 255;
    const b = rgb.b / 255;

    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }

    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100)
    };
  };

  const rgb = hexToRgb(color);
  const hsl = hexToHsl(color);

  const copyValue = async (value: string, label: string) => {
    try {
      await copyToClipboard(value);
      toast({
        title: "Success",
        description: `${label} value copied to clipboard`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy value",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Palette className="mx-auto w-16 h-16 text-pink-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Color Picker</h1>
          <p className="text-xl text-gray-600">Pick colors and get hex, RGB, HSL values</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Color Picker</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <Label htmlFor="color-input">Select Color</Label>
                <div className="flex gap-4 items-center mt-2">
                  <input
                    id="color-input"
                    type="color"
                    value={color}
                    onChange={(e) => setColor(e.target.value)}
                    className="w-20 h-20 border-2 border-gray-300 rounded-lg cursor-pointer"
                  />
                  <div className="flex-1">
                    <Input
                      value={color}
                      onChange={(e) => setColor(e.target.value)}
                      placeholder="#000000"
                      className="font-mono"
                    />
                  </div>
                </div>
              </div>

              <div 
                className="w-full h-32 rounded-lg border-2 border-gray-300"
                style={{ backgroundColor: color }}
              />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Color Values</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>HEX</Label>
                <div className="flex gap-2">
                  <Input value={color} readOnly className="font-mono" />
                  <Button
                    variant="outline"
                    onClick={() => copyValue(color, 'HEX')}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {rgb && (
                <div className="space-y-2">
                  <Label>RGB</Label>
                  <div className="flex gap-2">
                    <Input
                      value={`rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`}
                      readOnly
                      className="font-mono"
                    />
                    <Button
                      variant="outline"
                      onClick={() => copyValue(`rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`, 'RGB')}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}

              {hsl && (
                <div className="space-y-2">
                  <Label>HSL</Label>
                  <div className="flex gap-2">
                    <Input
                      value={`hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`}
                      readOnly
                      className="font-mono"
                    />
                    <Button
                      variant="outline"
                      onClick={() => copyValue(`hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`, 'HSL')}
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}

              {rgb && (
                <>
                  <div className="space-y-2">
                    <Label>RGB Values</Label>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label className="text-sm text-gray-600">R</Label>
                        <Input value={rgb.r} readOnly className="font-mono" />
                      </div>
                      <div>
                        <Label className="text-sm text-gray-600">G</Label>
                        <Input value={rgb.g} readOnly className="font-mono" />
                      </div>
                      <div>
                        <Label className="text-sm text-gray-600">B</Label>
                        <Input value={rgb.b} readOnly className="font-mono" />
                      </div>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
