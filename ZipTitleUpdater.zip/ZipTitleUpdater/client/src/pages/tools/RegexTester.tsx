import { useState } from "react";
import { Search, Copy, AlertCircle, CheckCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard } from "@/lib/utils";

export default function RegexTester() {
  const [pattern, setPattern] = useState('');
  const [testString, setTestString] = useState('');
  const [flags, setFlags] = useState({
    global: false,
    multiline: false,
    ignoreCase: false
  });
  const [matches, setMatches] = useState<RegExpMatchArray[]>([]);
  const [error, setError] = useState('');
  const [isValid, setIsValid] = useState(false);
  const { toast } = useToast();

  const testRegex = () => {
    if (!pattern) {
      setMatches([]);
      setError('');
      setIsValid(false);
      return;
    }

    try {
      let flagString = '';
      if (flags.global) flagString += 'g';
      if (flags.multiline) flagString += 'm';
      if (flags.ignoreCase) flagString += 'i';

      const regex = new RegExp(pattern, flagString);
      setError('');
      setIsValid(true);

      if (!testString) {
        setMatches([]);
        return;
      }

      if (flags.global) {
        const allMatches = [];
        let match;
        while ((match = regex.exec(testString)) !== null) {
          allMatches.push(match);
          if (!flags.global) break;
        }
        setMatches(allMatches);
      } else {
        const match = testString.match(regex);
        setMatches(match ? [match] : []);
      }

      toast({
        title: "Success",
        description: `Found ${matches.length} match${matches.length !== 1 ? 'es' : ''}`
      });
    } catch (err) {
      setError((err as Error).message);
      setIsValid(false);
      setMatches([]);
    }
  };

  const copyPattern = async () => {
    if (!pattern) return;
    
    try {
      await copyToClipboard(pattern);
      toast({
        title: "Success",
        description: "Pattern copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy pattern",
        variant: "destructive"
      });
    }
  };

  const highlightMatches = (text: string) => {
    if (!pattern || !isValid || matches.length === 0) {
      return text;
    }

    let result = text;
    const sortedMatches = [...matches].sort((a, b) => (b.index || 0) - (a.index || 0));
    
    sortedMatches.forEach((match) => {
      if (match.index !== undefined) {
        const before = result.slice(0, match.index);
        const matchText = result.slice(match.index, match.index + match[0].length);
        const after = result.slice(match.index + match[0].length);
        result = before + `<mark class="bg-yellow-200 px-1 rounded">${matchText}</mark>` + after;
      }
    });

    return result;
  };

  const commonPatterns = [
    { name: 'Email', pattern: '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}' },
    { name: 'URL', pattern: 'https?://[^\\s]+' },
    { name: 'Phone (US)', pattern: '\\(\\d{3}\\)\\s?\\d{3}-\\d{4}' },
    { name: 'Credit Card', pattern: '\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}[\\s-]?\\d{4}' },
    { name: 'IP Address', pattern: '\\b(?:[0-9]{1,3}\\.){3}[0-9]{1,3}\\b' },
    { name: 'Hex Color', pattern: '#[a-fA-F0-9]{6}' }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Search className="mx-auto w-16 h-16 text-red-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Regex Tester</h1>
          <p className="text-xl text-gray-600">Test and debug regular expressions</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Regular Expression</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="pattern">Pattern</Label>
                  <div className="flex gap-2 mt-2">
                    <span className="px-3 py-2 bg-gray-100 border border-r-0 rounded-l-md text-gray-600">/</span>
                    <Input
                      id="pattern"
                      value={pattern}
                      onChange={(e) => setPattern(e.target.value)}
                      placeholder="Enter your regex pattern..."
                      className="rounded-none"
                    />
                    <span className="px-3 py-2 bg-gray-100 border border-l-0 rounded-r-md text-gray-600">/</span>
                    <Button variant="outline" onClick={copyPattern} disabled={!pattern}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="global"
                      checked={flags.global}
                      onCheckedChange={(checked) => 
                        setFlags(prev => ({ ...prev, global: checked as boolean }))
                      }
                    />
                    <Label htmlFor="global">Global (g)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="multiline"
                      checked={flags.multiline}
                      onCheckedChange={(checked) => 
                        setFlags(prev => ({ ...prev, multiline: checked as boolean }))
                      }
                    />
                    <Label htmlFor="multiline">Multiline (m)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="ignoreCase"
                      checked={flags.ignoreCase}
                      onCheckedChange={(checked) => 
                        setFlags(prev => ({ ...prev, ignoreCase: checked as boolean }))
                      }
                    />
                    <Label htmlFor="ignoreCase">Ignore Case (i)</Label>
                  </div>
                </div>

                <Button onClick={testRegex} className="w-full">
                  Test Regex
                </Button>

                {error && (
                  <Alert className="border-red-200 bg-red-50">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <AlertDescription className="text-red-800">
                      <strong>Invalid regex:</strong> {error}
                    </AlertDescription>
                  </Alert>
                )}

                {isValid && pattern && (
                  <Alert className="border-green-200 bg-green-50">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <AlertDescription className="text-green-800">
                      Valid regex pattern
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Test String</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={testString}
                  onChange={(e) => setTestString(e.target.value)}
                  placeholder="Enter text to test against your regex..."
                  className="min-h-[200px]"
                />
                
                {testString && (
                  <div className="space-y-2">
                    <Label>Text with Matches Highlighted</Label>
                    <div 
                      className="p-3 bg-gray-50 border rounded-lg min-h-[100px] whitespace-pre-wrap"
                      dangerouslySetInnerHTML={{ __html: highlightMatches(testString) }}
                    />
                  </div>
                )}
              </CardContent>
            </Card>

            {matches.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Matches ({matches.length})</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {matches.map((match, index) => (
                      <div key={index} className="p-2 bg-gray-50 border rounded text-sm">
                        <span className="font-mono font-medium">{match[0]}</span>
                        <span className="text-gray-600 ml-2">
                          at position {match.index}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Common Patterns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {commonPatterns.map((item, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="w-full justify-start text-left h-auto p-3"
                    onClick={() => setPattern(item.pattern)}
                  >
                    <div>
                      <div className="font-medium">{item.name}</div>
                      <div className="text-xs text-gray-600 font-mono break-all">
                        {item.pattern}
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
