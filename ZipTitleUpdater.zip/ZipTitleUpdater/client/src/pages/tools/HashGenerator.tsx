import { useState } from "react";
import { Hash, Copy } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard } from "@/lib/utils";

export default function HashGenerator() {
  const [input, setInput] = useState('');
  const [algorithm, setAlgorithm] = useState('md5');
  const [hash, setHash] = useState('');
  const { toast } = useToast();

  // Simple hash functions (for demo purposes)
  const generateMD5 = async (text: string) => {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const generateSHA1 = async (text: string) => {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-1', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const generateSHA256 = async (text: string) => {
    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const generateHash = async () => {
    if (!input.trim()) {
      toast({
        title: "Error",
        description: "Please enter text to hash",
        variant: "destructive"
      });
      return;
    }

    try {
      let result = '';
      switch (algorithm) {
        case 'md5':
          // Note: Web Crypto API doesn't support MD5, using SHA-256 as fallback
          result = await generateMD5(input);
          break;
        case 'sha1':
          result = await generateSHA1(input);
          break;
        case 'sha256':
          result = await generateSHA256(input);
          break;
      }
      setHash(result);
      toast({
        title: "Success",
        description: `${algorithm.toUpperCase()} hash generated`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate hash",
        variant: "destructive"
      });
    }
  };

  const copyHash = async () => {
    if (!hash) return;
    
    try {
      await copyToClipboard(hash);
      toast({
        title: "Success",
        description: "Hash copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy hash",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Hash className="mx-auto w-16 h-16 text-purple-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Hash Generator</h1>
          <p className="text-xl text-gray-600">Generate MD5, SHA1, SHA256 hashes</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Generate Hash</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="input-text">Input Text</Label>
              <Textarea
                id="input-text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter text to hash..."
                className="mt-2 min-h-[100px]"
              />
            </div>

            <div>
              <Label htmlFor="algorithm">Hash Algorithm</Label>
              <Select value={algorithm} onValueChange={setAlgorithm}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="Select algorithm" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="md5">MD5 (simulated)</SelectItem>
                  <SelectItem value="sha1">SHA-1</SelectItem>
                  <SelectItem value="sha256">SHA-256</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button onClick={generateHash} className="w-full">
              Generate Hash
            </Button>

            {hash && (
              <div className="space-y-2">
                <Label>Generated Hash ({algorithm.toUpperCase()})</Label>
                <div className="flex gap-2">
                  <Input
                    value={hash}
                    readOnly
                    className="font-mono text-sm"
                  />
                  <Button variant="outline" onClick={copyHash}>
                    <Copy className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
