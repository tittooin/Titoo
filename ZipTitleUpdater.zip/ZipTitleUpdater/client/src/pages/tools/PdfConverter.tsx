import { useState } from "react";
import { Upload, Download, FileText } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function PdfConverter() {
  const [file, setFile] = useState<File | null>(null);
  const [converting, setConverting] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleConvert = async () => {
    if (!file) return;
    
    setConverting(true);
    // Simulate conversion process
    setTimeout(() => {
      setConverting(false);
      // In a real implementation, this would convert the file
      alert('Conversion feature would be implemented here with a PDF library');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <FileText className="mx-auto w-16 h-16 text-red-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">PDF Converter</h1>
          <p className="text-xl text-gray-600">Convert documents to PDF and vice versa</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Upload Document</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Upload className="mx-auto w-12 h-12 text-gray-400 mb-4" />
              <div className="space-y-2">
                <p className="text-lg font-medium text-gray-900">Drop your file here or click to browse</p>
                <p className="text-gray-500">Supports: DOC, DOCX, TXT, RTF, ODT</p>
                <input
                  type="file"
                  onChange={handleFileChange}
                  accept=".doc,.docx,.txt,.rtf,.odt"
                  className="hidden"
                  id="file-upload"
                />
                <label htmlFor="file-upload">
                  <Button variant="outline" className="cursor-pointer">
                    Choose File
                  </Button>
                </label>
              </div>
            </div>

            {file && (
              <Alert>
                <AlertDescription>
                  Selected file: {file.name} ({(file.size / 1024 / 1024).toFixed(2)} MB)
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-4">
              <Button 
                onClick={handleConvert} 
                disabled={!file || converting}
                className="flex-1"
              >
                {converting ? (
                  <>Converting...</>
                ) : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Convert to PDF
                  </>
                )}
              </Button>
            </div>

            <Alert>
              <AlertDescription>
                <strong>Note:</strong> This is a demo interface. In a production environment, 
                this would integrate with PDF conversion libraries like pdf-lib or jsPDF.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
