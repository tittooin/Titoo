import { useState } from "react";
import { Bot, Copy, Download, Plus, Trash2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

interface RobotRule {
  userAgent: string;
  allow: string[];
  disallow: string[];
}

export default function RobotsTxtGenerator() {
  const [rules, setRules] = useState<RobotRule[]>([
    {
      userAgent: '*',
      allow: [],
      disallow: ['/admin/', '/private/']
    }
  ]);
  
  const [sitemapUrl, setSitemapUrl] = useState('');
  const [crawlDelay, setCrawlDelay] = useState('');
  const [host, setHost] = useState('');
  const [commonSettings, setCommonSettings] = useState({
    blockSearchEngines: false,
    blockBots: false,
    allowAll: false
  });

  const { toast } = useToast();

  const addRule = () => {
    setRules([...rules, {
      userAgent: '*',
      allow: [],
      disallow: []
    }]);
  };

  const removeRule = (index: number) => {
    if (rules.length > 1) {
      setRules(rules.filter((_, i) => i !== index));
    }
  };

  const updateRule = (index: number, field: keyof RobotRule, value: any) => {
    const newRules = [...rules];
    newRules[index] = { ...newRules[index], [field]: value };
    setRules(newRules);
  };

  const addPath = (ruleIndex: number, type: 'allow' | 'disallow') => {
    const newRules = [...rules];
    newRules[ruleIndex][type].push('');
    setRules(newRules);
  };

  const updatePath = (ruleIndex: number, type: 'allow' | 'disallow', pathIndex: number, value: string) => {
    const newRules = [...rules];
    newRules[ruleIndex][type][pathIndex] = value;
    setRules(newRules);
  };

  const removePath = (ruleIndex: number, type: 'allow' | 'disallow', pathIndex: number) => {
    const newRules = [...rules];
    newRules[ruleIndex][type].splice(pathIndex, 1);
    setRules(newRules);
  };

  const applyCommonSetting = (setting: keyof typeof commonSettings) => {
    setCommonSettings(prev => ({ ...prev, [setting]: !prev[setting] }));
    
    switch (setting) {
      case 'blockSearchEngines':
        if (!commonSettings.blockSearchEngines) {
          setRules([{
            userAgent: '*',
            allow: [],
            disallow: ['/']
          }]);
        }
        break;
      case 'blockBots':
        if (!commonSettings.blockBots) {
          setRules([{
            userAgent: '*',
            allow: [],
            disallow: ['/wp-admin/', '/admin/', '/private/', '/temp/']
          }]);
        }
        break;
      case 'allowAll':
        if (!commonSettings.allowAll) {
          setRules([{
            userAgent: '*',
            allow: ['/'],
            disallow: []
          }]);
        }
        break;
    }
  };

  const generateRobotsTxt = () => {
    let robotsTxt = '';

    rules.forEach(rule => {
      robotsTxt += `User-agent: ${rule.userAgent}\n`;
      
      rule.disallow.forEach(path => {
        if (path.trim()) {
          robotsTxt += `Disallow: ${path}\n`;
        }
      });
      
      rule.allow.forEach(path => {
        if (path.trim()) {
          robotsTxt += `Allow: ${path}\n`;
        }
      });
      
      robotsTxt += '\n';
    });

    if (crawlDelay) {
      robotsTxt += `Crawl-delay: ${crawlDelay}\n\n`;
    }

    if (host) {
      robotsTxt += `Host: ${host}\n\n`;
    }

    if (sitemapUrl) {
      robotsTxt += `Sitemap: ${sitemapUrl}\n`;
    }

    return robotsTxt.trim();
  };

  const copyRobotsTxt = async () => {
    const txt = generateRobotsTxt();
    if (!txt) {
      toast({
        title: "Error",
        description: "No robots.txt content to copy",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await copyToClipboard(txt);
      toast({
        title: "Success",
        description: "Robots.txt copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy robots.txt",
        variant: "destructive"
      });
    }
  };

  const downloadRobotsTxt = () => {
    const txt = generateRobotsTxt();
    if (!txt) {
      toast({
        title: "Error",
        description: "No robots.txt content to download",
        variant: "destructive"
      });
      return;
    }
    
    downloadFile(txt, 'robots.txt', 'text/plain');
  };

  const commonUserAgents = [
    '*',
    'Googlebot',
    'Bingbot',
    'Slurp',
    'DuckDuckBot',
    'Baiduspider',
    'YandexBot',
    'facebookexternalhit',
    'Twitterbot'
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Bot className="mx-auto w-16 h-16 text-gray-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Robots.txt Generator</h1>
          <p className="text-xl text-gray-600">Create robots.txt files for SEO</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quick Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="allow-all"
                    checked={commonSettings.allowAll}
                    onCheckedChange={() => applyCommonSetting('allowAll')}
                  />
                  <Label htmlFor="allow-all">Allow all web crawlers</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="block-bots"
                    checked={commonSettings.blockBots}
                    onCheckedChange={() => applyCommonSetting('blockBots')}
                  />
                  <Label htmlFor="block-bots">Block bots from sensitive areas</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="block-search"
                    checked={commonSettings.blockSearchEngines}
                    onCheckedChange={() => applyCommonSetting('blockSearchEngines')}
                  />
                  <Label htmlFor="block-search">Block all search engines</Label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Robot Rules
                  <Button onClick={addRule} size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Rule
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="max-h-96 overflow-y-auto space-y-4">
                  {rules.map((rule, ruleIndex) => (
                    <div key={ruleIndex} className="p-4 border rounded-lg space-y-3">
                      <div className="flex items-center justify-between">
                        <Label className="text-sm font-medium">Rule {ruleIndex + 1}</Label>
                        {rules.length > 1 && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeRule(ruleIndex)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                      
                      <div>
                        <Label className="text-xs">User-agent</Label>
                        <Input
                          value={rule.userAgent}
                          onChange={(e) => updateRule(ruleIndex, 'userAgent', e.target.value)}
                          placeholder="*"
                          className="w-full mt-1"
                          list={`user-agents-${ruleIndex}`}
                        />
                        <datalist id={`user-agents-${ruleIndex}`}>
                          {commonUserAgents.map(ua => (
                            <option key={ua} value={ua} />
                          ))}
                        </datalist>
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs">Disallow</Label>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => addPath(ruleIndex, 'disallow')}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                        {rule.disallow.map((path, pathIndex) => (
                          <div key={pathIndex} className="flex gap-2 mb-2">
                            <Input
                              value={path}
                              onChange={(e) => updatePath(ruleIndex, 'disallow', pathIndex, e.target.value)}
                              placeholder="/admin/"
                              className="flex-1"
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removePath(ruleIndex, 'disallow', pathIndex)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <Label className="text-xs">Allow</Label>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => addPath(ruleIndex, 'allow')}
                          >
                            <Plus className="w-3 h-3" />
                          </Button>
                        </div>
                        {rule.allow.map((path, pathIndex) => (
                          <div key={pathIndex} className="flex gap-2 mb-2">
                            <Input
                              value={path}
                              onChange={(e) => updatePath(ruleIndex, 'allow', pathIndex, e.target.value)}
                              placeholder="/public/"
                              className="flex-1"
                            />
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removePath(ruleIndex, 'allow', pathIndex)}
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Additional Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="sitemap">Sitemap URL</Label>
                  <Input
                    id="sitemap"
                    value={sitemapUrl}
                    onChange={(e) => setSitemapUrl(e.target.value)}
                    placeholder="https://example.com/sitemap.xml"
                    className="mt-2"
                  />
                </div>
                
                <div>
                  <Label htmlFor="crawl-delay">Crawl Delay (seconds)</Label>
                  <Input
                    id="crawl-delay"
                    type="number"
                    value={crawlDelay}
                    onChange={(e) => setCrawlDelay(e.target.value)}
                    placeholder="10"
                    className="mt-2"
                  />
                </div>
                
                <div>
                  <Label htmlFor="host">Host</Label>
                  <Input
                    id="host"
                    value={host}
                    onChange={(e) => setHost(e.target.value)}
                    placeholder="https://example.com"
                    className="mt-2"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Generated robots.txt
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={copyRobotsTxt}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadRobotsTxt}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={generateRobotsTxt()}
                readOnly
                placeholder="Generated robots.txt will appear here..."
                className="min-h-[400px] font-mono text-sm"
              />
              
              <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Usage Instructions:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Save the file as 'robots.txt'</li>
                  <li>• Upload to your website's root directory</li>
                  <li>• Test at: https://yoursite.com/robots.txt</li>
                  <li>• Validate with Google Search Console</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
