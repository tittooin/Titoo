import { useState } from "react";
import { FileCode, Copy, Download, CheckCircle, XCircle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile, formatBytes } from "@/lib/utils";

export default function XmlFormatter() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [isValid, setIsValid] = useState(true);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const formatXml = (xml: string): string => {
    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(xml, 'application/xml');
      
      // Check for parsing errors
      const parseError = xmlDoc.querySelector('parsererror');
      if (parseError) {
        throw new Error(parseError.textContent || 'Invalid XML');
      }

      return formatXmlNode(xmlDoc, 0);
    } catch (error) {
      throw error;
    }
  };

  const formatXmlNode = (node: Node, depth: number): string => {
    const indent = '  '.repeat(depth);
    
    if (node.nodeType === Node.DOCUMENT_NODE) {
      const children = Array.from(node.childNodes);
      return children.map(child => formatXmlNode(child, depth)).join('\n');
    }
    
    if (node.nodeType === Node.ELEMENT_NODE) {
      const element = node as Element;
      const tagName = element.tagName;
      const attributes = Array.from(element.attributes)
        .map(attr => ` ${attr.name}="${attr.value}"`)
        .join('');
      
      const children = Array.from(element.childNodes);
      const hasElementChildren = children.some(child => child.nodeType === Node.ELEMENT_NODE);
      const textContent = children
        .filter(child => child.nodeType === Node.TEXT_NODE)
        .map(child => child.textContent?.trim())
        .filter(text => text)
        .join('');

      if (children.length === 0) {
        return `${indent}<${tagName}${attributes} />`;
      }
      
      if (!hasElementChildren && textContent) {
        return `${indent}<${tagName}${attributes}>${textContent}</${tagName}>`;
      }
      
      const formattedChildren = children
        .map(child => formatXmlNode(child, depth + 1))
        .filter(formatted => formatted.trim())
        .join('\n');
      
      if (!formattedChildren.trim()) {
        return `${indent}<${tagName}${attributes}></${tagName}>`;
      }
      
      return `${indent}<${tagName}${attributes}>\n${formattedChildren}\n${indent}</${tagName}>`;
    }
    
    if (node.nodeType === Node.TEXT_NODE) {
      const text = node.textContent?.trim();
      return text ? `${indent}${text}` : '';
    }
    
    if (node.nodeType === Node.COMMENT_NODE) {
      return `${indent}<!-- ${node.textContent} -->`;
    }
    
    if (node.nodeType === Node.PROCESSING_INSTRUCTION_NODE) {
      const pi = node as ProcessingInstruction;
      return `${indent}<?${pi.target} ${pi.data}?>`;
    }
    
    return '';
  };

  const processXml = (action: 'format' | 'minify' | 'validate') => {
    if (!input.trim()) {
      setOutput('');
      setError('');
      setIsValid(true);
      return;
    }

    try {
      const parser = new DOMParser();
      const xmlDoc = parser.parseFromString(input.trim(), 'application/xml');
      
      const parseError = xmlDoc.querySelector('parsererror');
      if (parseError) {
        throw new Error(parseError.textContent || 'Invalid XML syntax');
      }

      setError('');
      setIsValid(true);

      if (action === 'validate') {
        toast({
          title: "Success",
          description: "XML is valid"
        });
        return;
      }

      let result = '';
      
      if (action === 'format') {
        result = formatXml(input.trim());
      } else if (action === 'minify') {
        // Minify by removing extra whitespace
        result = input.trim()
          .replace(/>\s+</g, '><')
          .replace(/\s+/g, ' ')
          .trim();
      }

      setOutput(result);
      
      const originalSize = new Blob([input]).size;
      const processedSize = new Blob([result]).size;
      const change = action === 'minify' ? 'reduction' : 'increase';
      const percentage = ((Math.abs(originalSize - processedSize) / originalSize) * 100).toFixed(1);
      
      toast({
        title: "Success",
        description: `XML ${action}ted successfully. ${percentage}% size ${change}.`
      });
    } catch (err) {
      setIsValid(false);
      setError((err as Error).message);
      setOutput('');
      toast({
        title: "Error",
        description: "Invalid XML format",
        variant: "destructive"
      });
    }
  };

  const copyOutput = async () => {
    if (!output) return;
    
    try {
      await copyToClipboard(output);
      toast({
        title: "Success",
        description: "XML copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy XML",
        variant: "destructive"
      });
    }
  };

  const downloadOutput = () => {
    if (!output) return;
    downloadFile(output, 'formatted.xml', 'application/xml');
  };

  const loadSampleXml = () => {
    const sampleXml = `<?xml version="1.0" encoding="UTF-8"?>
<bookstore>
<book id="1" category="fiction">
<title lang="en">The Great Gatsby</title>
<author>F. Scott Fitzgerald</author>
<year>1925</year>
<price currency="USD">12.99</price>
</book>
<book id="2" category="fiction">
<title lang="en">To Kill a Mockingbird</title>
<author>Harper Lee</author>
<year>1960</year>
<price currency="USD">14.99</price>
</book>
</bookstore>`;
    setInput(sampleXml);
  };

  const originalSize = input ? new Blob([input]).size : 0;
  const formattedSize = output ? new Blob([output]).size : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <FileCode className="mx-auto w-16 h-16 text-yellow-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">XML Formatter</h1>
          <p className="text-xl text-gray-600">Format and validate XML documents</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Input XML
                <Button variant="outline" size="sm" onClick={loadSampleXml}>
                  Load Sample
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Paste your XML here..."
                className="min-h-[400px] font-mono text-sm"
              />
              
              <div className="flex gap-2 flex-wrap">
                <Button onClick={() => processXml('format')} className="flex-1">
                  Format XML
                </Button>
                <Button onClick={() => processXml('minify')} variant="outline" className="flex-1">
                  Minify XML
                </Button>
                <Button onClick={() => processXml('validate')} variant="outline" className="flex-1">
                  Validate
                </Button>
              </div>

              {originalSize > 0 && (
                <p className="text-sm text-gray-600">
                  Original size: {formatBytes(originalSize)}
                </p>
              )}

              {error && (
                <Alert className="border-red-200 bg-red-50">
                  <XCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-800">
                    <strong>XML Error:</strong> {error}
                  </AlertDescription>
                </Alert>
              )}

              {isValid && input && !error && (
                <Alert className="border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    Valid XML document
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Formatted XML
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyOutput}
                    disabled={!output}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadOutput}
                    disabled={!output}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={output}
                readOnly
                placeholder="Formatted XML will appear here..."
                className="min-h-[400px] font-mono text-sm"
              />
              
              {formattedSize > 0 && (
                <div className="mt-4 text-sm text-gray-600">
                  <p>Formatted size: {formatBytes(formattedSize)}</p>
                  {originalSize > 0 && (
                    <p>
                      Size change: {formattedSize > originalSize ? '+' : ''}
                      {((formattedSize - originalSize) / originalSize * 100).toFixed(1)}%
                    </p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>XML Formatting Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
              <div>
                <h4 className="font-medium mb-2">Format XML:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Proper indentation</li>
                  <li>• Line breaks for readability</li>
                  <li>• Attribute formatting</li>
                  <li>• Consistent spacing</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Minify XML:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Remove extra whitespace</li>
                  <li>• Compact formatting</li>
                  <li>• Reduce file size</li>
                  <li>• Optimize for transmission</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Validate XML:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Check syntax errors</li>
                  <li>• Verify well-formed structure</li>
                  <li>• Identify parsing issues</li>
                  <li>• Display error details</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
