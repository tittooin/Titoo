import { useState, useRef } from "react";
import { Star, Upload, Download, Grid, Palette } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface FaviconSize {
  size: number;
  name: string;
  purpose: string;
}

export default function FaviconGenerator() {
  const [sourceImage, setSourceImage] = useState<string | null>(null);
  const [favicons, setFavicons] = useState<{ [key: number]: string }>({});
  const [text, setText] = useState('');
  const [backgroundColor, setBackgroundColor] = useState('#ffffff');
  const [textColor, setTextColor] = useState('#000000');
  const [fontSize, setFontSize] = useState(32);
  const [fontFamily, setFontFamily] = useState('Arial');
  const [processing, setProcessing] = useState(false);
  const [generationType, setGenerationType] = useState<'image' | 'text'>('image');
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const faviconSizes: FaviconSize[] = [
    { size: 16, name: 'favicon-16x16.png', purpose: 'Browser tab' },
    { size: 32, name: 'favicon-32x32.png', purpose: 'Browser tab (high DPI)' },
    { size: 48, name: 'favicon-48x48.png', purpose: 'Windows site icons' },
    { size: 64, name: 'favicon-64x64.png', purpose: 'Windows site icons' },
    { size: 96, name: 'favicon-96x96.png', purpose: 'Android Chrome' },
    { size: 120, name: 'apple-touch-icon-120x120.png', purpose: 'iPhone retina' },
    { size: 144, name: 'apple-touch-icon-144x144.png', purpose: 'iPad retina' },
    { size: 152, name: 'apple-touch-icon-152x152.png', purpose: 'iPad retina' },
    { size: 180, name: 'apple-touch-icon-180x180.png', purpose: 'iPhone 6 Plus' },
    { size: 192, name: 'android-chrome-192x192.png', purpose: 'Android Chrome' },
    { size: 512, name: 'android-chrome-512x512.png', purpose: 'Android Chrome' }
  ];

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please select a valid image file",
        variant: "destructive"
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setSourceImage(imageUrl);
      setGenerationType('image');
    };
    reader.readAsDataURL(file);
  };

  const generateFromImage = (size: number): Promise<string> => {
    return new Promise((resolve) => {
      if (!sourceImage || !canvasRef.current) {
        resolve('');
        return;
      }

      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve('');
        return;
      }

      const img = new Image();
      img.onload = () => {
        canvas.width = size;
        canvas.height = size;
        
        // Clear canvas
        ctx.clearRect(0, 0, size, size);
        
        // Calculate dimensions to maintain aspect ratio and center the image
        const imgAspect = img.width / img.height;
        let drawWidth = size;
        let drawHeight = size;
        let drawX = 0;
        let drawY = 0;

        if (imgAspect > 1) {
          drawHeight = size / imgAspect;
          drawY = (size - drawHeight) / 2;
        } else {
          drawWidth = size * imgAspect;
          drawX = (size - drawWidth) / 2;
        }
        
        // Draw image
        ctx.drawImage(img, drawX, drawY, drawWidth, drawHeight);
        
        resolve(canvas.toDataURL('image/png'));
      };
      
      img.src = sourceImage;
    });
  };

  const generateFromText = (size: number): Promise<string> => {
    return new Promise((resolve) => {
      if (!canvasRef.current) {
        resolve('');
        return;
      }

      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve('');
        return;
      }

      canvas.width = size;
      canvas.height = size;
      
      // Fill background
      ctx.fillStyle = backgroundColor;
      ctx.fillRect(0, 0, size, size);
      
      // Draw text
      const scaledFontSize = (fontSize * size) / 64; // Scale font size relative to canvas size
      ctx.fillStyle = textColor;
      ctx.font = `${scaledFontSize}px ${fontFamily}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      
      // Handle multi-character text by taking first 2 characters
      const displayText = text.slice(0, 2).toUpperCase();
      ctx.fillText(displayText, size / 2, size / 2);
      
      resolve(canvas.toDataURL('image/png'));
    });
  };

  const generateFavicons = async () => {
    if (generationType === 'image' && !sourceImage) {
      toast({
        title: "Error",
        description: "Please upload an image first",
        variant: "destructive"
      });
      return;
    }

    if (generationType === 'text' && !text.trim()) {
      toast({
        title: "Error",
        description: "Please enter text for the favicon",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    const newFavicons: { [key: number]: string } = {};

    try {
      for (const faviconSize of faviconSizes) {
        const dataUrl = generationType === 'image' 
          ? await generateFromImage(faviconSize.size)
          : await generateFromText(faviconSize.size);
        
        if (dataUrl) {
          newFavicons[faviconSize.size] = dataUrl;
        }
      }

      setFavicons(newFavicons);
      toast({
        title: "Success",
        description: `Generated ${Object.keys(newFavicons).length} favicon sizes`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate favicons",
        variant: "destructive"
      });
    } finally {
      setProcessing(false);
    }
  };

  const downloadFavicon = (size: number, filename: string) => {
    const dataUrl = favicons[size];
    if (!dataUrl) return;

    const link = document.createElement('a');
    link.href = dataUrl;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const downloadAllFavicons = () => {
    faviconSizes.forEach(({ size, name }) => {
      if (favicons[size]) {
        setTimeout(() => downloadFavicon(size, name), size); // Stagger downloads
      }
    });
  };

  const generateHtmlCode = () => {
    const htmlLines = [
      '<!-- Favicon links for HTML <head> section -->',
      '<link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">',
      '<link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png">',
      '<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon-180x180.png">',
      '<link rel="apple-touch-icon" sizes="152x152" href="/apple-touch-icon-152x152.png">',
      '<link rel="apple-touch-icon" sizes="144x144" href="/apple-touch-icon-144x144.png">',
      '<link rel="apple-touch-icon" sizes="120x120" href="/apple-touch-icon-120x120.png">',
      '<link rel="manifest" href="/site.webmanifest">',
      '<meta name="theme-color" content="#ffffff">'
    ];
    return htmlLines.join('\n');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Star className="mx-auto w-16 h-16 text-orange-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Favicon Generator</h1>
          <p className="text-xl text-gray-600">Create favicons from images or text</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Favicon Source</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={generationType} onValueChange={(value) => setGenerationType(value as 'image' | 'text')}>
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="image" className="flex items-center gap-2">
                      <Upload className="w-4 h-4" />
                      From Image
                    </TabsTrigger>
                    <TabsTrigger value="text" className="flex items-center gap-2">
                      <Palette className="w-4 h-4" />
                      From Text
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="image" className="space-y-4">
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                      <Upload className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                      <div className="space-y-2">
                        <p className="text-lg font-medium text-gray-900">Upload your image</p>
                        <p className="text-gray-500">Square images work best (JPG, PNG, SVG)</p>
                        <input
                          ref={fileInputRef}
                          type="file"
                          onChange={handleImageUpload}
                          accept="image/*"
                          className="hidden"
                          id="image-upload"
                        />
                        <label htmlFor="image-upload">
                          <Button variant="outline" className="cursor-pointer">
                            Choose Image
                          </Button>
                        </label>
                      </div>
                    </div>

                    {sourceImage && (
                      <div className="text-center">
                        <Label>Preview</Label>
                        <img
                          src={sourceImage}
                          alt="Source"
                          className="mx-auto w-32 h-32 object-cover border border-gray-300 rounded-lg mt-2"
                        />
                      </div>
                    )}
                  </TabsContent>
                  
                  <TabsContent value="text" className="space-y-4">
                    <div>
                      <Label htmlFor="favicon-text">Text (1-2 characters)</Label>
                      <Input
                        id="favicon-text"
                        value={text}
                        onChange={(e) => setText(e.target.value.slice(0, 2))}
                        placeholder="AB"
                        className="mt-2 text-center text-2xl font-bold"
                        maxLength={2}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="bg-color">Background Color</Label>
                        <div className="flex gap-2 mt-2">
                          <input
                            id="bg-color"
                            type="color"
                            value={backgroundColor}
                            onChange={(e) => setBackgroundColor(e.target.value)}
                            className="w-12 h-10 border border-gray-300 rounded cursor-pointer"
                          />
                          <Input
                            value={backgroundColor}
                            onChange={(e) => setBackgroundColor(e.target.value)}
                            className="font-mono"
                          />
                        </div>
                      </div>
                      
                      <div>
                        <Label htmlFor="text-color">Text Color</Label>
                        <div className="flex gap-2 mt-2">
                          <input
                            id="text-color"
                            type="color"
                            value={textColor}
                            onChange={(e) => setTextColor(e.target.value)}
                            className="w-12 h-10 border border-gray-300 rounded cursor-pointer"
                          />
                          <Input
                            value={textColor}
                            onChange={(e) => setTextColor(e.target.value)}
                            className="font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="font-family">Font Family</Label>
                      <Select value={fontFamily} onValueChange={setFontFamily}>
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Arial">Arial</SelectItem>
                          <SelectItem value="Helvetica">Helvetica</SelectItem>
                          <SelectItem value="Times New Roman">Times New Roman</SelectItem>
                          <SelectItem value="Georgia">Georgia</SelectItem>
                          <SelectItem value="Verdana">Verdana</SelectItem>
                          <SelectItem value="Courier New">Courier New</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="font-size">Font Size: {fontSize}px</Label>
                      <input
                        id="font-size"
                        type="range"
                        min="16"
                        max="48"
                        value={fontSize}
                        onChange={(e) => setFontSize(parseInt(e.target.value))}
                        className="w-full mt-2"
                      />
                    </div>

                    {text && (
                      <div className="text-center">
                        <Label>Preview</Label>
                        <div 
                          className="mx-auto w-16 h-16 border border-gray-300 rounded-lg mt-2 flex items-center justify-center font-bold"
                          style={{ 
                            backgroundColor, 
                            color: textColor,
                            fontFamily,
                            fontSize: '20px'
                          }}
                        >
                          {text.slice(0, 2).toUpperCase()}
                        </div>
                      </div>
                    )}
                  </TabsContent>
                </Tabs>

                <Button
                  onClick={generateFavicons}
                  disabled={processing || (generationType === 'image' && !sourceImage) || (generationType === 'text' && !text.trim())}
                  className="w-full mt-4"
                >
                  {processing ? (
                    <>Generating...</>
                  ) : (
                    <>
                      <Grid className="w-4 h-4 mr-2" />
                      Generate Favicons
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {Object.keys(favicons).length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    HTML Code
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigator.clipboard.writeText(generateHtmlCode())}
                    >
                      Copy Code
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-xs bg-gray-100 p-3 rounded-lg overflow-x-auto">
                    {generateHtmlCode()}
                  </pre>
                </CardContent>
              </Card>
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Generated Favicons
                <Button
                  variant="outline"
                  size="sm"
                  onClick={downloadAllFavicons}
                  disabled={Object.keys(favicons).length === 0}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download All
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {Object.keys(favicons).length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {faviconSizes.map(({ size, name, purpose }) => (
                    favicons[size] && (
                      <div key={size} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <img
                            src={favicons[size]}
                            alt={`${size}x${size}`}
                            className="border border-gray-300 rounded"
                            style={{ width: Math.min(size, 32), height: Math.min(size, 32) }}
                          />
                          <div>
                            <div className="font-medium">{size}×{size}px</div>
                            <div className="text-sm text-gray-600">{purpose}</div>
                          </div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => downloadFavicon(size, name)}
                        >
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    )
                  ))}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="text-center">
                    <Star className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                    <p className="text-gray-500">Generated favicons will appear here</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <canvas ref={canvasRef} className="hidden" />

        <Alert className="mt-8">
          <AlertDescription>
            <strong>Installation Instructions:</strong>
            <br />
            1. Download all favicon files and upload them to your website's root directory
            <br />
            2. Copy the HTML code and paste it in your website's &lt;head&gt; section
            <br />
            3. Test your favicons by visiting your website in different browsers and devices
          </AlertDescription>
        </Alert>
      </div>

      <Footer />
    </div>
  );
}
