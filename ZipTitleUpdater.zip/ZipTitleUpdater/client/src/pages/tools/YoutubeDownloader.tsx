import { useState } from "react";
import { Download, Youtube, AlertTriangle } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function YoutubeDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const handleDownload = async () => {
    if (!url.trim()) return;
    
    setLoading(true);
    // Simulate loading
    setTimeout(() => {
      setLoading(false);
      alert('YouTube downloader would be implemented here with appropriate APIs and libraries');
    }, 2000);
  };

  const isValidYouTubeUrl = (url: string) => {
    const pattern = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w-]+/;
    return pattern.test(url);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Youtube className="mx-auto w-16 h-16 text-red-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">YouTube Downloader</h1>
          <p className="text-xl text-gray-600">Download YouTube videos in various formats</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Download Video</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Alert className="border-amber-200 bg-amber-50">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <AlertDescription className="text-amber-800">
                <strong>Note:</strong> This is a demo interface. Actual YouTube downloading 
                requires compliance with YouTube's Terms of Service and may require special APIs 
                or third-party services.
              </AlertDescription>
            </Alert>

            <div>
              <Label htmlFor="youtube-url">YouTube URL</Label>
              <Input
                id="youtube-url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://www.youtube.com/watch?v=..."
                className="mt-2"
              />
              {url && !isValidYouTubeUrl(url) && (
                <p className="text-sm text-red-600 mt-1">Please enter a valid YouTube URL</p>
              )}
            </div>

            <Button 
              onClick={handleDownload} 
              disabled={!url || !isValidYouTubeUrl(url) || loading}
              className="w-full"
            >
              {loading ? (
                <>Preparing Download...</>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Download Video
                </>
              )}
            </Button>

            <Alert>
              <AlertDescription>
                <strong>Supported formats:</strong> MP4, MP3, WEBM, AVI
                <br />
                <strong>Quality options:</strong> 720p, 1080p, 4K (when available)
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
