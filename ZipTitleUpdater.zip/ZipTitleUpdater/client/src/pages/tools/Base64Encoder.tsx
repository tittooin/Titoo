import { useState } from "react";
import { Code, Copy, Download } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

export default function Base64Encoder() {
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const { toast } = useToast();

  const encode = () => {
    if (!input) {
      setOutput('');
      return;
    }
    
    try {
      const encoded = btoa(input);
      setOutput(encoded);
      toast({
        title: "Success",
        description: "Text encoded to Base64"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to encode text",
        variant: "destructive"
      });
    }
  };

  const decode = () => {
    if (!input) {
      setOutput('');
      return;
    }
    
    try {
      const decoded = atob(input);
      setOutput(decoded);
      toast({
        title: "Success",
        description: "Base64 decoded to text"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Invalid Base64 string",
        variant: "destructive"
      });
    }
  };

  const copyOutput = async () => {
    if (!output) return;
    
    try {
      await copyToClipboard(output);
      toast({
        title: "Success",
        description: "Output copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy output",
        variant: "destructive"
      });
    }
  };

  const downloadOutput = () => {
    if (!output) return;
    downloadFile(output, 'output.txt');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Code className="mx-auto w-16 h-16 text-gray-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Base64 Encoder</h1>
          <p className="text-xl text-gray-600">Encode and decode Base64 strings</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Base64 Encoder/Decoder</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Tabs defaultValue="encode" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="encode">Encode</TabsTrigger>
                <TabsTrigger value="decode">Decode</TabsTrigger>
              </TabsList>
              
              <TabsContent value="encode" className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Text to Encode
                  </label>
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Enter text to encode to Base64..."
                    className="min-h-[200px]"
                  />
                </div>
                <Button onClick={encode} className="w-full">
                  Encode to Base64
                </Button>
              </TabsContent>
              
              <TabsContent value="decode" className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Base64 to Decode
                  </label>
                  <Textarea
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Enter Base64 string to decode..."
                    className="min-h-[200px] font-mono"
                  />
                </div>
                <Button onClick={decode} className="w-full">
                  Decode from Base64
                </Button>
              </TabsContent>
            </Tabs>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="block text-sm font-medium text-gray-700">
                  Output
                </label>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={copyOutput}
                    disabled={!output}
                  >
                    <Copy className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={downloadOutput}
                    disabled={!output}
                  >
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <Textarea
                value={output}
                readOnly
                placeholder="Output will appear here..."
                className="min-h-[200px] font-mono"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
