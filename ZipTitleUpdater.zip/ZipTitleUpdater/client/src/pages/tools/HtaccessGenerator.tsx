import { useState } from "react";
import { Settings, Copy, Download, Shield, Zap } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

interface RedirectRule {
  from: string;
  to: string;
  type: string;
}

interface SecurityRule {
  blockBadBots: boolean;
  preventHotlinking: boolean;
  hideServerInfo: boolean;
  preventDirectoryBrowsing: boolean;
  blockSuspiciousRequests: boolean;
  enableXSSProtection: boolean;
}

interface PerformanceRule {
  enableGzipCompression: boolean;
  enableBrowserCaching: boolean;
  enableKeepAlive: boolean;
  optimizeEtags: boolean;
}

export default function HtaccessGenerator() {
  const [redirects, setRedirects] = useState<RedirectRule[]>([
    { from: '', to: '', type: '301' }
  ]);
  
  const [customRules, setCustomRules] = useState('');
  
  const [security, setSecurity] = useState<SecurityRule>({
    blockBadBots: false,
    preventHotlinking: false,
    hideServerInfo: false,
    preventDirectoryBrowsing: false,
    blockSuspiciousRequests: false,
    enableXSSProtection: false
  });

  const [performance, setPerformance] = useState<PerformanceRule>({
    enableGzipCompression: false,
    enableBrowserCaching: false,
    enableKeepAlive: false,
    optimizeEtags: false
  });

  const [wwwSettings, setWwwSettings] = useState({
    forceWww: false,
    forceNoWww: false,
    forceHttps: false
  });

  const { toast } = useToast();

  const addRedirect = () => {
    setRedirects([...redirects, { from: '', to: '', type: '301' }]);
  };

  const updateRedirect = (index: number, field: keyof RedirectRule, value: string) => {
    const newRedirects = [...redirects];
    newRedirects[index] = { ...newRedirects[index], [field]: value };
    setRedirects(newRedirects);
  };

  const removeRedirect = (index: number) => {
    if (redirects.length > 1) {
      setRedirects(redirects.filter((_, i) => i !== index));
    }
  };

  const generateHtaccess = () => {
    let htaccess = '# Generated .htaccess file\n\n';

    // WWW and HTTPS settings
    if (wwwSettings.forceHttps) {
      htaccess += '# Force HTTPS\n';
      htaccess += 'RewriteEngine On\n';
      htaccess += 'RewriteCond %{HTTPS} off\n';
      htaccess += 'RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]\n\n';
    }

    if (wwwSettings.forceWww) {
      htaccess += '# Force WWW\n';
      htaccess += 'RewriteEngine On\n';
      htaccess += 'RewriteCond %{HTTP_HOST} !^www\\. [NC]\n';
      htaccess += 'RewriteRule ^(.*)$ https://www.%{HTTP_HOST}%{REQUEST_URI} [L,R=301]\n\n';
    } else if (wwwSettings.forceNoWww) {
      htaccess += '# Remove WWW\n';
      htaccess += 'RewriteEngine On\n';
      htaccess += 'RewriteCond %{HTTP_HOST} ^www\\.(.+)$ [NC]\n';
      htaccess += 'RewriteRule ^(.*)$ https://%1%{REQUEST_URI} [L,R=301]\n\n';
    }

    // Redirects
    const validRedirects = redirects.filter(r => r.from.trim() && r.to.trim());
    if (validRedirects.length > 0) {
      htaccess += '# Redirects\n';
      htaccess += 'RewriteEngine On\n';
      validRedirects.forEach(redirect => {
        htaccess += `Redirect ${redirect.type} ${redirect.from} ${redirect.to}\n`;
      });
      htaccess += '\n';
    }

    // Security rules
    if (Object.values(security).some(Boolean)) {
      htaccess += '# Security Rules\n';
      
      if (security.preventDirectoryBrowsing) {
        htaccess += 'Options -Indexes\n';
      }
      
      if (security.hideServerInfo) {
        htaccess += 'ServerTokens Prod\n';
        htaccess += 'ServerSignature Off\n';
      }
      
      if (security.enableXSSProtection) {
        htaccess += '<IfModule mod_headers.c>\n';
        htaccess += '    Header always set X-XSS-Protection "1; mode=block"\n';
        htaccess += '    Header always set X-Content-Type-Options "nosniff"\n';
        htaccess += '    Header always set X-Frame-Options "SAMEORIGIN"\n';
        htaccess += '</IfModule>\n';
      }
      
      if (security.blockBadBots) {
        htaccess += '<IfModule mod_rewrite.c>\n';
        htaccess += '    RewriteEngine On\n';
        htaccess += '    RewriteCond %{HTTP_USER_AGENT} (libwww-perl|wget|python|nikto|curl|scan|java|winhttp|clshttp|loader) [NC,OR]\n';
        htaccess += '    RewriteCond %{HTTP_USER_AGENT} (%0A|%0D|%27|%3C|%3E|%00) [NC,OR]\n';
        htaccess += '    RewriteCond %{HTTP_USER_AGENT} (;|<|>|\'|"|\)|\(|%0A|%0D|%22|%27|%28|%3C|%3E|%00).*(libwww-perl|wget|python|nikto|curl|scan|java|winhttp|HTTrack|clshttp|archiver|loader|email|harvest|extract|grab|miner) [NC]\n';
        htaccess += '    RewriteRule .* - [F,L]\n';
        htaccess += '</IfModule>\n';
      }
      
      if (security.preventHotlinking) {
        htaccess += '<IfModule mod_rewrite.c>\n';
        htaccess += '    RewriteEngine on\n';
        htaccess += '    RewriteCond %{HTTP_REFERER} !^$\n';
        htaccess += '    RewriteCond %{HTTP_REFERER} !^http(s)?://(www\\.)?yourdomain.com [NC]\n';
        htaccess += '    RewriteRule \\.(jpg|jpeg|png|gif|bmp)$ - [NC,F,L]\n';
        htaccess += '</IfModule>\n';
      }
      
      if (security.blockSuspiciousRequests) {
        htaccess += '<IfModule mod_rewrite.c>\n';
        htaccess += '    RewriteEngine On\n';
        htaccess += '    RewriteCond %{QUERY_STRING} (<|%3C).*script.*(>|%3E) [NC,OR]\n';
        htaccess += '    RewriteCond %{QUERY_STRING} GLOBALS(=|\\[|\\%[0-9A-Z]{0,2}) [OR]\n';
        htaccess += '    RewriteCond %{QUERY_STRING} _REQUEST(=|\\[|\\%[0-9A-Z]{0,2}) [OR]\n';
        htaccess += '    RewriteCond %{QUERY_STRING} proc/self/environ [OR]\n';
        htaccess += '    RewriteCond %{QUERY_STRING} mosConfig_[a-zA-Z_]{1,21}(=|\\%3D) [OR]\n';
        htaccess += '    RewriteCond %{QUERY_STRING} base64_(en|de)code\\(.*\\) [OR]\n';
        htaccess += '    RewriteCond %{QUERY_STRING} ^.*\\([\\(].*[\\)].*$ [NC]\n';
        htaccess += '    RewriteRule .* - [F,L]\n';
        htaccess += '</IfModule>\n';
      }
      
      htaccess += '\n';
    }

    // Performance rules
    if (Object.values(performance).some(Boolean)) {
      htaccess += '# Performance Optimization\n';
      
      if (performance.enableGzipCompression) {
        htaccess += '<IfModule mod_deflate.c>\n';
        htaccess += '    AddOutputFilterByType DEFLATE text/plain\n';
        htaccess += '    AddOutputFilterByType DEFLATE text/html\n';
        htaccess += '    AddOutputFilterByType DEFLATE text/xml\n';
        htaccess += '    AddOutputFilterByType DEFLATE text/css\n';
        htaccess += '    AddOutputFilterByType DEFLATE application/xml\n';
        htaccess += '    AddOutputFilterByType DEFLATE application/xhtml+xml\n';
        htaccess += '    AddOutputFilterByType DEFLATE application/rss+xml\n';
        htaccess += '    AddOutputFilterByType DEFLATE application/javascript\n';
        htaccess += '    AddOutputFilterByType DEFLATE application/x-javascript\n';
        htaccess += '</IfModule>\n';
      }
      
      if (performance.enableBrowserCaching) {
        htaccess += '<IfModule mod_expires.c>\n';
        htaccess += '    ExpiresActive on\n';
        htaccess += '    ExpiresByType text/css "access plus 1 year"\n';
        htaccess += '    ExpiresByType application/javascript "access plus 1 year"\n';
        htaccess += '    ExpiresByType image/png "access plus 1 year"\n';
        htaccess += '    ExpiresByType image/jpg "access plus 1 year"\n';
        htaccess += '    ExpiresByType image/jpeg "access plus 1 year"\n';
        htaccess += '    ExpiresByType image/gif "access plus 1 year"\n';
        htaccess += '    ExpiresByType image/svg+xml "access plus 1 year"\n';
        htaccess += '    ExpiresByType image/x-icon "access plus 1 year"\n';
        htaccess += '    ExpiresByType application/pdf "access plus 1 month"\n';
        htaccess += '    ExpiresByType text/html "access plus 1 hour"\n';
        htaccess += '</IfModule>\n';
      }
      
      if (performance.enableKeepAlive) {
        htaccess += '<IfModule mod_headers.c>\n';
        htaccess += '    Header set Connection keep-alive\n';
        htaccess += '</IfModule>\n';
      }
      
      if (performance.optimizeEtags) {
        htaccess += 'FileETag None\n';
      }
      
      htaccess += '\n';
    }

    // Custom rules
    if (customRules.trim()) {
      htaccess += '# Custom Rules\n';
      htaccess += customRules + '\n\n';
    }

    return htaccess.trim();
  };

  const copyHtaccess = async () => {
    const content = generateHtaccess();
    if (!content) {
      toast({
        title: "Error",
        description: "No .htaccess content to copy",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await copyToClipboard(content);
      toast({
        title: "Success",
        description: ".htaccess file copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy .htaccess file",
        variant: "destructive"
      });
    }
  };

  const downloadHtaccess = () => {
    const content = generateHtaccess();
    if (!content) {
      toast({
        title: "Error",
        description: "No .htaccess content to download",
        variant: "destructive"
      });
      return;
    }
    
    downloadFile(content, '.htaccess', 'text/plain');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Settings className="mx-auto w-16 h-16 text-red-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">.htaccess Generator</h1>
          <p className="text-xl text-gray-600">Generate .htaccess rules and redirects</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="security">Security</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
                <TabsTrigger value="custom">Custom</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Basic Settings</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="force-https"
                          checked={wwwSettings.forceHttps}
                          onCheckedChange={(checked) => 
                            setWwwSettings(prev => ({ ...prev, forceHttps: checked as boolean }))
                          }
                        />
                        <Label htmlFor="force-https">Force HTTPS</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="force-www"
                          checked={wwwSettings.forceWww}
                          onCheckedChange={(checked) => 
                            setWwwSettings(prev => ({ 
                              ...prev, 
                              forceWww: checked as boolean,
                              forceNoWww: checked ? false : prev.forceNoWww
                            }))
                          }
                        />
                        <Label htmlFor="force-www">Force WWW</Label>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id="force-no-www"
                          checked={wwwSettings.forceNoWww}
                          onCheckedChange={(checked) => 
                            setWwwSettings(prev => ({ 
                              ...prev, 
                              forceNoWww: checked as boolean,
                              forceWww: checked ? false : prev.forceWww
                            }))
                          }
                        />
                        <Label htmlFor="force-no-www">Remove WWW</Label>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Redirects
                      <Button onClick={addRedirect} size="sm">
                        Add Redirect
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {redirects.map((redirect, index) => (
                      <div key={index} className="p-3 border rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <Label className="text-sm">Redirect {index + 1}</Label>
                          {redirects.length > 1 && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeRedirect(index)}
                            >
                              Remove
                            </Button>
                          )}
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <Input
                            placeholder="From: /old-page"
                            value={redirect.from}
                            onChange={(e) => updateRedirect(index, 'from', e.target.value)}
                          />
                          <Input
                            placeholder="To: /new-page"
                            value={redirect.to}
                            onChange={(e) => updateRedirect(index, 'to', e.target.value)}
                          />
                        </div>
                        <select
                          value={redirect.type}
                          onChange={(e) => updateRedirect(index, 'type', e.target.value)}
                          className="w-full p-2 border rounded"
                        >
                          <option value="301">301 Permanent</option>
                          <option value="302">302 Temporary</option>
                        </select>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="security" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Shield className="w-5 h-5" />
                      Security Rules
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="block-bots"
                        checked={security.blockBadBots}
                        onCheckedChange={(checked) => 
                          setSecurity(prev => ({ ...prev, blockBadBots: checked as boolean }))
                        }
                      />
                      <Label htmlFor="block-bots">Block malicious bots</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="prevent-hotlinking"
                        checked={security.preventHotlinking}
                        onCheckedChange={(checked) => 
                          setSecurity(prev => ({ ...prev, preventHotlinking: checked as boolean }))
                        }
                      />
                      <Label htmlFor="prevent-hotlinking">Prevent image hotlinking</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="hide-server"
                        checked={security.hideServerInfo}
                        onCheckedChange={(checked) => 
                          setSecurity(prev => ({ ...prev, hideServerInfo: checked as boolean }))
                        }
                      />
                      <Label htmlFor="hide-server">Hide server information</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="directory-browsing"
                        checked={security.preventDirectoryBrowsing}
                        onCheckedChange={(checked) => 
                          setSecurity(prev => ({ ...prev, preventDirectoryBrowsing: checked as boolean }))
                        }
                      />
                      <Label htmlFor="directory-browsing">Prevent directory browsing</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="block-suspicious"
                        checked={security.blockSuspiciousRequests}
                        onCheckedChange={(checked) => 
                          setSecurity(prev => ({ ...prev, blockSuspiciousRequests: checked as boolean }))
                        }
                      />
                      <Label htmlFor="block-suspicious">Block suspicious requests</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="xss-protection"
                        checked={security.enableXSSProtection}
                        onCheckedChange={(checked) => 
                          setSecurity(prev => ({ ...prev, enableXSSProtection: checked as boolean }))
                        }
                      />
                      <Label htmlFor="xss-protection">Enable XSS protection headers</Label>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="performance" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="w-5 h-5" />
                      Performance Optimization
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="gzip"
                        checked={performance.enableGzipCompression}
                        onCheckedChange={(checked) => 
                          setPerformance(prev => ({ ...prev, enableGzipCompression: checked as boolean }))
                        }
                      />
                      <Label htmlFor="gzip">Enable Gzip compression</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="browser-caching"
                        checked={performance.enableBrowserCaching}
                        onCheckedChange={(checked) => 
                          setPerformance(prev => ({ ...prev, enableBrowserCaching: checked as boolean }))
                        }
                      />
                      <Label htmlFor="browser-caching">Enable browser caching</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="keep-alive"
                        checked={performance.enableKeepAlive}
                        onCheckedChange={(checked) => 
                          setPerformance(prev => ({ ...prev, enableKeepAlive: checked as boolean }))
                        }
                      />
                      <Label htmlFor="keep-alive">Enable Keep-Alive</Label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="etags"
                        checked={performance.optimizeEtags}
                        onCheckedChange={(checked) => 
                          setPerformance(prev => ({ ...prev, optimizeEtags: checked as boolean }))
                        }
                      />
                      <Label htmlFor="etags">Optimize ETags</Label>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="custom" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle>Custom Rules</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div>
                      <Label htmlFor="custom-rules">Custom .htaccess Rules</Label>
                      <Textarea
                        id="custom-rules"
                        value={customRules}
                        onChange={(e) => setCustomRules(e.target.value)}
                        placeholder="Add your custom .htaccess rules here..."
                        className="mt-2 min-h-[200px] font-mono text-sm"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Generated .htaccess
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={copyHtaccess}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadHtaccess}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={generateHtaccess()}
                readOnly
                placeholder="Generated .htaccess content will appear here..."
                className="min-h-[500px] font-mono text-sm"
              />
              
              <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-medium text-yellow-900 mb-2">⚠️ Important Notes:</h4>
                <ul className="text-sm text-yellow-800 space-y-1">
                  <li>• Always backup your existing .htaccess file</li>
                  <li>• Test changes on a staging environment first</li>
                  <li>• Some rules may not work on all servers</li>
                  <li>• Replace "yourdomain.com" with your actual domain</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
