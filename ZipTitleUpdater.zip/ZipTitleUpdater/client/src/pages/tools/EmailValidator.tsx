import { useState } from "react";
import { Mail, CheckCircle, XCircle, AlertTriangle, Upload } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface EmailValidationResult {
  email: string;
  isValid: boolean;
  errors: string[];
  warnings: string[];
  suggestions?: string;
}

interface EmailAnalysis {
  domain: string;
  localPart: string;
  hasValidSyntax: boolean;
  hasCommonDomain: boolean;
  hasDisposableDomain: boolean;
  hasTypo: boolean;
}

export default function EmailValidator() {
  const [singleEmail, setSingleEmail] = useState('');
  const [bulkEmails, setBulkEmails] = useState('');
  const [results, setResults] = useState<EmailValidationResult[]>([]);
  const [processing, setProcessing] = useState(false);
  const { toast } = useToast();

  const commonDomains = [
    'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com',
    'aol.com', 'live.com', 'msn.com', 'protonmail.com', 'zoho.com'
  ];

  const disposableDomains = [
    '10minutemail.com', 'tempmail.org', 'guerrillamail.com', 'mailinator.com',
    'trash-mail.com', 'throwaway.email', 'temp-mail.org', 'yopmail.com'
  ];

  const domainTypos = {
    'gmai.com': 'gmail.com',
    'gmial.com': 'gmail.com',
    'gmail.co': 'gmail.com',
    'yahooo.com': 'yahoo.com',
    'yaho.com': 'yahoo.com',
    'hotmial.com': 'hotmail.com',
    'hotmai.com': 'hotmail.com',
    'outlok.com': 'outlook.com',
    'outloo.com': 'outlook.com'
  };

  const validateEmailSyntax = (email: string): boolean => {
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    return emailRegex.test(email);
  };

  const analyzeEmail = (email: string): EmailAnalysis => {
    const [localPart, domain] = email.split('@');
    
    return {
      domain: domain || '',
      localPart: localPart || '',
      hasValidSyntax: validateEmailSyntax(email),
      hasCommonDomain: commonDomains.includes(domain?.toLowerCase() || ''),
      hasDisposableDomain: disposableDomains.includes(domain?.toLowerCase() || ''),
      hasTypo: Object.keys(domainTypos).includes(domain?.toLowerCase() || '')
    };
  };

  const validateSingleEmail = (email: string): EmailValidationResult => {
    const trimmedEmail = email.trim().toLowerCase();
    const analysis = analyzeEmail(trimmedEmail);
    const errors: string[] = [];
    const warnings: string[] = [];
    let suggestions: string | undefined;

    // Basic validation
    if (!trimmedEmail) {
      errors.push('Email address is required');
    } else if (!analysis.hasValidSyntax) {
      errors.push('Invalid email format');
    }

    // Length validation
    if (trimmedEmail.length > 254) {
      errors.push('Email address is too long (max 254 characters)');
    }

    if (analysis.localPart.length > 64) {
      errors.push('Local part is too long (max 64 characters)');
    }

    // Domain validation
    if (analysis.domain) {
      if (analysis.domain.length > 253) {
        errors.push('Domain is too long (max 253 characters)');
      }

      if (analysis.hasDisposableDomain) {
        warnings.push('This appears to be a disposable email address');
      }

      if (analysis.hasTypo) {
        const suggestion = domainTypos[analysis.domain.toLowerCase() as keyof typeof domainTypos];
        suggestions = `Did you mean ${analysis.localPart}@${suggestion}?`;
        warnings.push('Possible typo in domain name');
      }

      // Check for consecutive dots
      if (analysis.domain.includes('..')) {
        errors.push('Domain contains consecutive dots');
      }

      // Check for valid domain format
      if (!/^[a-zA-Z0-9.-]+$/.test(analysis.domain)) {
        errors.push('Domain contains invalid characters');
      }

      // Check if domain has at least one dot
      if (!analysis.domain.includes('.')) {
        errors.push('Domain must contain at least one dot');
      }
    }

    // Local part validation
    if (analysis.localPart) {
      // Check for consecutive dots
      if (analysis.localPart.includes('..')) {
        errors.push('Local part contains consecutive dots');
      }

      // Check if starts or ends with dot
      if (analysis.localPart.startsWith('.') || analysis.localPart.endsWith('.')) {
        errors.push('Local part cannot start or end with a dot');
      }

      // Check for valid characters (simplified)
      if (!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(analysis.localPart)) {
        errors.push('Local part contains invalid characters');
      }
    }

    // Additional warnings
    if (analysis.localPart && analysis.localPart.length < 2) {
      warnings.push('Local part is unusually short');
    }

    if (!analysis.hasCommonDomain && !analysis.hasDisposableDomain && analysis.domain) {
      warnings.push('Uncommon domain - verify it\'s correct');
    }

    return {
      email: trimmedEmail,
      isValid: errors.length === 0,
      errors,
      warnings,
      suggestions
    };
  };

  const validateEmails = (emailList: string[]): EmailValidationResult[] => {
    return emailList
      .filter(email => email.trim())
      .map(email => validateSingleEmail(email));
  };

  const handleSingleValidation = () => {
    if (!singleEmail.trim()) {
      toast({
        title: "Error",
        description: "Please enter an email address",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    setTimeout(() => {
      const result = validateSingleEmail(singleEmail);
      setResults([result]);
      setProcessing(false);
      
      toast({
        title: result.isValid ? "Valid Email" : "Invalid Email",
        description: result.isValid 
          ? "Email address is valid" 
          : `Found ${result.errors.length} error(s)`,
        variant: result.isValid ? "default" : "destructive"
      });
    }, 500);
  };

  const handleBulkValidation = () => {
    if (!bulkEmails.trim()) {
      toast({
        title: "Error",
        description: "Please enter email addresses to validate",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    setTimeout(() => {
      const emailList = bulkEmails
        .split('\n')
        .map(email => email.trim())
        .filter(email => email);

      if (emailList.length === 0) {
        toast({
          title: "Error",
          description: "No valid email addresses found",
          variant: "destructive"
        });
        setProcessing(false);
        return;
      }

      const results = validateEmails(emailList);
      setResults(results);
      setProcessing(false);

      const validCount = results.filter(r => r.isValid).length;
      const invalidCount = results.length - validCount;

      toast({
        title: "Validation Complete",
        description: `${validCount} valid, ${invalidCount} invalid out of ${results.length} emails`
      });
    }, 1000);
  };

  const loadSampleEmails = () => {
    const sampleEmails = `user@example.com
test@gmail.com
invalid-email
admin@company.co.uk
user@gmai.com
temp@10minutemail.com
valid.email+tag@domain.org`;
    setBulkEmails(sampleEmails);
  };

  const getStatusIcon = (result: EmailValidationResult) => {
    if (result.isValid && result.warnings.length === 0) {
      return <CheckCircle className="w-5 h-5 text-green-600" />;
    } else if (result.isValid && result.warnings.length > 0) {
      return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
    } else {
      return <XCircle className="w-5 h-5 text-red-600" />;
    }
  };

  const getStatusText = (result: EmailValidationResult) => {
    if (result.isValid && result.warnings.length === 0) return 'Valid';
    if (result.isValid && result.warnings.length > 0) return 'Valid (with warnings)';
    return 'Invalid';
  };

  const getStatusColor = (result: EmailValidationResult) => {
    if (result.isValid && result.warnings.length === 0) return 'bg-green-600';
    if (result.isValid && result.warnings.length > 0) return 'bg-yellow-600';
    return 'bg-red-600';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Mail className="mx-auto w-16 h-16 text-purple-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Email Validator</h1>
          <p className="text-xl text-gray-600">Validate email addresses and check syntax</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Email Validation</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="single" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="single">Single Email</TabsTrigger>
                  <TabsTrigger value="bulk">Bulk Validation</TabsTrigger>
                </TabsList>
                
                <TabsContent value="single" className="space-y-4">
                  <div>
                    <Label htmlFor="single-email">Email Address</Label>
                    <Input
                      id="single-email"
                      type="email"
                      value={singleEmail}
                      onChange={(e) => setSingleEmail(e.target.value)}
                      placeholder="user@example.com"
                      className="mt-2"
                      onKeyPress={(e) => e.key === 'Enter' && handleSingleValidation()}
                    />
                  </div>
                  
                  <Button 
                    onClick={handleSingleValidation}
                    disabled={processing}
                    className="w-full"
                  >
                    {processing ? 'Validating...' : 'Validate Email'}
                  </Button>
                </TabsContent>
                
                <TabsContent value="bulk" className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <Label htmlFor="bulk-emails">Email Addresses (one per line)</Label>
                      <Button variant="outline" size="sm" onClick={loadSampleEmails}>
                        Load Sample
                      </Button>
                    </div>
                    <Textarea
                      id="bulk-emails"
                      value={bulkEmails}
                      onChange={(e) => setBulkEmails(e.target.value)}
                      placeholder={`user1@example.com
user2@gmail.com
user3@company.org`}
                      className="min-h-[150px]"
                    />
                  </div>
                  
                  <Button 
                    onClick={handleBulkValidation}
                    disabled={processing}
                    className="w-full"
                  >
                    {processing ? 'Validating...' : 'Validate Emails'}
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Validation Results</CardTitle>
            </CardHeader>
            <CardContent>
              {results.length > 0 ? (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {results.map((result, index) => (
                    <div key={index} className="p-4 border rounded-lg space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(result)}
                          <span className="font-mono text-sm break-all">{result.email}</span>
                        </div>
                        <Badge className={getStatusColor(result)}>
                          {getStatusText(result)}
                        </Badge>
                      </div>

                      {result.errors.length > 0 && (
                        <div className="space-y-1">
                          <p className="text-sm font-medium text-red-800">Errors:</p>
                          {result.errors.map((error, errorIndex) => (
                            <p key={errorIndex} className="text-sm text-red-600">• {error}</p>
                          ))}
                        </div>
                      )}

                      {result.warnings.length > 0 && (
                        <div className="space-y-1">
                          <p className="text-sm font-medium text-yellow-800">Warnings:</p>
                          {result.warnings.map((warning, warningIndex) => (
                            <p key={warningIndex} className="text-sm text-yellow-600">• {warning}</p>
                          ))}
                        </div>
                      )}

                      {result.suggestions && (
                        <Alert className="border-blue-200 bg-blue-50">
                          <AlertDescription className="text-blue-800">
                            <strong>Suggestion:</strong> {result.suggestions}
                          </AlertDescription>
                        </Alert>
                      )}
                    </div>
                  ))}

                  {results.length > 1 && (
                    <div className="pt-4 border-t">
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div className="p-3 bg-green-50 rounded-lg">
                          <div className="text-2xl font-bold text-green-700">
                            {results.filter(r => r.isValid).length}
                          </div>
                          <div className="text-sm text-green-600">Valid</div>
                        </div>
                        <div className="p-3 bg-red-50 rounded-lg">
                          <div className="text-2xl font-bold text-red-700">
                            {results.filter(r => !r.isValid).length}
                          </div>
                          <div className="text-sm text-red-600">Invalid</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="text-center">
                    <Mail className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                    <p className="text-gray-500">Validation results will appear here</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Email Validation Features</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-sm">
              <div>
                <h4 className="font-medium mb-2">Syntax Validation:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• RFC-compliant email format</li>
                  <li>• Local part validation</li>
                  <li>• Domain structure checking</li>
                  <li>• Character set validation</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Domain Analysis:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Common domain recognition</li>
                  <li>• Disposable email detection</li>
                  <li>• Typo detection and suggestions</li>
                  <li>• Domain format validation</li>
                </ul>
              </div>
              <div>
                <h4 className="font-medium mb-2">Quality Checks:</h4>
                <ul className="space-y-1 text-gray-600">
                  <li>• Length validation</li>
                  <li>• Suspicious pattern detection</li>
                  <li>• Best practice recommendations</li>
                  <li>• Bulk validation support</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
