import { useState } from "react";
import { Tag, Copy, Download, Globe, Share2 } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

interface MetaTags {
  title: string;
  description: string;
  keywords: string;
  author: string;
  robots: string;
  viewport: string;
  charset: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  ogUrl: string;
  ogType: string;
  twitterCard: string;
  twitterSite: string;
  twitterCreator: string;
  twitterTitle: string;
  twitterDescription: string;
  twitterImage: string;
}

export default function MetaTagGenerator() {
  const [metaTags, setMetaTags] = useState<MetaTags>({
    title: '',
    description: '',
    keywords: '',
    author: '',
    robots: 'index, follow',
    viewport: 'width=device-width, initial-scale=1.0',
    charset: 'UTF-8',
    ogTitle: '',
    ogDescription: '',
    ogImage: '',
    ogUrl: '',
    ogType: 'website',
    twitterCard: 'summary_large_image',
    twitterSite: '',
    twitterCreator: '',
    twitterTitle: '',
    twitterDescription: '',
    twitterImage: ''
  });

  const { toast } = useToast();

  const updateMetaTag = (key: keyof MetaTags, value: string) => {
    setMetaTags(prev => ({ ...prev, [key]: value }));
  };

  const generateHTML = () => {
    const tags = [];
    
    // Basic meta tags
    if (metaTags.charset) tags.push(`<meta charset="${metaTags.charset}">`);
    if (metaTags.viewport) tags.push(`<meta name="viewport" content="${metaTags.viewport}">`);
    if (metaTags.title) tags.push(`<title>${metaTags.title}</title>`);
    if (metaTags.description) tags.push(`<meta name="description" content="${metaTags.description}">`);
    if (metaTags.keywords) tags.push(`<meta name="keywords" content="${metaTags.keywords}">`);
    if (metaTags.author) tags.push(`<meta name="author" content="${metaTags.author}">`);
    if (metaTags.robots) tags.push(`<meta name="robots" content="${metaTags.robots}">`);
    
    // Open Graph tags
    if (metaTags.ogTitle) tags.push(`<meta property="og:title" content="${metaTags.ogTitle}">`);
    if (metaTags.ogDescription) tags.push(`<meta property="og:description" content="${metaTags.ogDescription}">`);
    if (metaTags.ogImage) tags.push(`<meta property="og:image" content="${metaTags.ogImage}">`);
    if (metaTags.ogUrl) tags.push(`<meta property="og:url" content="${metaTags.ogUrl}">`);
    if (metaTags.ogType) tags.push(`<meta property="og:type" content="${metaTags.ogType}">`);
    
    // Twitter Card tags
    if (metaTags.twitterCard) tags.push(`<meta name="twitter:card" content="${metaTags.twitterCard}">`);
    if (metaTags.twitterSite) tags.push(`<meta name="twitter:site" content="${metaTags.twitterSite}">`);
    if (metaTags.twitterCreator) tags.push(`<meta name="twitter:creator" content="${metaTags.twitterCreator}">`);
    if (metaTags.twitterTitle) tags.push(`<meta name="twitter:title" content="${metaTags.twitterTitle}">`);
    if (metaTags.twitterDescription) tags.push(`<meta name="twitter:description" content="${metaTags.twitterDescription}">`);
    if (metaTags.twitterImage) tags.push(`<meta name="twitter:image" content="${metaTags.twitterImage}">`);
    
    return tags.join('\n');
  };

  const copyTags = async () => {
    const html = generateHTML();
    if (!html) {
      toast({
        title: "Error",
        description: "No meta tags to copy",
        variant: "destructive"
      });
      return;
    }
    
    try {
      await copyToClipboard(html);
      toast({
        title: "Success",
        description: "Meta tags copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy meta tags",
        variant: "destructive"
      });
    }
  };

  const downloadTags = () => {
    const html = generateHTML();
    if (!html) {
      toast({
        title: "Error",
        description: "No meta tags to download",
        variant: "destructive"
      });
      return;
    }
    
    const fullHTML = `<!DOCTYPE html>
<html lang="en">
<head>
${html}
</head>
<body>
    <!-- Your website content here -->
</body>
</html>`;
    
    downloadFile(fullHTML, 'meta-tags.html', 'text/html');
  };

  const autoFillOG = () => {
    setMetaTags(prev => ({
      ...prev,
      ogTitle: prev.title,
      ogDescription: prev.description
    }));
    toast({
      title: "Success",
      description: "Open Graph tags auto-filled from basic meta tags"
    });
  };

  const autoFillTwitter = () => {
    setMetaTags(prev => ({
      ...prev,
      twitterTitle: prev.ogTitle || prev.title,
      twitterDescription: prev.ogDescription || prev.description,
      twitterImage: prev.ogImage
    }));
    toast({
      title: "Success",
      description: "Twitter Card tags auto-filled from Open Graph tags"
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Tag className="mx-auto w-16 h-16 text-indigo-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Meta Tag Generator</h1>
          <p className="text-xl text-gray-600">Generate HTML meta tags for SEO</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="opengraph">Open Graph</TabsTrigger>
                <TabsTrigger value="twitter">Twitter</TabsTrigger>
              </TabsList>
              
              <TabsContent value="basic" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Globe className="w-5 h-5" />
                      Basic Meta Tags
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="title">Page Title</Label>
                      <Input
                        id="title"
                        value={metaTags.title}
                        onChange={(e) => updateMetaTag('title', e.target.value)}
                        placeholder="Enter page title..."
                        className="mt-2"
                      />
                      <p className="text-xs text-gray-600 mt-1">
                        {metaTags.title.length}/60 characters (optimal: 50-60)
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="description">Meta Description</Label>
                      <Textarea
                        id="description"
                        value={metaTags.description}
                        onChange={(e) => updateMetaTag('description', e.target.value)}
                        placeholder="Enter meta description..."
                        className="mt-2"
                        rows={3}
                      />
                      <p className="text-xs text-gray-600 mt-1">
                        {metaTags.description.length}/160 characters (optimal: 150-160)
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="keywords">Keywords</Label>
                      <Input
                        id="keywords"
                        value={metaTags.keywords}
                        onChange={(e) => updateMetaTag('keywords', e.target.value)}
                        placeholder="keyword1, keyword2, keyword3..."
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="author">Author</Label>
                      <Input
                        id="author"
                        value={metaTags.author}
                        onChange={(e) => updateMetaTag('author', e.target.value)}
                        placeholder="Author name..."
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="robots">Robots</Label>
                      <Select value={metaTags.robots} onValueChange={(value) => updateMetaTag('robots', value)}>
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="index, follow">index, follow</SelectItem>
                          <SelectItem value="noindex, follow">noindex, follow</SelectItem>
                          <SelectItem value="index, nofollow">index, nofollow</SelectItem>
                          <SelectItem value="noindex, nofollow">noindex, nofollow</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="opengraph" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span className="flex items-center gap-2">
                        <Share2 className="w-5 h-5" />
                        Open Graph Tags
                      </span>
                      <Button variant="outline" size="sm" onClick={autoFillOG}>
                        Auto-fill
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="og-title">OG Title</Label>
                      <Input
                        id="og-title"
                        value={metaTags.ogTitle}
                        onChange={(e) => updateMetaTag('ogTitle', e.target.value)}
                        placeholder="Open Graph title..."
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="og-description">OG Description</Label>
                      <Textarea
                        id="og-description"
                        value={metaTags.ogDescription}
                        onChange={(e) => updateMetaTag('ogDescription', e.target.value)}
                        placeholder="Open Graph description..."
                        className="mt-2"
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="og-image">OG Image URL</Label>
                      <Input
                        id="og-image"
                        value={metaTags.ogImage}
                        onChange={(e) => updateMetaTag('ogImage', e.target.value)}
                        placeholder="https://example.com/image.jpg"
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="og-url">OG URL</Label>
                      <Input
                        id="og-url"
                        value={metaTags.ogUrl}
                        onChange={(e) => updateMetaTag('ogUrl', e.target.value)}
                        placeholder="https://example.com/page"
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="og-type">OG Type</Label>
                      <Select value={metaTags.ogType} onValueChange={(value) => updateMetaTag('ogType', value)}>
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="website">Website</SelectItem>
                          <SelectItem value="article">Article</SelectItem>
                          <SelectItem value="blog">Blog</SelectItem>
                          <SelectItem value="profile">Profile</SelectItem>
                          <SelectItem value="book">Book</SelectItem>
                          <SelectItem value="video">Video</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="twitter" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>Twitter Card Tags</span>
                      <Button variant="outline" size="sm" onClick={autoFillTwitter}>
                        Auto-fill
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <Label htmlFor="twitter-card">Twitter Card Type</Label>
                      <Select value={metaTags.twitterCard} onValueChange={(value) => updateMetaTag('twitterCard', value)}>
                        <SelectTrigger className="mt-2">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="summary">Summary</SelectItem>
                          <SelectItem value="summary_large_image">Summary Large Image</SelectItem>
                          <SelectItem value="app">App</SelectItem>
                          <SelectItem value="player">Player</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="twitter-site">Twitter Site</Label>
                      <Input
                        id="twitter-site"
                        value={metaTags.twitterSite}
                        onChange={(e) => updateMetaTag('twitterSite', e.target.value)}
                        placeholder="@username"
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="twitter-creator">Twitter Creator</Label>
                      <Input
                        id="twitter-creator"
                        value={metaTags.twitterCreator}
                        onChange={(e) => updateMetaTag('twitterCreator', e.target.value)}
                        placeholder="@username"
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="twitter-title">Twitter Title</Label>
                      <Input
                        id="twitter-title"
                        value={metaTags.twitterTitle}
                        onChange={(e) => updateMetaTag('twitterTitle', e.target.value)}
                        placeholder="Twitter card title..."
                        className="mt-2"
                      />
                    </div>

                    <div>
                      <Label htmlFor="twitter-description">Twitter Description</Label>
                      <Textarea
                        id="twitter-description"
                        value={metaTags.twitterDescription}
                        onChange={(e) => updateMetaTag('twitterDescription', e.target.value)}
                        placeholder="Twitter card description..."
                        className="mt-2"
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="twitter-image">Twitter Image URL</Label>
                      <Input
                        id="twitter-image"
                        value={metaTags.twitterImage}
                        onChange={(e) => updateMetaTag('twitterImage', e.target.value)}
                        placeholder="https://example.com/twitter-image.jpg"
                        className="mt-2"
                      />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Generated Meta Tags
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={copyTags}>
                    <Copy className="w-4 h-4 mr-2" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={downloadTags}>
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={generateHTML()}
                readOnly
                placeholder="Generated meta tags will appear here..."
                className="min-h-[500px] font-mono text-sm"
              />
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
