import { useState } from "react";
import { Paintbrush, Copy, Download } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

export default function GradientGenerator() {
  const [direction, setDirection] = useState('to right');
  const [color1, setColor1] = useState('#ff6b6b');
  const [color2, setColor2] = useState('#4ecdc4');
  const [color3, setColor3] = useState('#45b7d1');
  const [useThirdColor, setUseThirdColor] = useState(false);
  const [angle, setAngle] = useState([45]);
  const { toast } = useToast();

  const directions = [
    { value: 'to right', label: 'To Right' },
    { value: 'to left', label: 'To Left' },
    { value: 'to bottom', label: 'To Bottom' },
    { value: 'to top', label: 'To Top' },
    { value: 'to bottom right', label: 'To Bottom Right' },
    { value: 'to bottom left', label: 'To Bottom Left' },
    { value: 'to top right', label: 'To Top Right' },
    { value: 'to top left', label: 'To Top Left' },
    { value: 'custom', label: 'Custom Angle' }
  ];

  const generateGradientCSS = () => {
    const dir = direction === 'custom' ? `${angle[0]}deg` : direction;
    const colors = useThirdColor ? `${color1}, ${color2}, ${color3}` : `${color1}, ${color2}`;
    return `background: linear-gradient(${dir}, ${colors});`;
  };

  const generateGradientStyle = () => {
    const dir = direction === 'custom' ? `${angle[0]}deg` : direction;
    const colors = useThirdColor ? `${color1}, ${color2}, ${color3}` : `${color1}, ${color2}`;
    return `linear-gradient(${dir}, ${colors})`;
  };

  const copyCSS = async () => {
    const css = generateGradientCSS();
    try {
      await copyToClipboard(css);
      toast({
        title: "Success",
        description: "CSS gradient copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy CSS",
        variant: "destructive"
      });
    }
  };

  const downloadCSS = () => {
    const css = `/* Generated CSS Gradient */
.gradient {
  ${generateGradientCSS()}
}

/* Alternative with fallback */
.gradient-fallback {
  background: ${color1}; /* Fallback */
  ${generateGradientCSS()}
}`;
    downloadFile(css, 'gradient.css', 'text/css');
  };

  const presetGradients = [
    { name: 'Sunset', color1: '#ff7e5f', color2: '#feb47b' },
    { name: 'Ocean', color1: '#667eea', color2: '#764ba2' },
    { name: 'Pink Dream', color1: '#f093fb', color2: '#f5576c' },
    { name: 'Green', color1: '#4facfe', color2: '#00f2fe' },
    { name: 'Purple', color1: '#a8edea', color2: '#fed6e3' },
    { name: 'Fire', color1: '#ff9a9e', color2: '#fecfef' }
  ];

  const applyPreset = (preset: { color1: string; color2: string }) => {
    setColor1(preset.color1);
    setColor2(preset.color2);
    setUseThirdColor(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Paintbrush className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Gradient Generator</h1>
          <p className="text-xl text-gray-600">Create CSS gradients with visual editor</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Gradient Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div 
                className="w-full h-64 rounded-lg border border-gray-300 mb-4"
                style={{ background: generateGradientStyle() }}
              />
              
              <div className="space-y-4">
                <div>
                  <Label>CSS Code</Label>
                  <div className="mt-2 relative">
                    <Input
                      value={generateGradientCSS()}
                      readOnly
                      className="font-mono text-sm pr-20"
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={copyCSS}
                      className="absolute right-1 top-1"
                    >
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button onClick={copyCSS} variant="outline" className="flex-1">
                    <Copy className="w-4 h-4 mr-2" />
                    Copy CSS
                  </Button>
                  <Button onClick={downloadCSS} variant="outline" className="flex-1">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Gradient Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="direction">Direction</Label>
                  <Select value={direction} onValueChange={setDirection}>
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select direction" />
                    </SelectTrigger>
                    <SelectContent>
                      {directions.map((dir) => (
                        <SelectItem key={dir.value} value={dir.value}>
                          {dir.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {direction === 'custom' && (
                  <div>
                    <Label>Angle: {angle[0]}°</Label>
                    <Slider
                      value={angle}
                      onValueChange={setAngle}
                      max={360}
                      min={0}
                      step={1}
                      className="mt-2"
                    />
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="color1">Color 1</Label>
                    <div className="flex gap-2 mt-2">
                      <input
                        id="color1"
                        type="color"
                        value={color1}
                        onChange={(e) => setColor1(e.target.value)}
                        className="w-12 h-10 border border-gray-300 rounded cursor-pointer"
                      />
                      <Input
                        value={color1}
                        onChange={(e) => setColor1(e.target.value)}
                        className="font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="color2">Color 2</Label>
                    <div className="flex gap-2 mt-2">
                      <input
                        id="color2"
                        type="color"
                        value={color2}
                        onChange={(e) => setColor2(e.target.value)}
                        className="w-12 h-10 border border-gray-300 rounded cursor-pointer"
                      />
                      <Input
                        value={color2}
                        onChange={(e) => setColor2(e.target.value)}
                        className="font-mono"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="use-third-color"
                    checked={useThirdColor}
                    onChange={(e) => setUseThirdColor(e.target.checked)}
                    className="rounded"
                  />
                  <Label htmlFor="use-third-color">Add third color</Label>
                </div>

                {useThirdColor && (
                  <div>
                    <Label htmlFor="color3">Color 3</Label>
                    <div className="flex gap-2 mt-2">
                      <input
                        id="color3"
                        type="color"
                        value={color3}
                        onChange={(e) => setColor3(e.target.value)}
                        className="w-12 h-10 border border-gray-300 rounded cursor-pointer"
                      />
                      <Input
                        value={color3}
                        onChange={(e) => setColor3(e.target.value)}
                        className="font-mono"
                      />
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Preset Gradients</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-3">
                  {presetGradients.map((preset, index) => (
                    <button
                      key={index}
                      onClick={() => applyPreset(preset)}
                      className="h-16 rounded-lg border-2 border-gray-300 hover:border-primary transition-colors relative overflow-hidden"
                      style={{ background: `linear-gradient(to right, ${preset.color1}, ${preset.color2})` }}
                    >
                      <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-10 transition-all flex items-end p-2">
                        <span className="text-white text-sm font-medium bg-black bg-opacity-50 px-2 py-1 rounded">
                          {preset.name}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
