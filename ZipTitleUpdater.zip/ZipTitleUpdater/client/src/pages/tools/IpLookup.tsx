import { useState } from "react";
import { Globe, Search, MapPin, Shield, Clock } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface IpInfo {
  ip: string;
  city: string;
  region: string;
  country: string;
  loc: string;
  org: string;
  timezone: string;
  hostname?: string;
}

export default function IpLookup() {
  const [ipAddress, setIpAddress] = useState('');
  const [ipInfo, setIpInfo] = useState<IpInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const isValidIP = (ip: string) => {
    const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    const ipv6Regex = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
    return ipv4Regex.test(ip) || ipv6Regex.test(ip);
  };

  const lookupIP = async () => {
    if (!ipAddress.trim()) {
      toast({
        title: "Error",
        description: "Please enter an IP address",
        variant: "destructive"
      });
      return;
    }

    if (!isValidIP(ipAddress.trim())) {
      toast({
        title: "Error",
        description: "Please enter a valid IP address",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // Using ipinfo.io API for IP geolocation
      const response = await fetch(`https://ipinfo.io/${ipAddress.trim()}/json`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch IP information');
      }
      
      const data = await response.json();
      
      if (data.error) {
        throw new Error(data.error.message || 'Invalid IP address');
      }
      
      setIpInfo(data);
      toast({
        title: "Success",
        description: "IP information retrieved successfully"
      });
    } catch (err) {
      setError((err as Error).message);
      setIpInfo(null);
      toast({
        title: "Error",
        description: "Failed to lookup IP address",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const lookupMyIP = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await fetch('https://ipinfo.io/json');
      
      if (!response.ok) {
        throw new Error('Failed to fetch your IP information');
      }
      
      const data = await response.json();
      setIpAddress(data.ip);
      setIpInfo(data);
      toast({
        title: "Success",
        description: "Your IP information retrieved successfully"
      });
    } catch (err) {
      setError((err as Error).message);
      toast({
        title: "Error",
        description: "Failed to lookup your IP address",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Globe className="mx-auto w-16 h-16 text-cyan-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">IP Lookup</h1>
          <p className="text-xl text-gray-600">Get detailed information about IP addresses</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>IP Address Lookup</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="ip-input">IP Address</Label>
              <Input
                id="ip-input"
                value={ipAddress}
                onChange={(e) => setIpAddress(e.target.value)}
                placeholder="Enter IP address (e.g., 8.8.8.8)"
                className="mt-2"
                onKeyPress={(e) => e.key === 'Enter' && lookupIP()}
              />
            </div>

            <div className="flex gap-2">
              <Button 
                onClick={lookupIP} 
                disabled={loading}
                className="flex-1"
              >
                {loading ? (
                  <>Looking up...</>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    Lookup IP
                  </>
                )}
              </Button>
              <Button 
                variant="outline" 
                onClick={lookupMyIP}
                disabled={loading}
              >
                My IP
              </Button>
            </div>

            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {ipInfo && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  Location Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <Label className="text-gray-600">IP Address</Label>
                    <p className="font-mono font-medium">{ipInfo.ip}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Country</Label>
                    <p className="font-medium">{ipInfo.country || 'Unknown'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Region</Label>
                    <p className="font-medium">{ipInfo.region || 'Unknown'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">City</Label>
                    <p className="font-medium">{ipInfo.city || 'Unknown'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Coordinates</Label>
                    <p className="font-mono text-sm">{ipInfo.loc || 'Unknown'}</p>
                  </div>
                  <div>
                    <Label className="text-gray-600">Timezone</Label>
                    <p className="font-medium">{ipInfo.timezone || 'Unknown'}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Network Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-sm">
                  <div>
                    <Label className="text-gray-600">Organization</Label>
                    <p className="font-medium">{ipInfo.org || 'Unknown'}</p>
                  </div>
                  {ipInfo.hostname && (
                    <div>
                      <Label className="text-gray-600">Hostname</Label>
                      <p className="font-mono text-sm break-all">{ipInfo.hostname}</p>
                    </div>
                  )}
                  <div>
                    <Label className="text-gray-600">Lookup Time</Label>
                    <p className="font-medium flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {new Date().toLocaleString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {ipInfo.loc && (
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Map Location</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                    <div className="text-center text-gray-600">
                      <MapPin className="w-12 h-12 mx-auto mb-2" />
                      <p>Map integration would be implemented here</p>
                      <p className="text-sm">Coordinates: {ipInfo.loc}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
