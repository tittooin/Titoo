import { useState } from "react";
import { Link, Copy, ExternalLink } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, isValidUrl } from "@/lib/utils";

export default function UrlShortener() {
  const [originalUrl, setOriginalUrl] = useState('');
  const [shortUrl, setShortUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const shortenUrl = async () => {
    if (!originalUrl.trim()) {
      toast({
        title: "Error",
        description: "Please enter a URL to shorten",
        variant: "destructive"
      });
      return;
    }

    if (!isValidUrl(originalUrl)) {
      toast({
        title: "Error",
        description: "Please enter a valid URL",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    
    // Simulate URL shortening with a demo short URL
    setTimeout(() => {
      const randomId = Math.random().toString(36).substring(2, 8);
      const shortened = `https://short.ly/${randomId}`;
      setShortUrl(shortened);
      setLoading(false);
      
      toast({
        title: "Success",
        description: "URL shortened successfully"
      });
    }, 1000);
  };

  const copyShortUrl = async () => {
    if (!shortUrl) return;
    
    try {
      await copyToClipboard(shortUrl);
      toast({
        title: "Success",
        description: "Shortened URL copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy URL",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Link className="mx-auto w-16 h-16 text-indigo-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">URL Shortener</h1>
          <p className="text-xl text-gray-600">Shorten long URLs for easy sharing</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Shorten URL</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="original-url">Original URL</Label>
              <Input
                id="original-url"
                value={originalUrl}
                onChange={(e) => setOriginalUrl(e.target.value)}
                placeholder="https://example.com/very/long/url/path"
                className="mt-2"
              />
            </div>

            <Button 
              onClick={shortenUrl} 
              disabled={!originalUrl.trim() || loading}
              className="w-full"
            >
              {loading ? 'Shortening...' : 'Shorten URL'}
            </Button>

            {shortUrl && (
              <div className="space-y-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div>
                  <Label>Shortened URL</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      value={shortUrl}
                      readOnly
                      className="font-mono"
                    />
                    <Button variant="outline" onClick={copyShortUrl}>
                      <Copy className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" asChild>
                      <a href={shortUrl} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    </Button>
                  </div>
                </div>
                
                <div className="text-sm text-green-700">
                  <p><strong>Original:</strong> {originalUrl}</p>
                  <p><strong>Shortened:</strong> {shortUrl}</p>
                  <p><strong>Saved characters:</strong> {originalUrl.length - shortUrl.length}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
