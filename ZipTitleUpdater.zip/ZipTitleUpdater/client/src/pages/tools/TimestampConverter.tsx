import { useState } from "react";
import { Clock, Copy } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard } from "@/lib/utils";

export default function TimestampConverter() {
  const [timestamp, setTimestamp] = useState('');
  const [humanDate, setHumanDate] = useState('');
  const [currentTimestamp] = useState(Math.floor(Date.now() / 1000));
  const { toast } = useToast();

  const convertTimestampToDate = (ts: string) => {
    const num = parseInt(ts);
    if (isNaN(num)) return '';
    
    // Handle both seconds and milliseconds
    const date = new Date(num < 10000000000 ? num * 1000 : num);
    return date.toISOString().slice(0, 16);
  };

  const convertDateToTimestamp = (dateStr: string) => {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    return Math.floor(date.getTime() / 1000).toString();
  };

  const handleTimestampChange = (value: string) => {
    setTimestamp(value);
    setHumanDate(convertTimestampToDate(value));
  };

  const handleDateChange = (value: string) => {
    setHumanDate(value);
    setTimestamp(convertDateToTimestamp(value));
  };

  const copyCurrentTimestamp = async () => {
    try {
      await copyToClipboard(currentTimestamp.toString());
      toast({
        title: "Success",
        description: "Current timestamp copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy timestamp",
        variant: "destructive"
      });
    }
  };

  const copyTimestamp = async () => {
    if (!timestamp) return;
    
    try {
      await copyToClipboard(timestamp);
      toast({
        title: "Success",
        description: "Timestamp copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy timestamp",
        variant: "destructive"
      });
    }
  };

  const formatReadableDate = (ts: string) => {
    if (!ts) return '';
    const num = parseInt(ts);
    if (isNaN(num)) return '';
    
    const date = new Date(num < 10000000000 ? num * 1000 : num);
    return date.toLocaleString();
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Clock className="mx-auto w-16 h-16 text-blue-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Timestamp Converter</h1>
          <p className="text-xl text-gray-600">Convert between timestamp and readable date</p>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Current Timestamp
                <Button variant="outline" size="sm" onClick={copyCurrentTimestamp}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <p className="text-2xl font-mono font-bold text-primary">{currentTimestamp}</p>
                <p className="text-gray-600">{new Date().toLocaleString()}</p>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Timestamp to Date</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="timestamp-input">Unix Timestamp</Label>
                  <div className="flex gap-2 mt-2">
                    <Input
                      id="timestamp-input"
                      value={timestamp}
                      onChange={(e) => handleTimestampChange(e.target.value)}
                      placeholder="1640995200"
                      className="font-mono"
                    />
                    <Button variant="outline" onClick={copyTimestamp} disabled={!timestamp}>
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                {timestamp && (
                  <div className="space-y-2">
                    <Label>Readable Date</Label>
                    <div className="p-3 bg-gray-50 border rounded-lg">
                      <p className="font-medium">{formatReadableDate(timestamp)}</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Date to Timestamp</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="date-input">Date & Time</Label>
                  <Input
                    id="date-input"
                    type="datetime-local"
                    value={humanDate}
                    onChange={(e) => handleDateChange(e.target.value)}
                    className="mt-2"
                  />
                </div>

                {humanDate && (
                  <div className="space-y-2">
                    <Label>Unix Timestamp</Label>
                    <div className="p-3 bg-gray-50 border rounded-lg">
                      <p className="font-mono font-medium">{timestamp}</p>
                    </div>
                  </div>
                )}

                <div className="text-sm text-gray-600 space-y-1">
                  <p><strong>Quick actions:</strong></p>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDateChange(new Date().toISOString().slice(0, 16))}
                    >
                      Now
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDateChange(new Date(Date.now() + 24*60*60*1000).toISOString().slice(0, 16))}
                    >
                      Tomorrow
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDateChange(new Date(Date.now() + 7*24*60*60*1000).toISOString().slice(0, 16))}
                    >
                      Next Week
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
