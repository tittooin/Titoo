import { useState } from "react";
import { Edit, Save, Copy, Download, Bold, Italic, Underline } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { copyToClipboard, downloadFile } from "@/lib/utils";

export default function TextEditor() {
  const [content, setContent] = useState('');
  const [wordCount, setWordCount] = useState(0);
  const [charCount, setCharCount] = useState(0);
  const { toast } = useToast();

  const handleContentChange = (value: string) => {
    setContent(value);
    setCharCount(value.length);
    setWordCount(value.trim() ? value.trim().split(/\s+/).length : 0);
  };

  const formatText = (type: 'bold' | 'italic' | 'underline') => {
    const textarea = document.getElementById('editor') as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = content.substring(start, end);

    if (!selectedText) {
      toast({
        title: "No text selected",
        description: "Please select text to format",
        variant: "destructive"
      });
      return;
    }

    let formattedText = '';
    switch (type) {
      case 'bold':
        formattedText = `**${selectedText}**`;
        break;
      case 'italic':
        formattedText = `*${selectedText}*`;
        break;
      case 'underline':
        formattedText = `<u>${selectedText}</u>`;
        break;
    }

    const newContent = content.substring(0, start) + formattedText + content.substring(end);
    handleContentChange(newContent);
  };

  const copyContent = async () => {
    if (!content) return;
    
    try {
      await copyToClipboard(content);
      toast({
        title: "Success",
        description: "Content copied to clipboard"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to copy content",
        variant: "destructive"
      });
    }
  };

  const saveContent = () => {
    if (!content) return;
    downloadFile(content, 'document.txt');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Edit className="mx-auto w-16 h-16 text-blue-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Text Editor</h1>
          <p className="text-xl text-gray-600">Rich text editor with formatting options</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Text Editor
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => formatText('bold')}>
                  <Bold className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => formatText('italic')}>
                  <Italic className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="sm" onClick={() => formatText('underline')}>
                  <Underline className="w-4 h-4" />
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Textarea
              id="editor"
              value={content}
              onChange={(e) => handleContentChange(e.target.value)}
              placeholder="Start typing your document here..."
              className="min-h-[400px] text-base leading-relaxed"
            />

            <div className="flex items-center justify-between">
              <div className="text-sm text-gray-600">
                Words: {wordCount} | Characters: {charCount}
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" onClick={copyContent} disabled={!content}>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy
                </Button>
                <Button onClick={saveContent} disabled={!content}>
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Footer />
    </div>
  );
}
