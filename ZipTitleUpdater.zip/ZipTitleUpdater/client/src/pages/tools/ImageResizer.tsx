import { useState, useRef } from "react";
import { Scaling, Upload, Download, RotateCw, Crop } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { formatBytes } from "@/lib/utils";

interface ImageDimensions {
  width: number;
  height: number;
}

export default function ImageResizer() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [resizedImage, setResizedImage] = useState<string | null>(null);
  const [originalDimensions, setOriginalDimensions] = useState<ImageDimensions | null>(null);
  const [targetDimensions, setTargetDimensions] = useState<ImageDimensions>({ width: 0, height: 0 });
  const [maintainAspectRatio, setMaintainAspectRatio] = useState(true);
  const [quality, setQuality] = useState(90);
  const [format, setFormat] = useState('jpeg');
  const [processing, setProcessing] = useState(false);
  const [originalSize, setOriginalSize] = useState(0);
  const [resizedSize, setResizedSize] = useState(0);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Error",
        description: "Please select a valid image file",
        variant: "destructive"
      });
      return;
    }

    setOriginalSize(file.size);
    
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setOriginalImage(imageUrl);
      
      // Get image dimensions
      const img = new Image();
      img.onload = () => {
        const dimensions = { width: img.width, height: img.height };
        setOriginalDimensions(dimensions);
        setTargetDimensions(dimensions);
      };
      img.src = imageUrl;
    };
    reader.readAsDataURL(file);
  };

  const updateDimensions = (field: 'width' | 'height', value: number) => {
    if (!originalDimensions) return;

    if (maintainAspectRatio) {
      const aspectRatio = originalDimensions.width / originalDimensions.height;
      if (field === 'width') {
        setTargetDimensions({
          width: value,
          height: Math.round(value / aspectRatio)
        });
      } else {
        setTargetDimensions({
          width: Math.round(value * aspectRatio),
          height: value
        });
      }
    } else {
      setTargetDimensions(prev => ({ ...prev, [field]: value }));
    }
  };

  const resizeImage = () => {
    if (!originalImage || !canvasRef.current || !originalDimensions) return;

    setProcessing(true);
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = targetDimensions.width;
      canvas.height = targetDimensions.height;
      
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw resized image
      ctx.drawImage(img, 0, 0, targetDimensions.width, targetDimensions.height);
      
      // Convert to desired format
      const mimeType = format === 'png' ? 'image/png' : 'image/jpeg';
      const qualityValue = format === 'png' ? 1 : quality / 100;
      
      const resizedDataUrl = canvas.toDataURL(mimeType, qualityValue);
      setResizedImage(resizedDataUrl);
      
      // Calculate file size (rough estimation)
      const resizedSizeEstimate = Math.round((resizedDataUrl.length * 3) / 4);
      setResizedSize(resizedSizeEstimate);
      
      setProcessing(false);
      
      toast({
        title: "Success",
        description: "Image resized successfully"
      });
    };
    
    img.src = originalImage;
  };

  const downloadResizedImage = () => {
    if (!resizedImage) return;
    
    const link = document.createElement('a');
    link.href = resizedImage;
    link.download = `resized-${targetDimensions.width}x${targetDimensions.height}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const presetSizes = [
    { name: 'Instagram Square', width: 1080, height: 1080 },
    { name: 'Instagram Portrait', width: 1080, height: 1350 },
    { name: 'Facebook Cover', width: 820, height: 312 },
    { name: 'Twitter Header', width: 1500, height: 500 },
    { name: 'YouTube Thumbnail', width: 1280, height: 720 },
    { name: 'Profile Picture', width: 400, height: 400 },
    { name: 'HD (720p)', width: 1280, height: 720 },
    { name: 'Full HD (1080p)', width: 1920, height: 1080 }
  ];

  const applyPresetSize = (preset: { width: number; height: number }) => {
    setTargetDimensions(preset);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Scaling className="mx-auto w-16 h-16 text-pink-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Image Resizer</h1>
          <p className="text-xl text-gray-600">Scaling images to custom dimensions</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Upload Image</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                    <div className="space-y-2">
                      <p className="text-lg font-medium text-gray-900">Drop your image here or click to browse</p>
                      <p className="text-gray-500">Supports: JPG, PNG, GIF, WEBP</p>
                      <input
                        ref={fileInputRef}
                        type="file"
                        onChange={handleFileUpload}
                        accept="image/*"
                        className="hidden"
                        id="image-upload"
                      />
                      <label htmlFor="image-upload">
                        <Button variant="outline" className="cursor-pointer">
                          Choose Image
                        </Button>
                      </label>
                    </div>
                  </div>

                  {originalImage && (
                    <div className="space-y-2">
                      <Label>Original Image Preview</Label>
                      <img
                        src={originalImage}
                        alt="Original"
                        className="w-full h-48 object-contain border border-gray-300 rounded-lg bg-white"
                      />
                      {originalDimensions && (
                        <p className="text-sm text-gray-600">
                          Original: {originalDimensions.width} × {originalDimensions.height} pixels
                          ({formatBytes(originalSize)})
                        </p>
                      )}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Scaling Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="width">Width (px)</Label>
                    <Input
                      id="width"
                      type="number"
                      value={targetDimensions.width}
                      onChange={(e) => updateDimensions('width', parseInt(e.target.value) || 0)}
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label htmlFor="height">Height (px)</Label>
                    <Input
                      id="height"
                      type="number"
                      value={targetDimensions.height}
                      onChange={(e) => updateDimensions('height', parseInt(e.target.value) || 0)}
                      className="mt-2"
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="aspect-ratio"
                    checked={maintainAspectRatio}
                    onCheckedChange={(checked) => setMaintainAspectRatio(checked as boolean)}
                  />
                  <Label htmlFor="aspect-ratio">Maintain aspect ratio</Label>
                </div>

                <div>
                  <Label htmlFor="format">Output Format</Label>
                  <Select value={format} onValueChange={setFormat}>
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="jpeg">JPEG</SelectItem>
                      <SelectItem value="png">PNG</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {format === 'jpeg' && (
                  <div>
                    <Label htmlFor="quality">Quality: {quality}%</Label>
                    <input
                      id="quality"
                      type="range"
                      min="10"
                      max="100"
                      value={quality}
                      onChange={(e) => setQuality(parseInt(e.target.value))}
                      className="w-full mt-2"
                    />
                  </div>
                )}

                <Button
                  onClick={resizeImage}
                  disabled={!originalImage || processing}
                  className="w-full"
                >
                  {processing ? (
                    <>Processing...</>
                  ) : (
                    <>
                      <Crop className="w-4 h-4 mr-2" />
                      Scaling Image
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Preset Sizes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {presetSizes.map((preset, index) => (
                    <Button
                      key={index}
                      variant="outline"
                      onClick={() => applyPresetSize(preset)}
                      className="text-left justify-start h-auto p-3"
                    >
                      <div>
                        <div className="font-medium">{preset.name}</div>
                        <div className="text-xs text-gray-600">
                          {preset.width} × {preset.height}
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Resized Image
                <Button
                  variant="outline"
                  size="sm"
                  onClick={downloadResizedImage}
                  disabled={!resizedImage}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {resizedImage ? (
                <div className="space-y-4">
                  <img
                    src={resizedImage}
                    alt="Resized"
                    className="w-full h-auto border border-gray-300 rounded-lg bg-white"
                  />
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>Resized: {targetDimensions.width} × {targetDimensions.height} pixels</p>
                    <p>File size: ~{formatBytes(resizedSize)}</p>
                    {originalSize > 0 && (
                      <p>
                        Size reduction: {((originalSize - resizedSize) / originalSize * 100).toFixed(1)}%
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-64 border-2 border-dashed border-gray-300 rounded-lg">
                  <div className="text-center">
                    <Scaling className="mx-auto w-12 h-12 text-gray-400 mb-4" />
                    <p className="text-gray-500">Resized image will appear here</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <canvas ref={canvasRef} className="hidden" />

        <Alert className="mt-8">
          <AlertDescription>
            <strong>Tip:</strong> For best quality, avoid upscaling images beyond their original dimensions. 
            Use high-quality source images and adjust the quality setting for the optimal balance between 
            file size and image quality.
          </AlertDescription>
        </Alert>
      </div>

      <Footer />
    </div>
  );
}
