import { useState } from "react";
import { CheckCircle, XCircle, Search, Globe } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

interface DomainStatus {
  domain: string;
  available: boolean;
  price?: string;
  registrar?: string;
}

export default function DomainChecker() {
  const [domain, setDomain] = useState('');
  const [results, setResults] = useState<DomainStatus[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const extensions = ['.com', '.net', '.org', '.info', '.biz', '.co', '.io', '.me', '.app', '.dev'];

  const isValidDomainName = (domain: string) => {
    const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
    return domainRegex.test(domain) && domain.length >= 2;
  };

  const checkDomains = async () => {
    if (!domain.trim()) {
      toast({
        title: "Error",
        description: "Please enter a domain name",
        variant: "destructive"
      });
      return;
    }

    const cleanDomain = domain.trim().toLowerCase().replace(/\.[a-z]+$/, '');

    if (!isValidDomainName(cleanDomain)) {
      toast({
        title: "Error",
        description: "Please enter a valid domain name",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError('');
    setResults([]);
    
    try {
      // Simulate domain availability check
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock domain availability results
      const mockResults: DomainStatus[] = extensions.map(ext => ({
        domain: cleanDomain + ext,
        available: Math.random() > 0.5, // Random availability for demo
        price: Math.random() > 0.5 ? `$${(Math.random() * 20 + 10).toFixed(2)}/year` : undefined,
        registrar: Math.random() > 0.5 ? 'Example Registrar' : undefined
      }));
      
      setResults(mockResults);
      
      const availableCount = mockResults.filter(r => r.available).length;
      toast({
        title: "Success",
        description: `Found ${availableCount} available domains`
      });
    } catch (err) {
      setError("Failed to check domain availability. This feature requires a domain availability API.");
      toast({
        title: "Error",
        description: "Failed to check domain availability",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const checkSingleDomain = async (fullDomain: string) => {
    // In production, this would check a single domain
    console.log(`Checking ${fullDomain}`);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <CheckCircle className="mx-auto w-16 h-16 text-emerald-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Domain Checker</h1>
          <p className="text-xl text-gray-600">Check domain availability and status</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Check Domain Availability</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="domain-input">Domain Name (without extension)</Label>
              <Input
                id="domain-input"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                placeholder="Enter domain name (e.g., myawesomesite)"
                className="mt-2"
                onKeyPress={(e) => e.key === 'Enter' && checkDomains()}
              />
            </div>

            <Button 
              onClick={checkDomains} 
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>Checking availability...</>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Check Availability
                </>
              )}
            </Button>

            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <AlertDescription>
                <strong>Note:</strong> This is a demo interface. In production, this would integrate 
                with domain registrar APIs to check real-time availability and pricing.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {results.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Domain Availability Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {results.map((result, index) => (
                  <div 
                    key={index}
                    className={`flex items-center justify-between p-4 border rounded-lg ${
                      result.available 
                        ? 'border-green-200 bg-green-50' 
                        : 'border-red-200 bg-red-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      {result.available ? (
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      ) : (
                        <XCircle className="w-5 h-5 text-red-600" />
                      )}
                      <div>
                        <p className="font-medium">{result.domain}</p>
                        <p className={`text-sm ${
                          result.available ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {result.available ? 'Available' : 'Taken'}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      {result.available && result.price && (
                        <p className="font-medium text-green-700">{result.price}</p>
                      )}
                      {!result.available && result.registrar && (
                        <p className="text-sm text-gray-600">via {result.registrar}</p>
                      )}
                      {result.available && (
                        <Button 
                          size="sm" 
                          className="mt-2"
                          onClick={() => alert('Registration would redirect to registrar')}
                        >
                          Register
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-4 border-t">
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <div className="flex items-center gap-4">
                    <span className="flex items-center gap-1">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      {results.filter(r => r.available).length} Available
                    </span>
                    <span className="flex items-center gap-1">
                      <XCircle className="w-4 h-4 text-red-600" />
                      {results.filter(r => !r.available).length} Taken
                    </span>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => window.open('https://whois.net', '_blank')}
                  >
                    <Globe className="w-4 h-4 mr-1" />
                    WHOIS Lookup
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      <Footer />
    </div>
  );
}
