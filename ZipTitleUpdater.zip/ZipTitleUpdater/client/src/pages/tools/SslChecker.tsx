import { useState } from "react";
import { Shield, Search, AlertTriangle, CheckCircle, Calendar, Lock } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

interface SSLInfo {
  domain: string;
  issuer: string;
  validFrom: string;
  validTo: string;
  daysUntilExpiry: number;
  algorithm: string;
  keySize: number;
  serialNumber: string;
  isValid: boolean;
  isExpired: boolean;
  isSelfSigned: boolean;
  san: string[];
}

export default function SslChecker() {
  const [domain, setDomain] = useState('');
  const [sslInfo, setSslInfo] = useState<SSLInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { toast } = useToast();

  const isValidDomain = (domain: string) => {
    const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
    return domainRegex.test(domain);
  };

  const checkSSL = async () => {
    if (!domain.trim()) {
      toast({
        title: "Error",
        description: "Please enter a domain name",
        variant: "destructive"
      });
      return;
    }

    const cleanDomain = domain.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').split('/')[0];

    if (!isValidDomain(cleanDomain)) {
      toast({
        title: "Error",
        description: "Please enter a valid domain name",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      // Simulate SSL certificate check
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock SSL certificate data
      const validFrom = new Date('2023-01-15');
      const validTo = new Date('2024-01-15');
      const now = new Date();
      const daysUntilExpiry = Math.ceil((validTo.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
      
      const mockSSLData: SSLInfo = {
        domain: cleanDomain,
        issuer: "Let's Encrypt Authority X3",
        validFrom: validFrom.toISOString(),
        validTo: validTo.toISOString(),
        daysUntilExpiry,
        algorithm: "RSA-SHA256",
        keySize: 2048,
        serialNumber: "03:A1:B2:C3:D4:E5:F6:07:08:09:0A:0B:0C:0D:0E:0F",
        isValid: daysUntilExpiry > 0,
        isExpired: daysUntilExpiry <= 0,
        isSelfSigned: false,
        san: [
          cleanDomain,
          `www.${cleanDomain}`,
          `mail.${cleanDomain}`
        ]
      };
      
      setSslInfo(mockSSLData);
      toast({
        title: "Success",
        description: "SSL certificate information retrieved successfully"
      });
    } catch (err) {
      setError("Failed to check SSL certificate. This feature requires SSL checking APIs.");
      setSslInfo(null);
      toast({
        title: "Error",
        description: "Failed to check SSL certificate",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getExpiryStatus = (days: number) => {
    if (days <= 0) return { color: 'destructive', text: 'Expired' };
    if (days <= 7) return { color: 'destructive', text: 'Expires Soon' };
    if (days <= 30) return { color: 'warning', text: 'Expires Soon' };
    return { color: 'success', text: 'Valid' };
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="text-center mb-8">
          <Shield className="mx-auto w-16 h-16 text-green-600 mb-4" />
          <h1 className="text-3xl font-bold text-gray-900 mb-2">SSL Checker</h1>
          <p className="text-xl text-gray-600">Check SSL certificate status and details</p>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle>SSL Certificate Checker</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="domain-input">Domain Name</Label>
              <Input
                id="domain-input"
                value={domain}
                onChange={(e) => setDomain(e.target.value)}
                placeholder="Enter domain name (e.g., example.com)"
                className="mt-2"
                onKeyPress={(e) => e.key === 'Enter' && checkSSL()}
              />
            </div>

            <Button 
              onClick={checkSSL} 
              disabled={loading}
              className="w-full"
            >
              {loading ? (
                <>Checking SSL...</>
              ) : (
                <>
                  <Search className="w-4 h-4 mr-2" />
                  Check SSL Certificate
                </>
              )}
            </Button>

            {error && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {error}
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <AlertDescription>
                <strong>Note:</strong> This is a demo interface. In production, this would integrate 
                with SSL checking APIs to retrieve real certificate information.
              </AlertDescription>
            </Alert>
          </CardContent>
        </Card>

        {sslInfo && (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Lock className="w-5 h-5" />
                    SSL Certificate Status
                  </span>
                  <Badge 
                    variant={sslInfo.isValid ? "default" : "destructive"}
                    className={sslInfo.isValid ? "bg-green-600" : "bg-red-600"}
                  >
                    {sslInfo.isValid ? (
                      <CheckCircle className="w-4 h-4 mr-1" />
                    ) : (
                      <AlertTriangle className="w-4 h-4 mr-1" />
                    )}
                    {getExpiryStatus(sslInfo.daysUntilExpiry).text}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label className="text-gray-600">Domain</Label>
                      <p className="font-mono font-medium">{sslInfo.domain}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Issuer</Label>
                      <p className="font-medium">{sslInfo.issuer}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Algorithm</Label>
                      <p className="font-medium">{sslInfo.algorithm}</p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Key Size</Label>
                      <p className="font-medium">{sslInfo.keySize} bits</p>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-gray-600">Valid From</Label>
                      <p className="font-medium flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDate(sslInfo.validFrom)}
                      </p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Valid Until</Label>
                      <p className="font-medium flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {formatDate(sslInfo.validTo)}
                      </p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Days Until Expiry</Label>
                      <p className={`font-medium ${
                        sslInfo.daysUntilExpiry <= 0 ? 'text-red-600' :
                        sslInfo.daysUntilExpiry <= 30 ? 'text-yellow-600' : 'text-green-600'
                      }`}>
                        {sslInfo.daysUntilExpiry} days
                      </p>
                    </div>
                    <div>
                      <Label className="text-gray-600">Serial Number</Label>
                      <p className="font-mono text-sm break-all">{sslInfo.serialNumber}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Subject Alternative Names (SAN)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sslInfo.san.map((name, index) => (
                    <div 
                      key={index}
                      className="p-2 bg-gray-50 border rounded text-sm font-mono"
                    >
                      {name}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Security Assessment</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <span>Certificate Valid</span>
                    {sslInfo.isValid ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-600" />
                    )}
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <span>Self-Signed</span>
                    {sslInfo.isSelfSigned ? (
                      <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    ) : (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    )}
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <span>Key Size (2048+ recommended)</span>
                    {sslInfo.keySize >= 2048 ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-yellow-600" />
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
