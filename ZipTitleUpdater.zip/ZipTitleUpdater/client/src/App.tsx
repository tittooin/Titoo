import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";

// Tool imports
import PdfConverter from "@/pages/tools/PdfConverter";
import YoutubeDownloader from "@/pages/tools/YoutubeDownloader";
import ImageCompressor from "@/pages/tools/ImageCompressor";
import TextEditor from "@/pages/tools/TextEditor";
import QrGenerator from "@/pages/tools/QrGenerator";
import PasswordGenerator from "@/pages/tools/PasswordGenerator";
import UrlShortener from "@/pages/tools/UrlShortener";
import ColorPicker from "@/pages/tools/ColorPicker";
import Base64Encoder from "@/pages/tools/Base64Encoder";
import JsonFormatter from "@/pages/tools/JsonFormatter";
import HtmlMinifier from "@/pages/tools/HtmlMinifier";
import CssMinifier from "@/pages/tools/CssMinifier";
import JsMinifier from "@/pages/tools/JsMinifier";
import MarkdownEditor from "@/pages/tools/MarkdownEditor";
import HashGenerator from "@/pages/tools/HashGenerator";
import UnitConverter from "@/pages/tools/UnitConverter";
import TimestampConverter from "@/pages/tools/TimestampConverter";
import RegexTester from "@/pages/tools/RegexTester";
import LoremGenerator from "@/pages/tools/LoremGenerator";
import GradientGenerator from "@/pages/tools/GradientGenerator";
import IpLookup from "@/pages/tools/IpLookup";
import WhoisLookup from "@/pages/tools/WhoisLookup";
import DomainChecker from "@/pages/tools/DomainChecker";
import SslChecker from "@/pages/tools/SslChecker";
import PageSpeedTest from "@/pages/tools/PageSpeedTest";
import SeoAnalyzer from "@/pages/tools/SeoAnalyzer";
import MetaTagGenerator from "@/pages/tools/MetaTagGenerator";
import SitemapGenerator from "@/pages/tools/SitemapGenerator";
import RobotsTxtGenerator from "@/pages/tools/RobotsTxtGenerator";
import HtaccessGenerator from "@/pages/tools/HtaccessGenerator";
import CsvToJson from "@/pages/tools/CsvToJson";
import XmlFormatter from "@/pages/tools/XmlFormatter";
import SqlFormatter from "@/pages/tools/SqlFormatter";
import ImageResizer from "@/pages/tools/ImageResizer";
import FaviconGenerator from "@/pages/tools/FaviconGenerator";
import EmailValidator from "@/pages/tools/EmailValidator";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      
      {/* Tool routes */}
      <Route path="/tools/pdf-converter" component={PdfConverter} />
      <Route path="/tools/youtube-downloader" component={YoutubeDownloader} />
      <Route path="/tools/image-compressor" component={ImageCompressor} />
      <Route path="/tools/text-editor" component={TextEditor} />
      <Route path="/tools/qr-generator" component={QrGenerator} />
      <Route path="/tools/password-generator" component={PasswordGenerator} />
      <Route path="/tools/url-shortener" component={UrlShortener} />
      <Route path="/tools/color-picker" component={ColorPicker} />
      <Route path="/tools/base64-encoder" component={Base64Encoder} />
      <Route path="/tools/json-formatter" component={JsonFormatter} />
      <Route path="/tools/html-minifier" component={HtmlMinifier} />
      <Route path="/tools/css-minifier" component={CssMinifier} />
      <Route path="/tools/js-minifier" component={JsMinifier} />
      <Route path="/tools/markdown-editor" component={MarkdownEditor} />
      <Route path="/tools/hash-generator" component={HashGenerator} />
      <Route path="/tools/unit-converter" component={UnitConverter} />
      <Route path="/tools/timestamp-converter" component={TimestampConverter} />
      <Route path="/tools/regex-tester" component={RegexTester} />
      <Route path="/tools/lorem-generator" component={LoremGenerator} />
      <Route path="/tools/gradient-generator" component={GradientGenerator} />
      <Route path="/tools/ip-lookup" component={IpLookup} />
      <Route path="/tools/whois-lookup" component={WhoisLookup} />
      <Route path="/tools/domain-checker" component={DomainChecker} />
      <Route path="/tools/ssl-checker" component={SslChecker} />
      <Route path="/tools/page-speed-test" component={PageSpeedTest} />
      <Route path="/tools/seo-analyzer" component={SeoAnalyzer} />
      <Route path="/tools/meta-tag-generator" component={MetaTagGenerator} />
      <Route path="/tools/sitemap-generator" component={SitemapGenerator} />
      <Route path="/tools/robots-txt-generator" component={RobotsTxtGenerator} />
      <Route path="/tools/htaccess-generator" component={HtaccessGenerator} />
      <Route path="/tools/csv-to-json" component={CsvToJson} />
      <Route path="/tools/xml-formatter" component={XmlFormatter} />
      <Route path="/tools/sql-formatter" component={SqlFormatter} />
      <Route path="/tools/image-resizer" component={ImageResizer} />
      <Route path="/tools/favicon-generator" component={FaviconGenerator} />
      <Route path="/tools/email-validator" component={EmailValidator} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
