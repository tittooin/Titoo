import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Tool } from "@/data/tools";
import * as Icons from "lucide-react";

interface ToolCardProps {
  tool: Tool;
}

const colorClasses = {
  red: 'bg-red-100 text-red-600',
  blue: 'bg-blue-100 text-blue-600',
  green: 'bg-green-100 text-green-600',
  yellow: 'bg-yellow-100 text-yellow-600',
  purple: 'bg-purple-100 text-purple-600',
  pink: 'bg-pink-100 text-pink-600',
  indigo: 'bg-indigo-100 text-indigo-600',
  orange: 'bg-orange-100 text-orange-600',
  gray: 'bg-gray-100 text-gray-600',
  cyan: 'bg-cyan-100 text-cyan-600',
  teal: 'bg-teal-100 text-teal-600',
  emerald: 'bg-emerald-100 text-emerald-600'
};

export default function ToolCard({ tool }: ToolCardProps) {
  const IconComponent = Icons[tool.icon as keyof typeof Icons] as any;
  const iconColorClass = colorClasses[tool.color as keyof typeof colorClasses];

  return (
    <Card className="tool-card bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all">
      <CardContent className="p-0">
        <div className="flex items-center mb-4">
          <div className={`w-12 h-12 ${iconColorClass} rounded-lg flex items-center justify-center mr-4`}>
            {IconComponent && <IconComponent className="w-6 h-6" />}
          </div>
          <h3 className="text-lg font-semibold text-gray-900">{tool.title}</h3>
        </div>
        <p className="text-gray-600 mb-4">{tool.description}</p>
        <Link href={tool.path} className="inline-flex items-center text-primary hover:text-secondary font-medium">
          Use Tool <ArrowRight className="ml-2 w-4 h-4" />
        </Link>
      </CardContent>
    </Card>
  );
}
