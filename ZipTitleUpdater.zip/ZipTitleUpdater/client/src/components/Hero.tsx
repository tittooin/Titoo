export default function Hero() {
  return (
    <section className="gradient-bg text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">35 Essential Online Tools</h1>
        <p className="text-xl md:text-2xl mb-8 text-blue-100">
          Boost your productivity with our comprehensive collection of free online tools. No registration required.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">35</div>
            <div className="text-blue-100">Tools Available</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">100%</div>
            <div className="text-blue-100">Free to Use</div>
          </div>
          <div className="text-center">
            <div className="text-4xl font-bold mb-2">0</div>
            <div className="text-blue-100">Registration Required</div>
          </div>
        </div>
      </div>
    </section>
  );
}
