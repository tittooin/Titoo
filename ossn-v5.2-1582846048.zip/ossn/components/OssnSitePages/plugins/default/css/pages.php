.ossn-site-pages-title {
    background: #F9F7F7;
    border: 1px solid #eee;
    padding: 10px;
    font-weight: bold;
}
.ossn-site-pages-body {
    padding: 10px;
}
@media only screen
and (max-width : 1360px) {
.ossn-site-pages{
    margin-left: 15px;
    margin-right: 15px
    }
}
@media only screen
and (min-width : 1360px) {
.ossn-site-pages{
    margin-left: 80px;
    margin-right: 80px
    }
}
