import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { businessCategories } from "@/lib/templates";
import { Store, Instagram, FileText, RefreshCw, Sparkles } from "lucide-react";

interface ContentGeneratorProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  onGenerateCaption: (input: string) => void;
  onGenerateSummary: (input: string) => void;
  onGenerateMoreVariations: (input: string) => void;
  isGenerating: boolean;
}

export function ContentGenerator({
  selectedCategory,
  onCategoryChange,
  onGenerateCaption,
  onGenerateSummary,
  onGenerateMoreVariations,
  isGenerating
}: ContentGeneratorProps) {
  const [captionInput, setCaptionInput] = useState("");
  const [articleInput, setArticleInput] = useState("");

  const handleGenerateCaption = () => {
    if (!captionInput.trim()) {
      alert('Please enter your post topic first!');
      return;
    }
    onGenerateCaption(captionInput);
  };

  const handleGenerateSummary = () => {
    if (!articleInput.trim() || articleInput.length < 50) {
      alert('Please write an article with at least 50 words!');
      return;
    }
    onGenerateSummary(articleInput);
  };

  const handleGenerateMoreVariations = () => {
    if (!captionInput.trim()) {
      alert('Please enter your post topic first!');
      return;
    }
    onGenerateMoreVariations(captionInput);
  };

  return (
    <div className="space-y-6">
      {/* Business Category Selection */}
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
            <Store className="h-5 w-5 text-insta-blue mr-2" />
            Choose Business Type
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {businessCategories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                className={`p-4 h-auto flex flex-col items-center space-y-2 transition-all hover:border-insta-blue hover:bg-blue-50 ${
                  selectedCategory === category.id 
                    ? "bg-insta-blue hover:bg-insta-blue border-insta-blue text-white" 
                    : "border-gray-200"
                }`}
                onClick={() => onCategoryChange(category.id)}
              >
                <span className="text-xl">{category.icon}</span>
                <span className="text-sm font-medium font-hindi">{category.name}</span>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Caption Generator */}
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
            <Instagram className="h-5 w-5 text-insta-magenta mr-2" />
            Instagram Caption Generator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="caption-input" className="block text-sm font-medium text-gray-700 mb-2 font-ui">
              Your Post Topic
            </Label>
            <Input
              id="caption-input"
              type="text"
              placeholder="e.g.: new menu launch, special offer, event..."
              value={captionInput}
              onChange={(e) => setCaptionInput(e.target.value)}
              className="font-ui"
              disabled={isGenerating}
            />
          </div>
          
          <div className="flex flex-wrap gap-3">
            <Button 
              onClick={handleGenerateCaption}
              disabled={isGenerating}
              className="bg-gradient-to-r from-insta-blue to-insta-magenta hover:shadow-lg transition-all font-ui"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Generate Caption
            </Button>
            
            <Button 
              variant="outline"
              onClick={handleGenerateMoreVariations}
              disabled={isGenerating}
              className="border-gray-300 hover:bg-gray-50 font-ui"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              More Options
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Article Summarizer */}
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
            <FileText className="h-5 w-5 text-insta-orange mr-2" />
            Article Summary Generator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="article-input" className="block text-sm font-medium text-gray-700 mb-2 font-ui">
              Paste long article or post
            </Label>
            <Textarea
              id="article-input"
              placeholder="Paste your long content here..."
              rows={4}
              value={articleInput}
              onChange={(e) => setArticleInput(e.target.value)}
              className="resize-none font-ui"
              disabled={isGenerating}
            />
            <p className="text-xs text-gray-500 mt-2 font-ui">Maximum 1000 words</p>
          </div>
          
          <Button 
            onClick={handleGenerateSummary}
            disabled={isGenerating}
            className="bg-gradient-to-r from-insta-orange to-insta-magenta hover:shadow-lg transition-all font-ui"
          >
            <FileText className="h-4 w-4 mr-2" />
            Generate 3-4 Line Summary
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
