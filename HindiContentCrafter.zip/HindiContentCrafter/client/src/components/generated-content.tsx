import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { popularEmojis, quickPostTemplates } from "@/lib/templates";
import { Instagram, FileText, Rocket, Copy, Heart, Percent, Star, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { GeneratedContent } from "@/hooks/use-content-generator";

interface GeneratedContentProps {
  captionContent: GeneratedContent | null;
  summaryContent: GeneratedContent | null;
  onGenerateQuickPost: (type: keyof typeof quickPostTemplates) => void;
  onAddEmoji: (emoji: string) => void;
  isGenerating: boolean;
}

export function GeneratedContent({
  captionContent,
  summaryContent,
  onGenerateQuickPost,
  onAddEmoji,
  isGenerating
}: GeneratedContentProps) {
  const { toast } = useToast();
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = async (text: string, type: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedText(text);
      toast({
        title: "Copied!",
        description: `${type} successfully copied.`,
        duration: 3000,
      });
      setTimeout(() => setCopiedText(null), 3000);
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy manually.",
        variant: "destructive",
        duration: 3000,
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Generated Caption Output */}
      {captionContent && (
        <Card className="border-gray-200 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
                <Instagram className="h-5 w-5 text-insta-magenta mr-2" />
                Generated Caption
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-xs font-ui">
                  {captionContent.characterCount}/2200
                </Badge>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(captionContent.text, "कैप्शन")}
                  className="h-8 w-8 p-0 hover:text-insta-success transition-colors"
                  title="Copy to clipboard"
                >
                  {copiedText === captionContent.text ? (
                    <CheckCircle className="h-4 w-4 text-insta-success" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 rounded-xl p-4 font-hindi text-base leading-relaxed mb-4">
              {captionContent.text}
            </div>
            
            {captionContent.hashtags.length > 0 && (
              <div className="flex flex-wrap gap-2 items-center">
                <span className="text-xs text-gray-500 font-ui">Suggested hashtags:</span>
                {captionContent.hashtags.map((hashtag, index) => (
                  <Badge
                    key={index}
                    variant="outline"
                    className="bg-blue-100 text-insta-blue border-blue-200 cursor-pointer hover:bg-blue-200 transition-colors font-ui"
                    onClick={() => onAddEmoji(` ${hashtag}`)}
                  >
                    {hashtag}
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Generated Summary Output */}
      {summaryContent && (
        <Card className="border-gray-200 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
                <FileText className="h-5 w-5 text-insta-orange mr-2" />
                Generated Summary
              </CardTitle>
              <div className="flex items-center space-x-2">
                <Badge variant="secondary" className="text-xs font-ui">
                  {summaryContent.characterCount}/280
                </Badge>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(summaryContent.text, "सम्मरी")}
                  className="h-8 w-8 p-0 hover:text-insta-success transition-colors"
                  title="Copy to clipboard"
                >
                  {copiedText === summaryContent.text ? (
                    <CheckCircle className="h-4 w-4 text-insta-success" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 rounded-xl p-4 font-hindi text-base leading-relaxed">
              {summaryContent.text}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Actions */}
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
            <Rocket className="h-5 w-5 text-insta-blue mr-2" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <Button
              variant="outline"
              className="w-full p-4 h-auto flex items-center justify-start space-x-3 border-gray-200 hover:bg-gray-50 transition-all"
              onClick={() => onGenerateQuickPost('motivation')}
              disabled={isGenerating}
            >
              <Heart className="h-5 w-5 text-red-500" />
              <div className="text-left">
                <p className="font-medium text-insta-dark font-ui">Motivational Post</p>
                <p className="text-xs text-gray-500 font-ui">Inspirational content</p>
              </div>
            </Button>
            
            <Button
              variant="outline"
              className="w-full p-4 h-auto flex items-center justify-start space-x-3 border-gray-200 hover:bg-gray-50 transition-all"
              onClick={() => onGenerateQuickPost('offer')}
              disabled={isGenerating}
            >
              <Percent className="h-5 w-5 text-green-500" />
              <div className="text-left">
                <p className="font-medium text-insta-dark font-ui">Offer Post</p>
                <p className="text-xs text-gray-500 font-ui">Special deal content</p>
              </div>
            </Button>
            
            <Button
              variant="outline"
              className="w-full p-4 h-auto flex items-center justify-start space-x-3 border-gray-200 hover:bg-gray-50 transition-all"
              onClick={() => onGenerateQuickPost('festival')}
              disabled={isGenerating}
            >
              <Star className="h-5 w-5 text-insta-orange" />
              <div className="text-left">
                <p className="font-medium text-insta-dark font-ui">Festival Post</p>
                <p className="text-xs text-gray-500 font-ui">Holiday content</p>
              </div>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Emoji Picker */}
      <Card className="border-gray-200 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="text-lg font-semibold text-insta-dark flex items-center font-ui">
            <span className="text-insta-orange mr-2">😊</span>
            Popular Emojis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-6 gap-2">
            {popularEmojis.map((emoji, index) => (
              <Button
                key={index}
                variant="ghost"
                className="p-2 text-2xl h-auto hover:bg-gray-100 rounded-lg transition-all"
                onClick={() => onAddEmoji(emoji)}
              >
                {emoji}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
