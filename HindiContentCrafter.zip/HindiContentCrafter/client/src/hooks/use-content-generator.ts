import { useState, useCallback } from "react";
import { contentTemplates, hashtagSets, quickPostTemplates } from "@/lib/templates";
import { TextProcessor } from "@/lib/text-processor";

export interface GeneratedContent {
  text: string;
  hashtags: string[];
  characterCount: number;
}

export function useContentGenerator() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("restaurant");

  const generateCaption = useCallback(async (input: string): Promise<GeneratedContent> => {
    setIsGenerating(true);
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    try {
      const templates = contentTemplates[selectedCategory] || contentTemplates.restaurant;
      const randomTemplate = templates[Math.floor(Math.random() * templates.length)];
      
      const variables: Record<string, string> = {};
      randomTemplate.variables.forEach(variable => {
        variables[variable] = input;
      });
      
      const generatedText = TextProcessor.generateCaption(randomTemplate.template, variables);
      const hashtags = hashtagSets[selectedCategory] || hashtagSets.restaurant;
      
      return {
        text: generatedText,
        hashtags: hashtags.slice(0, 4),
        characterCount: TextProcessor.getCharacterCount(generatedText)
      };
    } finally {
      setIsGenerating(false);
    }
  }, [selectedCategory]);

  const generateSummary = useCallback(async (input: string): Promise<GeneratedContent> => {
    setIsGenerating(true);
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    try {
      const summary = TextProcessor.generateSummary(input, 3);
      
      return {
        text: summary,
        hashtags: [],
        characterCount: TextProcessor.getCharacterCount(summary)
      };
    } finally {
      setIsGenerating(false);
    }
  }, []);

  const generateQuickPost = useCallback(async (type: keyof typeof quickPostTemplates): Promise<GeneratedContent> => {
    setIsGenerating(true);
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    try {
      const text = quickPostTemplates[type];
      
      return {
        text,
        hashtags: [],
        characterCount: TextProcessor.getCharacterCount(text)
      };
    } finally {
      setIsGenerating(false);
    }
  }, []);

  return {
    isGenerating,
    selectedCategory,
    setSelectedCategory,
    generateCaption,
    generateSummary,
    generateQuickPost,
  };
}
