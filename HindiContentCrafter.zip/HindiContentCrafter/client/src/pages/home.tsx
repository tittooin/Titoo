import { useState } from "react";
import { ContentGenerator } from "@/components/content-generator";
import { GeneratedContent } from "@/components/generated-content";
import { useContentGenerator, type GeneratedContent as GeneratedContentType } from "@/hooks/use-content-generator";
import { quickPostTemplates } from "@/lib/templates";
import { Bell, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const {
    isGenerating,
    selectedCategory,
    setSelectedCategory,
    generateCaption,
    generateSummary,
    generateQuickPost,
  } = useContentGenerator();

  const [captionContent, setCaptionContent] = useState<GeneratedContentType | null>(null);
  const [summaryContent, setSummaryContent] = useState<GeneratedContentType | null>(null);

  const handleGenerateCaption = async (input: string) => {
    const result = await generateCaption(input);
    setCaptionContent(result);
  };

  const handleGenerateSummary = async (input: string) => {
    const result = await generateSummary(input);
    setSummaryContent(result);
  };

  const handleGenerateQuickPost = async (type: keyof typeof quickPostTemplates) => {
    const result = await generateQuickPost(type);
    setCaptionContent(result);
  };

  const handleGenerateMoreVariations = async (input: string) => {
    const result = await generateCaption(input);
    setCaptionContent(result);
  };

  const handleAddEmoji = (emoji: string) => {
    if (captionContent) {
      setCaptionContent({
        ...captionContent,
        text: captionContent.text + ' ' + emoji,
        characterCount: captionContent.text.length + emoji.length + 1,
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-insta-blue to-insta-magenta rounded-xl flex items-center justify-center">
                <Sparkles className="text-white text-lg" />
              </div>
              <div>
                <h1 className="text-xl font-semibold text-insta-dark font-ui">Social Media Content Creator</h1>
                <p className="text-sm text-gray-500 font-ui">Create engaging social media content</p>
              </div>
            </div>
            
            {/* User Profile */}
            <div className="flex items-center space-x-4">
              <Button size="sm" variant="ghost" className="p-2 text-gray-400 hover:text-insta-blue transition-colors">
                <Bell className="h-5 w-5" />
              </Button>
              <div className="w-8 h-8 bg-gradient-to-r from-insta-orange to-insta-magenta rounded-full"></div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Content Generator Section */}
          <div className="lg:col-span-2">
            <ContentGenerator
              selectedCategory={selectedCategory}
              onCategoryChange={setSelectedCategory}
              onGenerateCaption={handleGenerateCaption}
              onGenerateSummary={handleGenerateSummary}
              onGenerateMoreVariations={handleGenerateMoreVariations}
              isGenerating={isGenerating}
            />
          </div>

          {/* Generated Content Section */}
          <div>
            <GeneratedContent
              captionContent={captionContent}
              summaryContent={summaryContent}
              onGenerateQuickPost={handleGenerateQuickPost}
              onAddEmoji={handleAddEmoji}
              isGenerating={isGenerating}
            />
          </div>
        </div>
      </main>

      {/* Loading Overlay */}
      {isGenerating && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-2xl p-8 max-w-sm mx-4 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-insta-blue mx-auto mb-4"></div>
            <p className="text-insta-dark font-medium font-ui">Generating content...</p>
            <p className="text-gray-500 text-sm mt-2 font-ui">Please wait</p>
          </div>
        </div>
      )}
    </div>
  );
}
