export class TextProcessor {
  static generateSummary(text: string, maxLines: number = 3): string {
    if (!text || text.trim().length < 50) {
      return "";
    }

    // Split text into sentences (using Hindi sentence ending patterns)
    const sentences = text
      .split(/[।.!?]+/)
      .map(s => s.trim())
      .filter(s => s.length > 20);

    if (sentences.length === 0) {
      return "";
    }

    // For simple extractive summarization, take the first few sentences
    // and the most important ones (those with question words or key phrases)
    const importantSentences = sentences.filter(sentence => 
      sentence.includes('क्या') || 
      sentence.includes('कैसे') || 
      sentence.includes('क्यों') ||
      sentence.includes('महत्वपूर्ण') ||
      sentence.includes('जरूरी') ||
      sentence.includes('फायदा') ||
      sentence.includes('नुकसान')
    );

    let selectedSentences: string[] = [];
    
    // Add first sentence if available
    if (sentences.length > 0) {
      selectedSentences.push(sentences[0]);
    }
    
    // Add important sentences
    if (importantSentences.length > 0 && selectedSentences.length < maxLines) {
      selectedSentences.push(...importantSentences.slice(0, maxLines - selectedSentences.length));
    }
    
    // Fill remaining slots with other sentences
    while (selectedSentences.length < maxLines && selectedSentences.length < sentences.length) {
      const nextSentence = sentences.find(s => !selectedSentences.includes(s));
      if (nextSentence) {
        selectedSentences.push(nextSentence);
      } else {
        break;
      }
    }

    return selectedSentences.join('। ') + '।';
  }

  static generateCaption(template: string, variables: Record<string, string>): string {
    let result = template;
    
    Object.entries(variables).forEach(([key, value]) => {
      const placeholder = `{${key}}`;
      result = result.replace(new RegExp(placeholder, 'g'), value);
    });

    return result;
  }

  static getCharacterCount(text: string): number {
    return text.length;
  }

  static isWithinLimit(text: string, limit: number): boolean {
    return text.length <= limit;
  }

  static addEmojisToText(text: string, emojis: string[]): string {
    if (emojis.length === 0) return text;
    
    const randomEmojis = emojis.slice(0, 2 + Math.floor(Math.random() * 3));
    return text + ' ' + randomEmojis.join(' ');
  }
}
