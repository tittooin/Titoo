export interface BusinessCategory {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface ContentTemplate {
  id: string;
  template: string;
  variables: string[];
}

export interface EmojiSet {
  category: string;
  emojis: string[];
}

export const businessCategories: BusinessCategory[] = [
  {
    id: "restaurant",
    name: "Restaurant",
    icon: "🍽️",
    color: "text-orange-500",
  },
  {
    id: "fashion",
    name: "Fashion",
    icon: "👗",
    color: "text-pink-500",
  },
  {
    id: "fitness",
    name: "Fitness",
    icon: "💪",
    color: "text-green-500",
  },
  {
    id: "beauty",
    name: "Beauty",
    icon: "💄",
    color: "text-purple-500",
  },
  {
    id: "tech",
    name: "Technology",
    icon: "💻",
    color: "text-blue-500",
  },
  {
    id: "education",
    name: "Education",
    icon: "🎓",
    color: "text-indigo-500",
  },
];

export const contentTemplates: Record<string, ContentTemplate[]> = {
  restaurant: [
    {
      id: "restaurant-1",
      template: "Today's special {dish} 🍽️ Delicious food, amazing atmosphere ✨ Order now! 📞",
      variables: ["dish"],
    },
    {
      id: "restaurant-2",
      template: "Happiness is hidden in the taste of {dish}! 😋 Come with family and get special discounts 🎉",
      variables: ["dish"],
    },
    {
      id: "restaurant-3",
      template: "New flavors every day, every meal is exceptional! 🔥 Don't forget to try {dish} 💯",
      variables: ["dish"],
    },
  ],
  fashion: [
    {
      id: "fashion-1",
      template: "This season's trending collection {style} ✨ Perfect combo of style and comfort 👗",
      variables: ["style"],
    },
    {
      id: "fashion-2",
      template: "Give your style a new look with {style}! 💃 Up to 50% off 🎊",
      variables: ["style"],
    },
    {
      id: "fashion-3",
      template: "Your personality is hidden in every dress 🌟 Check out {style} collection 💎",
      variables: ["style"],
    },
  ],
  fitness: [
    {
      id: "fitness-1",
      template: "Today's workout {exercise} 💪 Stay fit, stay healthy! Join our fitness group ✨",
      variables: ["exercise"],
    },
    {
      id: "fitness-2",
      template: "See your transformation in just 30 days! 🔥 Start with {exercise} today 🎯",
      variables: ["exercise"],
    },
    {
      id: "fitness-3",
      template: "Boost energy, strength and confidence with {exercise} 💯 Book your free trial class! 📞",
      variables: ["exercise"],
    },
  ],
  beauty: [
    {
      id: "beauty-1",
      template: "The secret of beauty lies in {treatment}! ✨ Natural and safe treatments 🌿",
      variables: ["treatment"],
    },
    {
      id: "beauty-2",
      template: "Give your skin the gift of {treatment} 💎 Book your appointment today! 📞",
      variables: ["treatment"],
    },
  ],
  tech: [
    {
      id: "tech-1",
      template: "Move ahead in the world of technology with {service}! 💻 Digital solutions, better future ✨",
      variables: ["service"],
    },
    {
      id: "tech-2",
      template: "New technology, new opportunities! Build your digital future with {service} 🚀",
      variables: ["service"],
    },
  ],
  education: [
    {
      id: "education-1",
      template: "Change your future with the power of knowledge! Taking admissions in {course} 📚 Limited seats! 🎯",
      variables: ["course"],
    },
    {
      id: "education-2",
      template: "The path to success goes through {course}! 🌟 Expert teachers, best results 📈",
      variables: ["course"],
    },
  ],
};

export const hashtagSets: Record<string, string[]> = {
  restaurant: ["#FoodLover", "#LocalEats", "#DeliverAvailable", "#FreshFood", "#SpecialOffer", "#TastyFood"],
  fashion: ["#Fashion", "#Style", "#NewCollection", "#TrendingNow", "#Sale", "#Fashionista"],
  fitness: ["#Fitness", "#Health", "#Workout", "#Motivation", "#StrongBody", "#HealthyLifestyle"],
  beauty: ["#Beauty", "#Skincare", "#NaturalBeauty", "#Glow", "#SelfCare", "#BeautyTreatment"],
  tech: ["#Technology", "#Digital", "#Innovation", "#TechSolutions", "#Future", "#DigitalIndia"],
  education: ["#Education", "#Learning", "#Skills", "#Career", "#Success", "#KnowledgeIsPower"],
};

export const popularEmojis: string[] = [
  "🍽️", "🎉", "❤️", "🔥", "✨", "💯",
  "🎊", "🌟", "💝", "🎯", "📸", "💪",
  "😋", "👗", "💄", "📚", "🚀", "💻",
  "🌿", "💎", "📞", "🏆", "🎁", "⭐"
];

export const quickPostTemplates = {
  motivation: "Every morning is a new beginning! 🌅 Work hard for your dreams today too 💪 Success is waiting for you ✨ #Motivation #SuccessStory #DreamBig #PositiveVibes",
  offer: "Amazing offer! 🎉 Up to 50% off today only 🔥 Hurry up, limited stock! 📞 Order now #SpecialOffer #LimitedTime #BigSale #DontMiss",
  festival: "May this festival bring showers of happiness! 🎊 Heartfelt wishes to you and your family ✨ Call for special festival offers 📞 #Festival #Celebration #FamilyTime #SpecialOffer"
};
