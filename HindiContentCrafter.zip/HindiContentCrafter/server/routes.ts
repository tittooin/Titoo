import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // Templates endpoint
  app.get("/api/templates/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const templates = await storage.getTemplatesByCategory(category);
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch templates" });
    }
  });

  // Generate content endpoint
  app.post("/api/generate", async (req, res) => {
    try {
      const { category, inputText, type } = req.body;
      
      if (!category || !inputText || !type) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      const generatedContent = await storage.createGeneratedContent({
        userId: null,
        category,
        inputText,
        generatedText: inputText, // This would be processed by AI/templates
        type,
      });

      res.json(generatedContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate content" });
    }
  });

  // Content history endpoint
  app.get("/api/content/history", async (req, res) => {
    try {
      const history = await storage.getContentHistory();
      res.json(history);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch history" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
