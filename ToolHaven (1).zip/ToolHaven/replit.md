# replit.md

## Overview

This is a full-stack web application built with React, Express.js, and PostgreSQL. The application serves as an "OnlineToolsHub" - a platform that provides 30+ free online tools for various tasks like PDF manipulation, video processing, AI interactions, and more. The application also includes a blog system and contact functionality.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Build Tool**: Vite for development and production builds
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Schema Validation**: Zod for runtime type checking
- **Session Management**: PostgreSQL session store (connect-pg-simple)

### Development Setup
- **Monorepo Structure**: Shared code between client and server
- **Hot Reload**: Vite development server with Express middleware
- **TypeScript**: Full-stack TypeScript with path mapping
- **ESM**: Modern ES modules throughout

## Key Components

### Database Schema
- **Users**: Basic user authentication system
- **Blog Posts**: Content management with categories, tags, and images
- **Contact Messages**: Form submissions storage
- **Schema Location**: `shared/schema.ts` using Drizzle ORM

### API Routes
- **Blog Posts**: CRUD operations (`/api/blog-posts`)
- **Contact Form**: Message submission (`/api/contact`)
- **Validation**: Zod schemas for request validation

### Frontend Components
- **Navigation**: Sticky navigation with smooth scrolling
- **Hero Section**: Landing page with search functionality
- **Tools Grid**: Categorized tool display with filtering
- **Blog Section**: Blog post management and display
- **Contact Section**: Contact form with validation
- **Tool Modals**: Interactive tool interfaces

### Tools System
- **30+ Tools**: PDF, video, AI, converter, image, and text tools
- **Modal Interface**: Each tool opens in a dedicated modal
- **Categorization**: Tools organized by type and functionality
- **Search & Filter**: Real-time search and category filtering

## Data Flow

1. **Client Requests**: React components use TanStack Query for data fetching
2. **API Layer**: Express.js routes handle HTTP requests
3. **Validation**: Zod schemas validate incoming data
4. **Database**: Drizzle ORM manages PostgreSQL operations
5. **Response**: JSON responses sent back to client
6. **State Management**: TanStack Query caches and synchronizes data

## External Dependencies

### Core Technologies
- **Database**: PostgreSQL (Neon serverless)
- **ORM**: Drizzle with PostgreSQL dialect
- **UI Library**: Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables
- **Form Handling**: React Hook Form with Zod resolvers

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety across the stack
- **ESBuild**: Server-side bundling for production
- **Replit Integration**: Development environment integration

## Deployment Strategy

### Development
- **Command**: `npm run dev` - Starts development server with hot reload
- **Vite Integration**: Middleware mode for seamless development
- **Type Checking**: `npm run check` for TypeScript validation

### Production Build
- **Client**: Vite builds to `dist/public`
- **Server**: ESBuild bundles to `dist/index.js`
- **Command**: `npm run build` - Full-stack production build

### Database Management
- **Migrations**: Drizzle migrations in `./migrations`
- **Push Schema**: `npm run db:push` - Apply schema changes
- **Environment**: `DATABASE_URL` required for connection

## User Preferences

Preferred communication style: Simple, everyday language.

## Static Hosting Package

For shared hosting deployment, a complete static HTML version is available in the `static-build/` directory:

- **index.html**: Complete standalone website with TailwindCSS CDN
- **README.md**: Detailed deployment instructions for various hosting providers
- **.htaccess**: Apache configuration for better performance and security

This static version includes all functionality except the blog creation and contact form submission (requires backend integration).

## Changelog

Changelog:
- July 01, 2025. Initial setup
- July 01, 2025. Updated branding to "TittoosOnlineTools"
- July 01, 2025. Updated blog post dates to current dates (2024-2025)
- July 01, 2025. Created static HTML version for shared hosting deployment