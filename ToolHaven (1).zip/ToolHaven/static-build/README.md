# TittoosOnlineTools - Static Website for Shared Hosting

This is a standalone HTML version of the TittoosOnlineTools website that can be deployed to any shared hosting provider.

## Files Included

- `index.html` - Complete website in a single HTML file
- `README.md` - This deployment guide

## Deployment Instructions

### For Shared Hosting (cPanel, etc.)

1. **Upload the file:**
   - Log into your hosting control panel (cPanel, etc.)
   - Navigate to File Manager
   - Go to your domain's public_html folder (or www folder)
   - Upload the `index.html` file

2. **Set as default:**
   - Rename `index.html` to match your hosting provider's default file name if needed
   - Most hosts use `index.html` as the default, so no changes should be needed

3. **Access your site:**
   - Visit your domain - the website should load immediately

### For GitHub Pages

1. Create a new repository on GitHub
2. Upload the `index.html` file to the repository
3. Go to Settings > Pages
4. Select "Deploy from a branch" and choose "main"
5. Your site will be available at `https://yourusername.github.io/repository-name`

### For Netlify

1. Go to [netlify.com](https://netlify.com)
2. Drag and drop the `index.html` file to the deploy area
3. Your site will be deployed instantly with a custom URL

### For Vercel

1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Upload the `index.html` file
4. Deploy immediately

## Features Included

- ✅ Professional navigation with smooth scrolling
- ✅ Hero section with search functionality
- ✅ 30+ online tools showcase
- ✅ Blog section with sample posts
- ✅ Contact form (static - you'll need to add backend for functionality)
- ✅ Professional footer
- ✅ Mobile responsive design
- ✅ SEO optimized (meta tags, descriptions)
- ✅ Uses TailwindCSS CDN for styling

## Notes

- **Contact Form:** The contact form is currently static. To make it functional, you'll need to:
  - Use a service like Formspree, Netlify Forms, or EmailJS
  - Add your own backend API
  - Use your hosting provider's form handling service

- **Search Functionality:** Basic client-side search is implemented. For advanced search, you may want to integrate with a search service.

- **Performance:** The site uses TailwindCSS CDN for quick deployment. For production, consider using a custom build for better performance.

## Customization

To customize the website:

1. Open `index.html` in any text editor
2. Modify the content, colors, or layout as needed
3. Save and re-upload to your hosting provider

## Support

For any issues or questions about deployment, check your hosting provider's documentation or contact their support team.

---

**TittoosOnlineTools** - Your one-stop destination for 30+ free online tools.