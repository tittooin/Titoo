import { users, blogPosts, contactMessages, type User, type InsertUser, type BlogPost, type InsertBlogPost, type ContactMessage, type InsertContactMessage } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getAllBlogPosts(): Promise<BlogPost[]>;
  getBlogPost(id: number): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  
  createContactMessage(message: InsertContactMessage): Promise<ContactMessage>;
  getAllContactMessages(): Promise<ContactMessage[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private blogPosts: Map<number, BlogPost>;
  private contactMessages: Map<number, ContactMessage>;
  private currentUserId: number;
  private currentBlogPostId: number;
  private currentContactMessageId: number;

  constructor() {
    this.users = new Map();
    this.blogPosts = new Map();
    this.contactMessages = new Map();
    this.currentUserId = 1;
    this.currentBlogPostId = 1;
    this.currentContactMessageId = 1;
    
    // Initialize with sample blog posts
    this.initializeBlogPosts();
  }

  private initializeBlogPosts() {
    const samplePosts: Omit<BlogPost, 'id'>[] = [
      {
        title: "10 Best PDF Tools Every Professional Needs",
        content: "Discover the essential PDF tools that can streamline your workflow and boost productivity in your daily tasks. From merging multiple documents to compressing large files, these tools will revolutionize how you handle PDF documents.\n\nPDF tools have become indispensable in today's digital workplace. Whether you're a business professional, student, or freelancer, mastering these tools can significantly improve your efficiency. Let's explore the top 10 PDF tools that every professional should have in their toolkit.\n\n1. PDF Merger - Combine multiple documents seamlessly\n2. PDF Splitter - Extract specific pages with precision\n3. PDF Compressor - Reduce file sizes without quality loss\n4. PDF Converter - Transform documents between formats\n5. PDF Editor - Make quick edits and annotations\n\nThese tools not only save time but also ensure your documents maintain professional standards across all platforms and devices.",
        category: "PDF Tools",
        imageUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["PDF", "productivity", "business", "tools", "workflow"],
        createdAt: new Date("2025-01-01")
      },
      {
        title: "How AI is Revolutionizing Online Tools",
        content: "Explore how artificial intelligence is transforming the way we interact with online tools and automating complex tasks. The integration of AI technology is making tools smarter, faster, and more intuitive than ever before.\n\nArtificial Intelligence has entered the mainstream of online tools, bringing unprecedented capabilities to everyday tasks. From intelligent document processing to automated content generation, AI is reshaping how we work with digital tools.\n\nKey AI advancements in online tools:\n- Natural language processing for better user interactions\n- Machine learning algorithms that adapt to user preferences\n- Computer vision for advanced image and document processing\n- Predictive analytics for optimized workflows\n\nThe future of online tools lies in AI integration, making complex tasks accessible to everyone while maintaining professional-grade results.",
        category: "AI Tools",
        imageUrl: "https://images.unsplash.com/photo-1677442136019-21780ecad995?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["AI", "artificial intelligence", "automation", "machine learning", "technology"],
        createdAt: new Date("2024-12-30")
      },
      {
        title: "Video Compression Guide: Quality vs File Size",
        content: "Learn the best practices for compressing videos while maintaining optimal quality for different use cases. Understanding the balance between file size and quality is crucial for effective video management.\n\nVideo compression is both an art and a science. Whether you're preparing content for web streaming, email attachments, or storage optimization, finding the right balance is essential.\n\nCompression strategies by use case:\n- Web streaming: Prioritize fast loading times\n- Professional presentations: Maintain high quality\n- Social media: Optimize for platform requirements\n- Email sharing: Focus on file size reduction\n- Archive storage: Balance quality and space\n\nModern compression algorithms offer sophisticated options for maintaining visual quality while achieving significant size reductions. The key is understanding your specific needs and choosing the right settings accordingly.",
        category: "Video Tools",
        imageUrl: "https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["video", "compression", "optimization", "streaming", "quality"],
        createdAt: new Date("2024-12-28")
      },
      {
        title: "Online Tool Security: What You Need to Know",
        content: "Essential security considerations when using online tools and how to protect your data and privacy. In an age of increasing digital threats, understanding security best practices is more important than ever.\n\nSecurity should be a top priority when selecting and using online tools. With sensitive data frequently processed through web-based applications, users must be vigilant about protecting their information.\n\nKey security considerations:\n- End-to-end encryption for sensitive documents\n- Zero-knowledge architecture that protects privacy\n- Secure file deletion after processing\n- Two-factor authentication where available\n- Regular security audits and updates\n\nWhen choosing online tools, look for providers who prioritize security and transparency. Read privacy policies, understand data handling practices, and always use reputable services for sensitive information.",
        category: "Security",
        imageUrl: "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=400",
        tags: ["security", "privacy", "data protection", "encryption", "cybersecurity"],
        createdAt: new Date("2024-12-25")
      }
    ];

    samplePosts.forEach(post => {
      const id = this.currentBlogPostId++;
      this.blogPosts.set(id, { ...post, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getAllBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getBlogPost(id: number): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }

  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.currentBlogPostId++;
    const post: BlogPost = { 
      ...insertPost, 
      id, 
      createdAt: new Date(),
      tags: insertPost.tags || [],
      imageUrl: insertPost.imageUrl || null
    };
    this.blogPosts.set(id, post);
    return post;
  }

  async createContactMessage(insertMessage: InsertContactMessage): Promise<ContactMessage> {
    const id = this.currentContactMessageId++;
    const message: ContactMessage = { 
      ...insertMessage, 
      id, 
      createdAt: new Date()
    };
    this.contactMessages.set(id, message);
    return message;
  }

  async getAllContactMessages(): Promise<ContactMessage[]> {
    return Array.from(this.contactMessages.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
}

export const storage = new MemStorage();
