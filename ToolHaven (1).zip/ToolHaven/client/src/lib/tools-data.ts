import { 
  FileText, 
  Video, 
  Bot, 
  Image, 
  Calculator, 
  Type, 
  Code, 
  Link, 
  Database, 
  Palette,
  QrCode,
  Hash,
  Key,
  Ruler,
  Clock,
  Search,
  Scissors,
  Archive,
  FileImage,
  Download,
  Edit,
  Wand2,
  RotateCcw,
  AlignLeft,
  FileCode,
  Globe,
  Languages,
  Zap
} from "lucide-react";

export interface Tool {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: any;
  bgColor: string;
  iconColor: string;
  tags: string[];
}

export const toolsData: Tool[] = [
  // PDF Tools
  {
    id: "pdf-merger",
    title: "PDF Merger",
    description: "Combine multiple PDF files into a single document",
    category: "pdf",
    icon: FileText,
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
    tags: ["Free", "Secure"]
  },
  {
    id: "pdf-splitter",
    title: "PDF Splitter",
    description: "Split PDF files into separate pages or sections",
    category: "pdf",
    icon: Scissors,
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
    tags: ["Free", "Fast"]
  },
  {
    id: "pdf-compressor",
    title: "PDF Compressor",
    description: "Reduce PDF file size while maintaining quality",
    category: "pdf",
    icon: Archive,
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
    tags: ["Free", "Quality"]
  },
  {
    id: "word-to-pdf",
    title: "Word to PDF",
    description: "Convert Word documents to PDF format",
    category: "pdf",
    icon: FileText,
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600",
    tags: ["Free", "Instant"]
  },

  // Video Tools
  {
    id: "youtube-downloader",
    title: "YouTube Downloader",
    description: "Download YouTube videos in various formats",
    category: "video",
    icon: Download,
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
    tags: ["Free", "HD Quality"]
  },
  {
    id: "video-compressor",
    title: "Video Compressor",
    description: "Compress video files to reduce size",
    category: "video",
    icon: Video,
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600",
    tags: ["Free", "Batch"]
  },
  {
    id: "video-converter",
    title: "Video Converter",
    description: "Convert videos between different formats",
    category: "video",
    icon: RotateCcw,
    bgColor: "bg-indigo-100",
    iconColor: "text-indigo-600",
    tags: ["Free", "Multi-format"]
  },
  {
    id: "video-editor",
    title: "Video Editor",
    description: "Basic video editing with trim and cut features",
    category: "video",
    icon: Edit,
    bgColor: "bg-green-100",
    iconColor: "text-green-600",
    tags: ["Free", "Easy"]
  },

  // AI Tools
  {
    id: "ai-chat",
    title: "AI Chat Assistant",
    description: "Chat with AI for questions and assistance",
    category: "ai",
    icon: Bot,
    bgColor: "bg-gradient-to-br from-purple-100 to-pink-100",
    iconColor: "text-purple-600",
    tags: ["Free", "Smart"]
  },
  {
    id: "ai-writer",
    title: "AI Content Writer",
    description: "Generate content with AI assistance",
    category: "ai",
    icon: Edit,
    bgColor: "bg-gradient-to-br from-blue-100 to-indigo-100",
    iconColor: "text-blue-600",
    tags: ["Free", "Creative"]
  },
  {
    id: "ai-translator",
    title: "AI Translator",
    description: "Translate text between 100+ languages",
    category: "ai",
    icon: Languages,
    bgColor: "bg-gradient-to-br from-green-100 to-teal-100",
    iconColor: "text-green-600",
    tags: ["Free", "100+ Languages"]
  },
  {
    id: "ai-summarizer",
    title: "AI Text Summarizer",
    description: "Summarize long texts into key points",
    category: "ai",
    icon: Zap,
    bgColor: "bg-gradient-to-br from-orange-100 to-red-100",
    iconColor: "text-orange-600",
    tags: ["Free", "Accurate"]
  },

  // Image Tools
  {
    id: "image-compressor",
    title: "Image Compressor",
    description: "Compress images without losing quality",
    category: "image",
    icon: Image,
    bgColor: "bg-green-100",
    iconColor: "text-green-600",
    tags: ["Free", "Lossless"]
  },
  {
    id: "image-resizer",
    title: "Image Resizer",
    description: "Resize images to specific dimensions",
    category: "image",
    icon: Ruler,
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600",
    tags: ["Free", "Precise"]
  },
  {
    id: "background-remover",
    title: "Background Remover",
    description: "Remove backgrounds from images instantly",
    category: "image",
    icon: Wand2,
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600",
    tags: ["Free", "AI-Powered"]
  },
  {
    id: "image-converter",
    title: "Image Converter",
    description: "Convert images between different formats",
    category: "image",
    icon: FileImage,
    bgColor: "bg-indigo-100",
    iconColor: "text-indigo-600",
    tags: ["Free", "Multiple Formats"]
  },

  // Text Tools
  {
    id: "word-counter",
    title: "Word Counter",
    description: "Count words, characters, and paragraphs",
    category: "text",
    icon: Calculator,
    bgColor: "bg-yellow-100",
    iconColor: "text-yellow-600",
    tags: ["Free", "Instant"]
  },
  {
    id: "text-formatter",
    title: "Text Formatter",
    description: "Format text with various styling options",
    category: "text",
    icon: AlignLeft,
    bgColor: "bg-teal-100",
    iconColor: "text-teal-600",
    tags: ["Free", "Flexible"]
  },
  {
    id: "case-converter",
    title: "Case Converter",
    description: "Convert text between different cases",
    category: "text",
    icon: Type,
    bgColor: "bg-pink-100",
    iconColor: "text-pink-600",
    tags: ["Free", "Multiple Cases"]
  },
  {
    id: "lorem-generator",
    title: "Lorem Ipsum Generator",
    description: "Generate placeholder text for design",
    category: "text",
    icon: FileCode,
    bgColor: "bg-gray-100",
    iconColor: "text-gray-600",
    tags: ["Free", "Customizable"]
  },

  // Converter Tools
  {
    id: "json-formatter",
    title: "JSON Formatter",
    description: "Format and validate JSON data",
    category: "converter",
    icon: Code,
    bgColor: "bg-orange-100",
    iconColor: "text-orange-600",
    tags: ["Free", "Validator"]
  },
  {
    id: "url-encoder",
    title: "URL Encoder/Decoder",
    description: "Encode and decode URLs safely",
    category: "converter",
    icon: Link,
    bgColor: "bg-cyan-100",
    iconColor: "text-cyan-600",
    tags: ["Free", "Bidirectional"]
  },
  {
    id: "base64-encoder",
    title: "Base64 Encoder",
    description: "Encode and decode Base64 strings",
    category: "converter",
    icon: Database,
    bgColor: "bg-lime-100",
    iconColor: "text-lime-600",
    tags: ["Free", "Secure"]
  },
  {
    id: "color-converter",
    title: "Color Converter",
    description: "Convert colors between HEX, RGB, HSL",
    category: "converter",
    icon: Palette,
    bgColor: "bg-rose-100",
    iconColor: "text-rose-600",
    tags: ["Free", "Multi-format"]
  },
  {
    id: "qr-generator",
    title: "QR Code Generator",
    description: "Create QR codes for text, URLs, and more",
    category: "converter",
    icon: QrCode,
    bgColor: "bg-emerald-100",
    iconColor: "text-emerald-600",
    tags: ["Free", "Customizable"]
  },
  {
    id: "hash-generator",
    title: "Hash Generator",
    description: "Generate MD5, SHA1, SHA256 hashes",
    category: "converter",
    icon: Hash,
    bgColor: "bg-violet-100",
    iconColor: "text-violet-600",
    tags: ["Free", "Multiple Algorithms"]
  },
  {
    id: "password-generator",
    title: "Password Generator",
    description: "Generate secure random passwords",
    category: "converter",
    icon: Key,
    bgColor: "bg-amber-100",
    iconColor: "text-amber-600",
    tags: ["Free", "Secure"]
  },
  {
    id: "unit-converter",
    title: "Unit Converter",
    description: "Convert between different units of measurement",
    category: "converter",
    icon: Ruler,
    bgColor: "bg-sky-100",
    iconColor: "text-sky-600",
    tags: ["Free", "Comprehensive"]
  },
  {
    id: "timestamp-converter",
    title: "Timestamp Converter",
    description: "Convert Unix timestamps to human-readable dates",
    category: "converter",
    icon: Clock,
    bgColor: "bg-stone-100",
    iconColor: "text-stone-600",
    tags: ["Free", "Bidirectional"]
  },
  {
    id: "regex-tester",
    title: "Regex Tester",
    description: "Test and debug regular expressions",
    category: "converter",
    icon: Search,
    bgColor: "bg-red-100",
    iconColor: "text-red-600",
    tags: ["Free", "Live Testing"]
  }
];
