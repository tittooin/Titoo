import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import ToolsGrid from "@/components/ToolsGrid";
import BlogSection from "@/components/BlogSection";
import ContactSection from "@/components/ContactSection";
import Footer from "@/components/Footer";
import ToolModal from "@/components/ToolModal";
import LegalModals from "@/components/LegalModals";
import { useState } from "react";

export default function Home() {
  const [selectedTool, setSelectedTool] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <Hero />
      <ToolsGrid onToolClick={setSelectedTool} />
      <BlogSection />
      <ContactSection />
      <Footer />
      <ToolModal 
        toolId={selectedTool} 
        onClose={() => setSelectedTool(null)} 
      />
      <LegalModals />
    </div>
  );
}
