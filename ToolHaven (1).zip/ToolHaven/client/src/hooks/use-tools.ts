import { useState, useMemo } from "react";
import { toolsData } from "@/lib/tools-data";

export function useTools() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredTools = useMemo(() => {
    let filtered = toolsData;

    // Filter by category
    if (selectedCategory !== "all") {
      filtered = filtered.filter(tool => tool.category === selectedCategory);
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(tool => 
        tool.title.toLowerCase().includes(query) ||
        tool.description.toLowerCase().includes(query) ||
        tool.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    return filtered;
  }, [searchQuery, selectedCategory]);

  return {
    tools: filteredTools,
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    totalTools: toolsData.length
  };
}
