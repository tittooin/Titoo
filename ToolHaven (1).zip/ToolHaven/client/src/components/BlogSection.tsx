import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { BlogPost, InsertBlogPost } from "@shared/schema";

export default function BlogSection() {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [formData, setFormData] = useState<InsertBlogPost>({
    title: "",
    content: "",
    category: "",
    imageUrl: "",
    tags: []
  });
  const [tagsInput, setTagsInput] = useState("");
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: blogPosts, isLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/blog-posts"],
  });

  const createPostMutation = useMutation({
    mutationFn: async (data: InsertBlogPost) => {
      const response = await apiRequest("POST", "/api/blog-posts", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blog-posts"] });
      setFormData({ title: "", content: "", category: "", imageUrl: "", tags: [] });
      setTagsInput("");
      setShowCreateForm(false);
      toast({
        title: "Success",
        description: "Blog post created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create blog post",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const tags = tagsInput.split(",").map(tag => tag.trim()).filter(Boolean);
    createPostMutation.mutate({ ...formData, tags });
  };

  const formatDate = (date: string | Date) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <section id="blog" className="py-16 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">Loading blog posts...</div>
        </div>
      </section>
    );
  }

  return (
    <section id="blog" className="py-16 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Latest Blog Posts</h2>
          <p className="text-lg text-muted-foreground">Tips, tutorials, and insights about online tools</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {blogPosts?.map((post) => (
            <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow border-custom">
              {post.imageUrl && (
                <img 
                  src={post.imageUrl} 
                  alt={post.title}
                  className="w-full h-48 object-cover"
                />
              )}
              <CardContent className="p-6">
                <div className="flex items-center mb-2">
                  <Badge variant="default" className="bg-primary-custom">
                    {post.category}
                  </Badge>
                  <span className="text-muted-foreground text-sm ml-2">
                    {formatDate(post.createdAt)}
                  </span>
                </div>
                <h3 className="text-xl font-semibold mb-2">{post.title}</h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                  {post.content.substring(0, 150)}...
                </p>
                <Button variant="link" className="text-accent-custom hover:text-primary-custom p-0">
                  Read More →
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Blog Creation Section */}
        <Card className="p-8 border-custom">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold mb-4">Share Your Knowledge</h3>
            {!showCreateForm ? (
              <Button 
                onClick={() => setShowCreateForm(true)}
                className="bg-primary-custom hover:bg-primary-custom/90"
              >
                Create Blog Post
              </Button>
            ) : (
              <Button 
                variant="outline" 
                onClick={() => setShowCreateForm(false)}
              >
                Cancel
              </Button>
            )}
          </div>

          {showCreateForm && (
            <form onSubmit={handleSubmit} className="max-w-2xl mx-auto space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Post Title</label>
                <Input
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Enter your blog post title"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Category</label>
                <Select 
                  required
                  value={formData.category} 
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="PDF Tools">PDF Tools</SelectItem>
                    <SelectItem value="Video Tools">Video Tools</SelectItem>
                    <SelectItem value="AI Tools">AI Tools</SelectItem>
                    <SelectItem value="Image Tools">Image Tools</SelectItem>
                    <SelectItem value="Text Tools">Text Tools</SelectItem>
                    <SelectItem value="Converters">Converters</SelectItem>
                    <SelectItem value="General">General</SelectItem>
                    <SelectItem value="Security">Security</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Content</label>
                <Textarea
                  required
                  rows={8}
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Write your blog post content here..."
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Featured Image URL</label>
                <Input
                  type="url"
                  value={formData.imageUrl || ""}
                  onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                  placeholder="https://example.com/image.jpg"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Tags (comma-separated)</label>
                <Input
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="online tools, productivity, tutorials"
                />
              </div>
              
              <Button 
                type="submit" 
                className="w-full bg-primary-custom hover:bg-primary-custom/90"
                disabled={createPostMutation.isPending}
              >
                {createPostMutation.isPending ? "Publishing..." : "Publish Blog Post"}
              </Button>
            </form>
          )}
        </Card>
      </div>
    </section>
  );
}
