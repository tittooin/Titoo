import { useState } from "react";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface HeroProps {
  onSearch?: (query: string) => void;
}

export default function Hero({ onSearch }: HeroProps) {
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    if (onSearch) {
      onSearch(searchQuery);
    }
    // Scroll to tools section
    const toolsSection = document.getElementById('tools');
    if (toolsSection) {
      toolsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  return (
    <section id="home" className="bg-gradient-to-br from-primary to-accent text-white py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-6xl font-bold mb-6">30+ Free Online Tools</h1>
        <p className="text-xl md:text-2xl mb-8 opacity-90">
          Convert files, download videos, chat with AI, and more - all for free
        </p>
        
        <div className="max-w-2xl mx-auto mb-8">
          <div className="relative flex">
            <Input
              type="text"
              placeholder="Search tools..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              className="text-lg py-6 pr-20 text-foreground bg-white border-border"
            />
            <Button 
              onClick={handleSearch}
              className="absolute right-2 top-2 bg-accent-custom hover:bg-primary-custom"
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4">
          <span className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">PDF Tools</span>
          <span className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">Video Downloads</span>
          <span className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">AI Chat</span>
          <span className="bg-white bg-opacity-20 px-4 py-2 rounded-full text-sm">File Converters</span>
        </div>
      </div>
    </section>
  );
}
