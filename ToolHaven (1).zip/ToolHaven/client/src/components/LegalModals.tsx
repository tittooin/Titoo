import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function LegalModals() {
  const [activeModal, setActiveModal] = useState<string | null>(null);

  useEffect(() => {
    const handleOpenModal = (event: CustomEvent) => {
      setActiveModal(event.detail.modalId);
    };

    window.addEventListener('openModal', handleOpenModal as EventListener);
    return () => window.removeEventListener('openModal', handleOpenModal as EventListener);
  }, []);

  const closeModal = () => setActiveModal(null);

  return (
    <>
      {/* Privacy Policy Modal */}
      <Dialog open={activeModal === 'privacy'} onOpenChange={closeModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Privacy Policy</DialogTitle>
          </DialogHeader>
          <div className="prose max-w-none">
            <p className="text-muted-foreground mb-4">Last updated: January 1, 2025</p>
            
            <h3 className="text-xl font-semibold mb-3">Information We Collect</h3>
            <p className="mb-4">
              We collect information you provide directly to us when you use our online tools, create blog posts, or contact us. 
              This may include your name, email address, and any content you upload or create.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">How We Use Your Information</h3>
            <ul className="mb-4 space-y-2">
              <li>• To provide and improve our online tools</li>
              <li>• To respond to your inquiries and provide support</li>
              <li>• To send you updates about our services</li>
              <li>• To analyze usage patterns and improve user experience</li>
            </ul>
            
            <h3 className="text-xl font-semibold mb-3">Data Security</h3>
            <p className="mb-4">
              We implement appropriate security measures to protect your personal information. 
              All file uploads are processed securely and deleted after processing.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">Third-Party Services</h3>
            <p className="mb-4">
              We may use third-party services for analytics and functionality. 
              These services have their own privacy policies governing the use of your information.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">Contact Us</h3>
            <p className="mb-4">
              If you have any questions about this Privacy Policy, please contact us at privacy@tittoosonlinetools.com
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Terms of Service Modal */}
      <Dialog open={activeModal === 'terms'} onOpenChange={closeModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Terms of Service</DialogTitle>
          </DialogHeader>
          <div className="prose max-w-none">
            <p className="text-muted-foreground mb-4">Last updated: January 1, 2025</p>
            
            <h3 className="text-xl font-semibold mb-3">Acceptance of Terms</h3>
            <p className="mb-4">
              By accessing and using TittoosOnlineTools, you accept and agree to be bound by the terms and provision of this agreement.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">Use License</h3>
            <p className="mb-4">
              Permission is granted to temporarily use our online tools for personal and commercial purposes. 
              This license shall automatically terminate if you violate any of these restrictions.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">Prohibited Uses</h3>
            <ul className="mb-4 space-y-2">
              <li>• Use our tools for illegal activities</li>
              <li>• Attempt to damage or disrupt our services</li>
              <li>• Upload malicious files or content</li>
              <li>• Violate any applicable laws or regulations</li>
            </ul>
            
            <h3 className="text-xl font-semibold mb-3">Disclaimer</h3>
            <p className="mb-4">
              Our tools are provided "as is" without any warranties. 
              We do not guarantee that our services will be uninterrupted or error-free.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">Limitation of Liability</h3>
            <p className="mb-4">
              In no event shall TittoosOnlineTools be liable for any damages arising out of the use or inability to use our services.
            </p>
            
            <h3 className="text-xl font-semibold mb-3">Contact Information</h3>
            <p className="mb-4">
              Questions about the Terms of Service should be sent to us at legal@tittoosonlinetools.com
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
