import { useEffect } from "react";
import { X, Upload, CloudUpload, Info } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { toolsData } from "@/lib/tools-data";

interface ToolModalProps {
  toolId: string | null;
  onClose: () => void;
}

export default function ToolModal({ toolId, onClose }: ToolModalProps) {
  const tool = toolId ? toolsData.find(t => t.id === toolId) : null;

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (toolId) {
      document.addEventListener('keydown', handleEscape);
      return () => document.removeEventListener('keydown', handleEscape);
    }
  }, [toolId, onClose]);

  if (!tool) return null;

  const renderToolInterface = () => {
    switch (tool.id) {
      case 'pdf-merger':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className={`w-20 h-20 ${tool.bgColor} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                <tool.icon className={`text-3xl ${tool.iconColor}`} />
              </div>
              <h3 className="text-xl font-semibold mb-2">{tool.title}</h3>
              <p className="text-muted-foreground">{tool.description}</p>
            </div>
            <div className="border-2 border-dashed border-border rounded-lg p-8 text-center">
              <CloudUpload className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-lg mb-2">Drop PDF files here or click to upload</p>
              <p className="text-sm text-muted-foreground">Supports multiple PDF files</p>
              <Button className="mt-4 bg-primary-custom hover:bg-primary-custom/90">
                Choose Files
              </Button>
            </div>
            <div className="bg-muted rounded-lg p-4">
              <h4 className="font-semibold mb-2">Features:</h4>
              <ul className="space-y-1 text-sm text-muted-foreground">
                <li>• Merge unlimited PDF files</li>
                <li>• Preserve original quality</li>
                <li>• Secure processing</li>
                <li>• No file size limit</li>
              </ul>
            </div>
          </div>
        );

      case 'youtube-downloader':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className={`w-20 h-20 ${tool.bgColor} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                <tool.icon className={`text-3xl ${tool.iconColor}`} />
              </div>
              <h3 className="text-xl font-semibold mb-2">{tool.title}</h3>
              <p className="text-muted-foreground">{tool.description}</p>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">YouTube URL</label>
                <Input placeholder="https://www.youtube.com/watch?v=..." />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Quality</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select quality" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1080p">1080p (Full HD)</SelectItem>
                      <SelectItem value="720p">720p (HD)</SelectItem>
                      <SelectItem value="480p">480p</SelectItem>
                      <SelectItem value="360p">360p</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Format</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mp4">MP4</SelectItem>
                      <SelectItem value="mp3">MP3 (Audio only)</SelectItem>
                      <SelectItem value="avi">AVI</SelectItem>
                      <SelectItem value="mkv">MKV</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Button className="w-full bg-primary-custom hover:bg-primary-custom/90">
                Download Video
              </Button>
            </div>
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                Please respect copyright laws and YouTube's terms of service.
              </AlertDescription>
            </Alert>
          </div>
        );

      case 'ai-chat':
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className={`w-20 h-20 ${tool.bgColor} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                <tool.icon className={`text-3xl ${tool.iconColor}`} />
              </div>
              <h3 className="text-xl font-semibold mb-2">{tool.title}</h3>
              <p className="text-muted-foreground">{tool.description}</p>
            </div>
            <div className="bg-muted rounded-lg p-4 h-64 overflow-y-auto">
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                    <tool.icon className="text-white text-sm" />
                  </div>
                  <div className="bg-background rounded-lg p-3 shadow-sm">
                    <p className="text-sm">Hello! I'm your AI assistant. How can I help you today?</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 justify-end">
                  <div className="bg-primary-custom text-white rounded-lg p-3 shadow-sm">
                    <p className="text-sm">Hi! Can you help me with PDF conversion?</p>
                  </div>
                  <div className="w-8 h-8 bg-muted-foreground rounded-full flex items-center justify-center">
                    <span className="text-white text-sm">U</span>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center">
                    <tool.icon className="text-white text-sm" />
                  </div>
                  <div className="bg-background rounded-lg p-3 shadow-sm">
                    <p className="text-sm">Of course! I can help you with PDF conversion. What type of conversion are you looking for?</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="flex space-x-2">
              <Input placeholder="Type your message..." className="flex-1" />
              <Button className="bg-primary-custom hover:bg-primary-custom/90">
                Send
              </Button>
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-8">
            <div className={`w-20 h-20 ${tool.bgColor} rounded-lg flex items-center justify-center mx-auto mb-4`}>
              <tool.icon className={`text-3xl ${tool.iconColor}`} />
            </div>
            <h3 className="text-xl font-semibold mb-2">{tool.title}</h3>
            <p className="text-muted-foreground mb-6">{tool.description}</p>
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                <Info className="inline mr-2 h-4 w-4" />
                This tool interface is coming soon! We're working on bringing you this amazing tool.
              </p>
            </div>
          </div>
        );
    }
  };

  return (
    <Dialog open={!!toolId} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{tool.title}</DialogTitle>
        </DialogHeader>
        {renderToolInterface()}
      </DialogContent>
    </Dialog>
  );
}
