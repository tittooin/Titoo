import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="bg-white border-b border-custom sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <h1 className="text-2xl font-bold text-primary-custom">TittoosOnlineTools</h1>
            </div>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <button 
                onClick={() => scrollToSection('home')}
                className="text-primary-custom hover:text-accent-custom px-3 py-2 font-medium transition-colors"
              >
                Home
              </button>
              <button 
                onClick={() => scrollToSection('tools')}
                className="text-foreground hover:text-accent-custom px-3 py-2 font-medium transition-colors"
              >
                Tools
              </button>
              <button 
                onClick={() => scrollToSection('blog')}
                className="text-foreground hover:text-accent-custom px-3 py-2 font-medium transition-colors"
              >
                Blog
              </button>
              <button 
                onClick={() => scrollToSection('contact')}
                className="text-foreground hover:text-accent-custom px-3 py-2 font-medium transition-colors"
              >
                Contact
              </button>
            </div>
          </div>
          
          <div className="md:hidden">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-foreground hover:text-accent-custom p-2"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>
      
      {isMobileMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t border-custom">
            <button 
              onClick={() => scrollToSection('home')}
              className="block px-3 py-2 text-primary-custom font-medium w-full text-left"
            >
              Home
            </button>
            <button 
              onClick={() => scrollToSection('tools')}
              className="block px-3 py-2 text-foreground hover:text-accent-custom w-full text-left"
            >
              Tools
            </button>
            <button 
              onClick={() => scrollToSection('blog')}
              className="block px-3 py-2 text-foreground hover:text-accent-custom w-full text-left"
            >
              Blog
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="block px-3 py-2 text-foreground hover:text-accent-custom w-full text-left"
            >
              Contact
            </button>
          </div>
        </div>
      )}
    </nav>
  );
}
