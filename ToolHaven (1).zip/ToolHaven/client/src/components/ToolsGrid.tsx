import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toolsData } from "@/lib/tools-data";

interface ToolsGridProps {
  onToolClick: (toolId: string) => void;
  searchQuery?: string;
}

const categories = [
  { id: "all", label: "All Tools" },
  { id: "pdf", label: "PDF Tools" },
  { id: "video", label: "Video Tools" },
  { id: "ai", label: "AI Tools" },
  { id: "converter", label: "Converters" },
  { id: "image", label: "Image Tools" },
  { id: "text", label: "Text Tools" },
];

export default function ToolsGrid({ onToolClick, searchQuery = "" }: ToolsGridProps) {
  const [activeCategory, setActiveCategory] = useState("all");

  const filteredTools = useMemo(() => {
    let filtered = toolsData;

    // Filter by category
    if (activeCategory !== "all") {
      filtered = filtered.filter(tool => tool.category === activeCategory);
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(tool => 
        tool.title.toLowerCase().includes(query) ||
        tool.description.toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [activeCategory, searchQuery]);

  return (
    <div>
      {/* Category Filter */}
      <section className="py-8 bg-muted">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={activeCategory === category.id ? "default" : "outline"}
                onClick={() => setActiveCategory(category.id)}
                className={activeCategory === category.id ? 
                  "bg-primary-custom text-white hover:bg-primary-custom/90" : 
                  "hover:bg-muted"
                }
              >
                {category.label}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section id="tools" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">Featured Online Tools</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTools.map((tool) => (
              <Card 
                key={tool.id}
                className="p-6 hover:shadow-lg transition-shadow cursor-pointer border-custom"
                onClick={() => onToolClick(tool.id)}
              >
                <div className="text-center">
                  <div className={`w-16 h-16 ${tool.bgColor} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                    <tool.icon className={`text-2xl ${tool.iconColor}`} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{tool.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4">{tool.description}</p>
                  <div className="flex justify-center space-x-2">
                    {tool.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
          
          {filteredTools.length === 0 && (
            <div className="text-center py-12">
              <p className="text-lg text-muted-foreground">No tools found matching your criteria.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
