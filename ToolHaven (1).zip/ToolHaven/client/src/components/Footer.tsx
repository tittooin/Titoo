import { Twitter, Facebook, Linkedin } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const openModal = (modalId: string) => {
    const event = new CustomEvent('openModal', { detail: { modalId } });
    window.dispatchEvent(event);
  };

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-2xl font-bold mb-4">TittoosOnlineTools</h3>
            <p className="text-gray-400 mb-4">
              Your one-stop destination for 30+ free online tools. Convert, compress, edit, and optimize your files with ease.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Popular Tools</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button onClick={() => {}} className="hover:text-white transition-colors">PDF Merger</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">YouTube Downloader</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">AI Chat</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">Image Compressor</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">QR Generator</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Categories</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button onClick={() => {}} className="hover:text-white transition-colors">PDF Tools</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">Video Tools</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">AI Tools</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">Image Tools</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">Converters</button></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4">Legal</h4>
            <ul className="space-y-2 text-gray-400">
              <li><button onClick={() => openModal('privacy')} className="hover:text-white transition-colors">Privacy Policy</button></li>
              <li><button onClick={() => openModal('terms')} className="hover:text-white transition-colors">Terms of Service</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">Cookie Policy</button></li>
              <li><button onClick={() => scrollToSection('contact')} className="hover:text-white transition-colors">Contact Us</button></li>
              <li><button onClick={() => {}} className="hover:text-white transition-colors">DMCA</button></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2025 TittoosOnlineTools. All rights reserved. | Free online tools for everyone.</p>
        </div>
      </div>
    </footer>
  );
}
